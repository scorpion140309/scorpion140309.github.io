#ifndef _GL_WINDOW_26560_H_	// ���O�d���h�~
#define _GL_WINDOW_26560_H_

#include <windows.h>

namespace{
	const int GLW_ORTOGRAPHIC_MODE = 0;
	const int GLW_PERSPECTIVE_MODE = 1;
}

struct glvi;

class glWindow
{
private:
	//
	void DisplayFunc__();
	int SetPixelFormat__()  const;

	// �������Ȃ������o�֐�
	glWindow( const glWindow & rhs );						//�R�s�[�R���X�g���N�^
	glWindow & operator = ( const glWindow & rhs );			//������Z�q

protected:
	LRESULT ( CALLBACK *proc_ )( HWND hWnd, UINT msg, WPARAM wp, LPARAM lp );
	void ( *disp_ )();

	//
	void MouseFunc_( UINT button_state, WORD x, WORD y );
	void KeydownFunc_( UINT_PTR key, LONG x, LONG y );

	// 
	HINSTANCE instance_;
	int show_;
	HWND wnd_;
	HDC dc_;
	HGLRC rc_;
	MSG msg_;
	WNDCLASS winc_;
	glvi *vi_;

	//
	//
	void Light_and_Material_() const;
	void OtherSetting_() const;
	int InitWGL_( HWND hWnd );
	void Reshape_() const;
	void Mouse_( UINT button_state, WORD x, WORD y );
	void drawGL_();

	int SetProjectionMode_( int mode );
	void Reset_();


public:
//	glWindow( HINSTANCE hInstance, int nCmdShow, void display_func( const glvi *vi ) );
	glWindow( HINSTANCE hInstance, int nCmdShow );
	virtual ~glWindow();

	// �Öف�����
	glWindow * operator& (){ return this; };				//�A�h���X���Z�q
	const glWindow * operator& () const{ return this; };	//�A�h���X���Z�q

	// windows.h
	// �p�����Ȃ�
	ATOM RegClass( HICON hIcon = NULL );
	ATOM RegClass( LRESULT CALLBACK wndproc( HWND, UINT, WPARAM, LPARAM ) );
	HWND Create( const char *window_name, int nWidth = 500, int nHeight = 500 );
	void glWindow::Loop( MSG *msg );

	//

};

#endif	// _GL_WINDOW_26560_H_
