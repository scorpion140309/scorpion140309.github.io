//
//
//

#ifdef UNICODE
#define LPXCH LPWCH
#else
#define LPXCH LPCH
#endif

//
#include <windows.h>
#include <wscInsertMenu.h>

// �T�u���j���[�}��
int scmn::InsertSubMenu( const HMENU hMenu, const HMENU hSubMenu, const TCHAR *submenuname, const UINT uItem ){
	MENUITEMINFO mii;

	::ZeroMemory( &mii, sizeof( MENUITEMINFO ) );
	mii.cbSize		= sizeof( MENUITEMINFO );
	mii.fMask		= MIIM_TYPE | MIIM_SUBMENU;
	mii.fType		= MFT_STRING;
	mii.hSubMenu	= hSubMenu;
	mii.dwTypeData	= reinterpret_cast< LPTSTR >( const_cast< TCHAR * >( submenuname ) );
	return ::InsertMenuItem( hMenu , uItem, TRUE, &mii );
}

// �A�C�e���}��
int scmn::InsertItem( const HMENU hMenu, const unsigned int wID, const TCHAR *itemname, const UINT uItem ){
	MENUITEMINFO mii;

	::ZeroMemory( &mii, sizeof( MENUITEMINFO ) );
	mii.cbSize		= sizeof( MENUITEMINFO );
	mii.fMask		= MIIM_TYPE | MIIM_ID;
	mii.wID			= wID;
	mii.fType		= MFT_STRING;
	mii.dwTypeData	= reinterpret_cast< LPTSTR >( const_cast< TCHAR* >( itemname ) );
/*
	mii.cbSize		= sizeof( MENUITEMINFO );
	mii.fMask		= MIIM_STRING|MIIM_BITMAP;
	mii.wID			= wID;
	mii.fType		= MFT_STRING;
	mii.dwTypeData	= reinterpret_cast< LPTSTR >( const_cast< TCHAR* >( itemname ) );
	mii.hbmpItem = (HBITMAP)LoadImage(NULL,"D:\\SDK\\LeapMotion_test_project\\aero_link.bmp",IMAGE_BITMAP,0,0,LR_LOADFROMFILE);;
*/
	return ::InsertMenuItem( hMenu, uItem, TRUE, &mii );
}

// �`�F�b�N�t���A�C�e���}��
int scmn::InsertCheckItem( const HMENU hMenu, const unsigned int wID, const TCHAR *itemname, const UINT uItem ){
	MENUITEMINFO mii;

	::ZeroMemory( &mii, sizeof( MENUITEMINFO ) );
	mii.cbSize		= sizeof( MENUITEMINFO );
	mii.fMask		= MIIM_TYPE | MIIM_ID;
	mii.fState		= MFS_ENABLED | MFS_CHECKED;
	mii.wID			= wID;
	mii.fType		= MFT_STRING;
	mii.dwTypeData	= reinterpret_cast< LPTSTR >( const_cast< TCHAR * >( itemname ) );

	return ::InsertMenuItem( hMenu, uItem, TRUE, &mii );
}

// ���W�I�^�A�C�e���}��
int scmn::InsertRadioItem( const HMENU hMenu, const unsigned int wID, const TCHAR *itemname, const UINT uItem ){
	MENUITEMINFO mii;

	::ZeroMemory( &mii, sizeof( MENUITEMINFO ) );
	mii.cbSize		= sizeof( MENUITEMINFO );
	mii.fMask		= MIIM_TYPE | MIIM_STATE | MIIM_ID;
	mii.fState		= MFS_ENABLED;
	mii.wID			= wID;
	mii.fType		= MFT_STRING | MFT_RADIOCHECK;
	mii.cch			= static_cast< unsigned int >( ::lstrlen( itemname ) );
	mii.dwTypeData	= reinterpret_cast< LPTSTR >( const_cast< TCHAR * >( itemname ) );

	return ::InsertMenuItem( hMenu, uItem, TRUE, &mii );
}

// �Z�p���[�^�}��
int scmn::InsertSeparator( const HMENU hMenu, const UINT uItem ){
	MENUITEMINFO mii;

	::ZeroMemory( &mii, sizeof( MENUITEMINFO ) );
	mii.cbSize		= sizeof( MENUITEMINFO );
	mii.fMask		= MIIM_TYPE | MIIM_STATE;
	mii.fType		= MFT_SEPARATOR;
	mii.fState		= MFS_GRAYED;

	return ::InsertMenuItem( hMenu, uItem, TRUE, &mii );
}
