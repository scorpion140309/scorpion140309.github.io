//
//
//


#define _CRT_SECURE_NO_DEPRECATE
#define STRICT
#define WIN32_LEAN_AND_MEAN

#include "glWindow.h"
#include "glvi.h"

//#include <scGetString.h>

#include <gl/gl.h>
#include <gl/glu.h>


#pragma comment( lib, "opengl32.lib" )
#pragma comment( lib, "glu32.lib" )



//
namespace{
	//
	// �萔
	//
	// �t�@�C�����̍ő�T�C�Y
	const int FILEPATH_SIZE = 10000;

	//
	// �O���[�o���ϐ�
	//

}

/*********************************************************************
	static �񃁃��o
 *********************************************************************/

static void Init_glvi( glvi *vi )
{
	vi->bgcolor[ 0 ] = 0.0f;
	vi->bgcolor[ 1 ] = 0.0f;
	vi->bgcolor[ 2 ] = 0.0f;
	vi->bgcolor[ 3 ] = 0.0f;
	vi->eye[ 0 ] = 0.0f;
	vi->eye[ 1 ] = 0.0f;
	vi->eye[ 2 ] = 200.0f;
	vi->eye[ 3 ] = 0.0f;
	vi->center[ 0 ] = 0.0f;
	vi->center[ 1 ] = 0.0f;
	vi->center[ 2 ] = 0.0f;
	vi->center[ 3 ] = 0.0f;
	vi->v_mode = GLW_PERSPECTIVE_MODE;
	vi->scale = 1.0f;
	vi->angle0 = 0.0f;
	vi->angle1 = 0.0f;
	vi->trans[ 0 ] = 0.0f;
	vi->trans[ 1 ] = 0.0f;
	vi->trans[ 2 ] = 0.0f;

	// ����
	vi->lmodel_ambient[ 0 ] = 0.0f;
	vi->lmodel_ambient[ 1 ] = 0.0f;
	vi->lmodel_ambient[ 2 ] = 0.0f;
	vi->lmodel_ambient[ 3 ] = 0.0f;
	vi->lmodel_twoside[ 0 ] = GL_TRUE;
	vi->lmodel_local[ 0 ] = GL_FALSE;
	vi->light0_ambient[ 0 ] = 0.1f;
	vi->light0_ambient[ 1 ] = 0.1f;
	vi->light0_ambient[ 2 ] = 0.1f;
	vi->light0_ambient[ 3 ] = 1.0f;
	vi->light0_diffuse[ 0 ] = 1.0f;
	vi->light0_diffuse[ 1 ] = 1.0f;
	vi->light0_diffuse[ 2 ] = 1.0f;
	vi->light0_diffuse[ 3 ] = 0.0f;
	vi->light0_specular[ 0 ] = 1.0f;
	vi->light0_specular[ 1 ] = 1.0f;
	vi->light0_specular[ 2 ] = 1.0f;
	vi->light0_specular[ 3 ] = 0.0f;
	vi->light0_position[ 0 ] = static_cast< float >( vi->eye[ 0 ] );
	vi->light0_position[ 1 ] = static_cast< float >( vi->eye[ 1 ] );
	vi->light0_position[ 2 ] = static_cast< float >( vi->eye[ 2 ] );
	vi->light0_position[ 3 ] = static_cast< float >( vi->eye[ 3 ] );

	vi->znear = -400.0f;
	vi->zfar = 400.0f;

	vi->mat_ambient[ 0 ] = 0.1f;
	vi->mat_ambient[ 1 ] = 0.1f;
	vi->mat_ambient[ 2 ] = 0.1f;
	vi->mat_ambient[ 3 ] = 0.1f;
	vi->mat_shininess[ 0 ] = 40.0f;
	vi->mat_specular[ 0 ] = 0.1f;
	vi->mat_specular[ 1 ] = 0.1f;
	vi->mat_specular[ 2 ] = 0.1f;
	vi->mat_specular[ 3 ] = 0.0f;
	vi->mat_diffuse[ 0 ] = 0.0f;
	vi->mat_diffuse[ 1 ] = 1.0f;
	vi->mat_diffuse[ 2 ] = 0.0f;
	vi->mat_diffuse[ 3 ] = 0.0f;


	return;
}


/*********************************************************************
	static �����o
 *********************************************************************/


/*********************************************************************
	�R���X�g���N�^�C�f�X�g���N�^
 *********************************************************************/
// �R���X�g���N�^
// constractor
glWindow::glWindow( HINSTANCE hInstance, int nCmdShow )
{
	instance_	= hInstance;
	show_		= nCmdShow;

	wnd_	= NULL;
	dc_	= NULL;

	vi_ = new glvi;
	Init_glvi( vi_ );

}

// �f�X�g���N�^
glWindow::~glWindow()
{
	delete vi_;
}

/*********************************************************************
	private�����o�֐�
 *********************************************************************/
//
int glWindow::SetPixelFormat__() const
{
	PIXELFORMATDESCRIPTOR pfd;
	int pixelformat;

	pfd.nSize = sizeof( PIXELFORMATDESCRIPTOR );
	pfd.nVersion = 1;
	pfd.dwFlags = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;
	pfd.iPixelType = PFD_TYPE_RGBA;
	pfd.cColorBits = 24;
	pfd.cDepthBits = 32;
	pfd.cAccumBits = 0;
	pfd.cStencilBits = 0;
	if( ( pixelformat = ::ChoosePixelFormat( dc_, &pfd ) ) == 0 ){
//		::MessageBox( wnd_, "ChoosePixelFormat failed", "Error", MB_OK );
		return 1;
	}
	if( ::SetPixelFormat( dc_, pixelformat, &pfd) == FALSE ){
//		::MessageBox( wnd_, "SetPixelFormat failed", "Error", MB_OK );
		return 1;
	}

	return 0;
}



/*********************************************************************
	protected�����o�֐�
 *********************************************************************/

// drawing
void glWindow::drawGL_()
{
	::glClearColor( vi_->bgcolor[0], vi_->bgcolor[1], vi_->bgcolor[2], 0.0f );
	::glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
	::glClearDepth( 1.0f );

	::glPushMatrix();
		::glTranslated( vi_->center[ 0 ] + vi_->trans[ 0 ], vi_->center[ 1 ] + vi_->trans[ 1 ], vi_->center[ 2 ] + vi_->trans[ 2 ] );
		::glRotated( vi_->angle1, 1.0f, 0.0f, 0.0f );
		::glPushMatrix();
			::glRotated( vi_->angle0, 0.0f, 1.0f, 0.0f );
			::glScaled( vi_->scale, vi_->scale, vi_->scale );
			DisplayFunc__();
		::glPopMatrix();
	::glPopMatrix();

	::SwapBuffers( dc_ );

	return;
}

//
void glWindow::Light_and_Material_() const
{
	/* �����̐ݒ� */
	::glLightfv( GL_LIGHT0, GL_AMBIENT, vi_->light0_ambient );
	::glLightfv( GL_LIGHT0, GL_DIFFUSE, vi_->light0_diffuse );
	::glLightfv( GL_LIGHT0, GL_SPECULAR, vi_->light0_specular );
	::glLightfv( GL_LIGHT0, GL_POSITION, vi_->light0_position );
	::glEnable( GL_LIGHT0);

	/* �������f���̐ݒ� */
	::glLightModelfv( GL_LIGHT_MODEL_LOCAL_VIEWER, vi_->lmodel_local );
	::glLightModelfv( GL_LIGHT_MODEL_TWO_SIDE, vi_->lmodel_twoside );
	::glLightModelfv( GL_LIGHT_MODEL_AMBIENT, vi_->lmodel_ambient );

	/* ������L���ɂ��� */
	::glEnable( GL_LIGHTING );

	/* �I�u�W�F�N�g�̍ގ� */
	::glMaterialfv( GL_FRONT, GL_AMBIENT, vi_->mat_ambient );
	::glMaterialfv( GL_FRONT, GL_SHININESS, vi_->mat_shininess );
	::glMaterialfv( GL_FRONT, GL_SPECULAR, vi_->mat_specular );
	::glMaterialfv( GL_FRONT, GL_DIFFUSE, vi_->mat_diffuse );
	::glColorMaterial( GL_FRONT_AND_BACK, GL_DIFFUSE );

	return;
}

//
void glWindow::OtherSetting_() const
{
	// �f�v�X��L���ɂ���
	::glEnable( GL_DEPTH_TEST );

	return;
}

// �T�C�Y�ύX���ɌĂԁB
// WM_SIZE �� WM_CREATE ����ɌĂ΂�邱�Ƃ�����炵���B
void glWindow::Reshape_() const
{
	RECT rect;
	LONG w, h;
	double aspect;

	if( wnd_ == NULL ){
		return;
	}
	::GetWindowRect( wnd_, &rect );
	w = rect.right - rect.left;
	h = rect.bottom - rect.top;
	aspect = static_cast< double >( w ) / static_cast< double >( h );

	::glViewport( 0, 0, static_cast< GLsizei >( w ), static_cast< GLsizei >( h ) );	// ��ʂ̏o��͈�
	::glMatrixMode( GL_PROJECTION );	// ���E�ϊ��錾
	::glLoadIdentity();				// �P�ʍs����
	if( vi_->v_mode == GLW_PERSPECTIVE_MODE ){
		::gluPerspective(
			50.0,			// field of view in degree
			aspect,			// aspect ratio
			1.0,			// Z near
			vi_->eye[ 2 ] * 2	// Z far
		);
		::gluLookAt(
			vi_->eye[ 0 ], vi_->eye[ 1 ], vi_->eye[ 2 ],
			vi_->center[ 0 ], vi_->center[ 1 ], vi_->center[ 2 ],
			0.0f, 1.0f, 0.0f
		);
	}
	else{
		double v_size = 200.0f;
		::glOrtho(
			- v_size * aspect, v_size * aspect,
			- v_size, v_size,
			vi_->znear, vi_->zfar
		);
		::gluLookAt(
			vi_->eye[ 0 ], vi_->eye[ 1 ], vi_->eye[ 2 ],
			vi_->center[ 0 ], vi_->center[ 1 ], vi_->center[ 2 ],
			0.0f, 1.0f, 0.0f
		);
	}
	::glMatrixMode( GL_MODELVIEW );		// ���f���ϊ��錾

	return;
}

// mouse & motion
void glWindow::Mouse_( UINT button_state, WORD x, WORD y )
{
	static WORD ox, oy;
	static int rotation, scaling, trans;

	switch( button_state ){
	case WM_LBUTTONDOWN:
		rotation = 1;
		ox = x;
		oy = y;
		break;
	case WM_LBUTTONUP:
		rotation = 0;
		break;
	case WM_RBUTTONDOWN:
		scaling = 1;
		ox = x;
		oy = y;
		break;
	case WM_RBUTTONUP:
		scaling = 0;
		break;
	case WM_MBUTTONDOWN:
		::SetCursor( ::LoadCursor( NULL, IDC_CROSS ) );
		trans = 1;
		ox = x;
		oy = y;
		break;
	case WM_MBUTTONUP:
		trans = 0;
		break;
	case WM_MOUSEMOVE:
		if( rotation )
		{
			vi_->angle0 = vi_->angle0 + ( x - ox );
			vi_->angle1 = vi_->angle1 + ( y - oy );
		}
		if( scaling )
		{
			vi_->scale += 0.01f * static_cast< float >( x - ox );
		}
		// ��������
		if( trans )
		{
			vi_->trans[ 0 ] += static_cast< float >( x - ox );
			vi_->trans[ 1 ] -= static_cast< float >( y - oy );
		}
		ox = x;
		oy = y;
		break;
	default:
		break;
	}

	ox = x;
	oy = y;

	if( trans )
	{
		::SetCursor( ::LoadCursor( NULL, IDC_SIZEALL ) );	// �\��
	}
	else if( scaling )
	{
		::SetCursor( ::LoadCursor( NULL, IDC_ARROW ) );
	}
	else if( rotation )
	{
		::SetCursor( ::LoadCursor( NULL, IDC_ARROW ) );
	}
	else
	{
		::SetCursor( ::LoadCursor( NULL, IDC_ARROW ) );
	}

	return;
}

//
int glWindow::InitWGL_( HWND hWnd )
{
	wnd_ = hWnd;
	dc_ = ::GetDC( hWnd );
	if( SetPixelFormat__() )
	{
		return 1;
	}
	rc_ = ::wglCreateContext( dc_ );
	::wglMakeCurrent( dc_, rc_ );
	return 0;
}

//
int glWindow::SetProjectionMode_( int mode )
{
	int old_mode = vi_->v_mode;
	vi_->v_mode = mode;
	Reshape_();
	return old_mode;
}

//
void glWindow::Reset_()
{
	vi_->trans[ 0 ] = 0.0f;
	vi_->trans[ 1 ] = 0.0f;
	vi_->trans[ 2 ] = 0.0f;

	vi_->scale = 1.0f;
	vi_->angle0 = 0.0f;
	vi_->angle1 = 0.0f;
	return;
}

/*********************************************************************
	public�����o�֐�
 *********************************************************************/
//
ATOM glWindow::RegClass( HICON hIcon ){
	winc_.style			= CS_HREDRAW | CS_VREDRAW;
//	winc_.lpfnWndProc	= Wndproc_;
	winc_.lpfnWndProc	= proc_;
	winc_.cbClsExtra	= 0;
	winc_.cbWndExtra	= 0;
	winc_.hInstance		= instance_;
	if( hIcon ){
		winc_.hIcon		= hIcon;
	}
	else{
		winc_.hIcon		= NULL;
	}
	winc_.hCursor		= ::LoadCursor( NULL, IDC_ARROW );
	winc_.hbrBackground	= static_cast< HBRUSH >( ::GetStockObject( GRAY_BRUSH ) );
	winc_.lpszMenuName	= NULL;
	winc_.lpszClassName	= TEXT( "ClassName" );

	return ::RegisterClass( &winc_ );
}

//
ATOM glWindow::RegClass( LRESULT CALLBACK wndproc( HWND, UINT, WPARAM, LPARAM ) )
{
	winc_.style			= CS_HREDRAW | CS_VREDRAW;
	winc_.lpfnWndProc	= wndproc;
	winc_.cbClsExtra	= 0;
	winc_.cbWndExtra	= 0;
	winc_.hInstance		= instance_;
	winc_.hIcon			= NULL;
	winc_.hCursor		= ::LoadCursor( NULL, IDC_ARROW );
	winc_.hbrBackground	= static_cast< HBRUSH >( ::GetStockObject( GRAY_BRUSH ) );
	winc_.lpszMenuName	= NULL;
	winc_.lpszClassName	= TEXT( "ClassName" );

	return ::RegisterClass( &winc_ );
}

// �E�B���h�E�����
HWND glWindow::Create( const char *window_name, int nWidth, int nHeight )
{
	DWORD dwStile;
	dwStile = WS_OVERLAPPEDWINDOW | WS_VISIBLE;
//	dwStile = ( WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_THICKFRAME ) | WS_VISIBLE;
	wnd_ = ::CreateWindow(
		TEXT( "ClassName" ), TEXT( window_name ),
		dwStile,
		CW_USEDEFAULT, CW_USEDEFAULT,
		nWidth, nHeight,
		NULL , NULL , instance_ , NULL
	);
	if( wnd_ )
	{
		::ShowWindow( wnd_, show_ );	// �E�C���h�E�̕\��
		::UpdateWindow( wnd_ );		// �E�C���h�E�̍ŏ��̍X�V
	}

	return wnd_;
}

//
void glWindow::Loop( MSG *msg )
{
	while( ::GetMessage( msg , NULL , 0 , 0 ) )
	{
		::TranslateMessage( msg );	// ���ꂪ�����ƃG�f�B�b�g�R���g���[�����g���Ȃ��炵��
		::DispatchMessage( msg );
	}
	return;
}

// �`��֐����w��
void glWindow::DisplayFunc__()
{
	if( disp_ )
	{
		( *disp_ )();
	}
	return;
}

