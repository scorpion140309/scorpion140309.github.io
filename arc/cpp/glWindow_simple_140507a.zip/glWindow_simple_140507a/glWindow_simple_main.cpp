//
// Windows API �� OpenGL
// ���:scorpion
//

#define STRICT
#define WIN32_LEAN_AND_MEAN

#include "resource.h"

#include "mygl.h"
#include <windows.h>

// ���C��
int WINAPI WinMain(
	HINSTANCE hInstance,
	HINSTANCE /*hPrevInst*/,
	LPSTR lpCmdParam,
	int nCmdShow)
{
	int result = -1;
	HWND hWnd;
	MSG msg;

	mygl gw( hInstance, nCmdShow, lpCmdParam );
	if( gw.RegClass( ::LoadIcon( hInstance, MAKEINTRESOURCE( IDI_ICON_GL_WINDOW_TEST ) ) ) )
	{
		hWnd = gw.Create( TITLE, 640, 480 );
		if( hWnd )
		{
			gw.Loop( &msg );
			result = static_cast< int >( msg.wParam );
		}
	}

	return result;
}

