#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif

#define IDI_ICON_GL_WINDOW_TEST                  16
