//
//
//


#define _CRT_SECURE_NO_DEPRECATE
#define STRICT
//#define WIN32_LEAN_AND_MEAN

#include "glWindow.h"
#include "mygl.h"
#include "glvi.h"

#include <wscInsertMenu.h>

#include <gl/gl.h>
#include <gl/glu.h>


#pragma comment( lib, "opengl32.lib" )
#pragma comment( lib, "glu32.lib" )

// �����A��
//#include <gl/glut.h>
//#pragma comment( lib, "glut32.lib" )

#include <vector>


//
namespace
{
	//
	// �萔
	//

	// Menu ID
	const int IDM_HOGE_RELOAD_VERTICES		= 0x0101;
	const int IDM_HOGE_LOAD_3D_DATA			= 0x0102;
	const int IDM_HOGE_EXIT					= 0x01FF;

	const int IDM_HOGE_VIEW_RESET				= 0x0201;
	const int IDM_HOGE_PERSPECTIVE_PROJECTION	= 0x0202;
	const int IDM_HOGE_ORTHOGRAPHIC_PROJECTION	= 0x0203;
	const int IDM_HOGE_VIEW_YZ_PLANE			= 0x0204;
	const int IDM_HOGE_VIEW_ZX_PLANE			= 0x0205;
	const int IDM_HOGE_VIEW_XY_PLANE			= 0x0206;
	const int IDM_HOGE_CHOOSE_BGCOLOR			= 0x0207;

	const int IDM_HOGE_HELP					= 0x0901;
	const int IDM_HOGE_ABOUT_HOGE			= 0x0902;


}

/*********************************************************************
	�񃁃��o
 *********************************************************************/


/*********************************************************************
	static �񃁃��o
 *********************************************************************/



/*********************************************************************
	static �����o
 *********************************************************************/
// �֐��|�C���^�� this �|�C���^��������B
mygl * mygl::st_that_ptr__ = NULL;

// static�����o�֐� �� ��static�����o�֐�
LRESULT CALLBACK mygl::st_DummyProc__( HWND hWnd, UINT msg, WPARAM wp, LPARAM lp )
{
	LRESULT result = NULL;

	if( mygl::st_that_ptr__ != NULL )
	{
		result = mygl::st_that_ptr__->MyGLproc__( hWnd, msg, wp, lp );
	}
	return result;
}

// static�����o�֐� �� ��static�����o�֐�
void mygl::st_DummyDisp__()
{
	if( mygl::st_that_ptr__ != NULL )
	{
		mygl::st_that_ptr__->Mydisp__();
	}
	return;
}

/*********************************************************************
	�R���X�g���N�^�C�f�X�g���N�^
 *********************************************************************/
// �R���X�g���N�^
// constractor
mygl::mygl( HINSTANCE hInstance, int nCmdShow, LPSTR /* lpCmdParam */ ) : glWindow( hInstance, nCmdShow )
{
	mygl::st_that_ptr__ = this;
	disp_ = st_DummyDisp__;	// �`��֐�
	proc_ = st_DummyProc__;	// �E�B���h�E�v���V�[�W��

	current_file__ = static_cast< char * >( ::operator new( 10000 ) );
	current_file__[ 0 ] = '\0';

}

// �f�X�g���N�^
mygl::~mygl()
{
	::operator delete( current_file__ );


}

/*********************************************************************
	private�����o�֐�
 *********************************************************************/
// �E�B���h�E�v���V�[�W���̎���
LRESULT CALLBACK mygl::MyGLproc__( HWND hWnd, UINT msg, WPARAM wp, LPARAM lp )
{
	switch( msg ){
	case WM_CREATE:
		if( InitWGL_( hWnd ) )
		{
			::PostQuitMessage( 0 );
			return 0;
		}
		Light_and_Material_();
		OtherSetting_();
		InitMenu__();

		break;
	case WM_DESTROY:
		::PostQuitMessage( 0 );
		return 0;

	case WM_SIZE:
		Reshape_();
		break;

	case WM_COMMAND:
		Commandproc__( HIWORD( wp ),LOWORD( wp ), reinterpret_cast< HWND >( lp ) );
		break;
	case WM_KEYDOWN:
		POINT pt;
		::GetCursorPos( &pt );
		KeydownFunc__( wp, pt.x, pt.y );
		drawGL_();
		break;
	case WM_LBUTTONDOWN:
	case WM_LBUTTONUP:
	case WM_RBUTTONDOWN:
	case WM_RBUTTONUP:
	case WM_MBUTTONDOWN:
	case WM_MBUTTONUP:
	case WM_MOUSEMOVE:
		Mouse_( msg, LOWORD( lp ), HIWORD( lp ) );
		drawGL_();
		break;

	case WM_MOUSEWHEEL:
		if( GET_WHEEL_DELTA_WPARAM( wp ) > 0 )
		{
			vi_->znear += 100.0f;
			Reshape_();
		}
		else
		{
			vi_->znear -= 100.0f;
			Reshape_();
		}
		drawGL_();
		break;
	case WM_PAINT:
		drawGL_();
		break;


	default:
		break;
	}
	return ::DefWindowProc( hWnd, msg, wp, lp );
}



// ���e���[�h�̃`�F�b�N
BOOL mygl::CheckProjectionFlag__( int mode )
{
	BOOL result;
	unsigned int idCheck;

	vi_->v_mode = mode;
	if( mode == GLW_PERSPECTIVE_MODE ){
		idCheck = IDM_HOGE_PERSPECTIVE_PROJECTION;
	}
	else if( mode == GLW_ORTOGRAPHIC_MODE ){
		idCheck = IDM_HOGE_ORTHOGRAPHIC_PROJECTION;
	}
	else{
		return false;
	}
	result = ::CheckMenuRadioItem(
		::GetMenu( wnd_ ),
		IDM_HOGE_PERSPECTIVE_PROJECTION, IDM_HOGE_ORTHOGRAPHIC_PROJECTION, idCheck,
		MF_BYCOMMAND
	);
	return result;
}


int mygl::Read3D__( const char * )
{
	int result = -1;

	::MessageBox( wnd_, "������", "ERROR", MB_ICONSTOP | MB_OK );

	return result;
}


// �R�}���h�v���V�[�W��(���j���[�o�[����)
LRESULT mygl::Commandproc__( WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/ )
{
	const char *filename = NULL;
	// Menu
	switch( wID ){
		// &File
	case IDM_HOGE_LOAD_3D_DATA:
		Read3D__( filename );
		break;
	case IDM_HOGE_EXIT:
		::PostQuitMessage( 0 );
		return 0;

	case IDM_HOGE_VIEW_RESET:
		Reset_();
		break;
	case IDM_HOGE_PERSPECTIVE_PROJECTION:
		CheckProjectionFlag__( GLW_PERSPECTIVE_MODE );
		SetProjectionMode_( GLW_PERSPECTIVE_MODE );
		break;
	case IDM_HOGE_ORTHOGRAPHIC_PROJECTION:
		CheckProjectionFlag__( GLW_ORTOGRAPHIC_MODE );
		SetProjectionMode_( GLW_ORTOGRAPHIC_MODE );
		break;
	case IDM_HOGE_VIEW_YZ_PLANE:
		View_YZ_Plane__();
		break;
	case IDM_HOGE_VIEW_ZX_PLANE:
		View_ZX_Plane__();
		break;
	case IDM_HOGE_VIEW_XY_PLANE:
		View_XY_Plane__();
		break;

	case IDM_HOGE_CHOOSE_BGCOLOR:
		ChooseBackgroundColor__();
		break;

	case IDM_HOGE_HELP:
		::MessageBox( wnd_, "", "�w���v", MB_OK | MB_ICONINFORMATION );
		break;
	case IDM_HOGE_ABOUT_HOGE:
		break;

	default:
		break;
	}

	return 0;
}

//
int mygl::ChooseBackgroundColor__()
{
	CHOOSECOLOR cc = { 0 };
	COLORREF color = 0;
	static COLORREF CustColors[ 16 ] = {
		0x00000000,
		0x00404040,
		0x00606060,
		0x00808080,
		0x00D0D0D0,
		0x00FFFFC0,
		0x00FFC0FF,
		0x00C0FFFF,
		0x00FFFFFF,
		0x00FFFFFF,
		0x00FFFFFF,
		0x00FFFFFF,
		0x00FFFFFF,
		0x00FFFFFF,
		0x00FFFFFF,
		0x00FFFFFF,
	};

	cc.lStructSize	= sizeof ( CHOOSECOLOR );
	cc.hwndOwner	= wnd_;
	cc.rgbResult	= color;
	cc.lpCustColors	= CustColors;
	cc.Flags		= CC_FULLOPEN | CC_RGBINIT;
	if( !ChooseColor( &cc ) ){
		return 1;
	}
	vi_->bgcolor[ 2 ] = ( cc.rgbResult >> 16 ) / 255.0f;
	vi_->bgcolor[ 1 ] = ( ( cc.rgbResult >>  8 ) & 0xFF )/ 255.0f;
	vi_->bgcolor[ 0 ] = ( cc.rgbResult & 0xFF ) / 255.0f;


	return 0;
}

//
int mygl::View_YZ_Plane__()
{
	if( vi_->angle0 == 90.0f &&	vi_->angle1 == 0.0f )
	{
		vi_->angle0 = -90.0f;
		vi_->angle1 = 0.0f;
	}
	else
	{
		vi_->angle0 = 90.0f;
		vi_->angle1 = 0.0f;
	}
	return 0;
}

//
int mygl::View_ZX_Plane__()
{
	if( vi_->angle0 == 90.0f &&	vi_->angle1 == 90.0f )
	{
		vi_->angle0 = -90.0f;
		vi_->angle1 = -90.0f;
	}
	else
	{
		vi_->angle0 = 90.0f;
		vi_->angle1 = 90.0f;
	}
	return 0;
}

//
int mygl::View_XY_Plane__()
{
	if( vi_->angle0 == 0.0f &&	vi_->angle1 == 0.0f )
	{
		vi_->angle0 = 180.0f;
		vi_->angle1 = 0.0f;
	}
	else
	{
		vi_->angle0 = 0.0f;
		vi_->angle1 = 0.0f;
	}
	return 0;
}

// �N���C�A���g�w��̃L�[�_�E�����擾�֐��ɐ؂�ւ���
void mygl::KeydownFunc__( UINT_PTR key, LONG /*x*/, LONG /*y*/ )
{
	switch( key ){
	case 'R':
		Reset_();
		break;

	case 'X':
		View_YZ_Plane__();
		break;
	case 'Y':
		View_ZX_Plane__();
		break;
	case 'Z':
		View_XY_Plane__();
		break;

		//
	case VK_UP:
		vi_->trans[ 1 ] += 1.0f;
		break;
	case VK_DOWN:
		vi_->trans[ 1 ] -= 1.0f;
		break;
	case VK_LEFT:
		vi_->trans[ 0 ] -= 1.0f;
		break;
	case VK_RIGHT:
		vi_->trans[ 0 ] += 1.0f;
		break;

	default:
		break;
	}
	return;
}


// ���j���[�o�[�̏�����
void mygl::InitMenu__()
{
	HMENU hMenu, hFileMenu, hViewMenu, hExecutionMenu, hHelpMenu;

	hMenu			= ::CreateMenu();
	hFileMenu		= ::CreateMenu();
	hViewMenu		= ::CreateMenu();
	hExecutionMenu	= ::CreateMenu();
	hHelpMenu		= ::CreateMenu();

	// File
	scmn::InsertSubMenu( hMenu, hFileMenu, "�t�@�C��(&F)", 0 );
	scmn::InsertItem( hFileMenu, IDM_HOGE_LOAD_3D_DATA, "3D�f�[�^���J��(&O)", 0 );

	scmn::InsertSeparator( hFileMenu, 98 );
	scmn::InsertItem( hFileMenu, IDM_HOGE_EXIT, "�I��(&X)", 99 );

	// View
	scmn::InsertSubMenu( hMenu, hViewMenu, "�\��(&V)", 1 );
	scmn::InsertCheckItem( hViewMenu, IDM_HOGE_VIEW_RESET, "���_������(&R)", 0 );
	scmn::InsertSeparator( hViewMenu, 1 );
	scmn::InsertRadioItem( hViewMenu, IDM_HOGE_PERSPECTIVE_PROJECTION, "���ߊ�����(&P)", 2 );
	scmn::InsertRadioItem( hViewMenu, IDM_HOGE_ORTHOGRAPHIC_PROJECTION, "���ߊ��Ȃ�(&O)", 3 );
	scmn::InsertSeparator( hViewMenu, 4 );
	scmn::InsertItem( hViewMenu, IDM_HOGE_VIEW_YZ_PLANE, "y - z���ʕ\��(&X)", 5 );
	scmn::InsertItem( hViewMenu, IDM_HOGE_VIEW_ZX_PLANE, "z - x���ʕ\��(&Y)", 6 );
	scmn::InsertItem( hViewMenu, IDM_HOGE_VIEW_XY_PLANE, "x - y���ʕ\��(&Z)", 7 );
	scmn::InsertSeparator( hViewMenu, 8 );
	scmn::InsertItem( hViewMenu, IDM_HOGE_CHOOSE_BGCOLOR, "�w�i�F�I��", 9 );

	// Help
	scmn::InsertSubMenu( hMenu, hHelpMenu, "�w���v(&H)", 9 );
	scmn::InsertItem( hHelpMenu, IDM_HOGE_HELP, "�w���v(&H)", 0 );

	::SetMenu( wnd_, hMenu );

	//
//	CheckProjectionFlag__( GLW_PERSPECTIVE_MODE );
	CheckProjectionFlag__( GLW_ORTOGRAPHIC_MODE );

	return;
}


// �`��֐�
void mygl::Mydisp__()
{
	::glPushMatrix();

		// ���S���V�t�g
		::glTranslated( - vi_->center[ 0 ], - vi_->center[ 1 ], - vi_->center[ 2 ] );

		// ���W���`��
		DrawAxes__();

		// �`��
		Draw3D__();

	::glPopMatrix();

	char str_buf[ 256 ];	
	std::sprintf( str_buf, "%s scale:%f", TITLE, vi_->scale );
	::SetWindowText( wnd_, str_buf );

	return;
}

// axes �� axis �̕����`�B�O�̂��߁B
void mygl::DrawAxes__()
{
	::glDisable( GL_LIGHTING );
	::glDisable( GL_TEXTURE_2D );
	::glLineWidth( 2.0f );

	// X
	::glColor3b( 127, 32, 32 );
	::glBegin( GL_LINES );
		::glVertex3f( 0.0f, 0.0f, 0.0f );
		::glVertex3f( 100.0f, 0.0f, 0.0f );
	::glEnd();

	// Y
	::glColor3b( 32, 127, 32 );
	::glBegin( GL_LINES );
		::glVertex3f( 0.0f, 0.0f, 0.0f );
		::glVertex3f( 0.0f, 100.0f, 0.0f );
	::glEnd();

	// Z
	::glColor3b( 32, 32, 127 );
	::glBegin( GL_LINES );
		::glVertex3f( 0.0f, 0.0f, 0.0f );
		::glVertex3f( 0.0f, 0.0f, 100.0f );
	::glEnd();


	return;
}

// ���[�U��`��3D�`��֐�
void mygl::Draw3D__()
{
	//
	int fcvx_size = 4;
	int fc_size = 6;
	float vertex[ 8 ][ 3 ] =
	{
		{   50.0f,   50.0f,   50.0f },
		{ - 50.0f,   50.0f,   50.0f },
		{ - 50.0f, - 50.0f,   50.0f },
		{   50.0f, - 50.0f,   50.0f },
		{   50.0f,   50.0f, - 50.0f },
		{ - 50.0f,   50.0f, - 50.0f },
		{ - 50.0f, - 50.0f, - 50.0f },
		{   50.0f, - 50.0f, - 50.0f }
	};
	float nomal_vec[ 6 ][ 3 ] =
	{
		{   0.0f,   0.0f,   1.0f },
		{   0.0f,   0.0f, - 1.0f },
		{   1.0f,   0.0f,   0.0f },
		{ - 1.0f,   0.0f,   0.0f },
		{   0.0f,   1.0f,   0.0f },
		{   0.0f, - 1.0f,   0.0f },
	};
	int indexed_face[ 6 ][ 4 ] =
	{
		{ 0, 1, 2, 3 },
		{ 7, 6, 5, 4 },
		{ 0, 3, 7, 4 },
		{ 5, 6, 2, 1 },
		{ 0, 4, 5, 1 },
		{ 3, 2, 6, 7 },
	};

	// �ގ�0
	float mat_ambient0[] = { 0.2f, 0.2f, 0.2f, 0.5f };
	float mat_specular0[] = { 0.0f, 0.0f, 0.0f, 0.0f };
	float mat_shininess0[] = { 0.0f };
	float mat_diffuse0[ 6 ][ 4 ] =
	{
		{ 0.5f, 1.0f, 1.0f, 0.0f },
		{ 0.5f, 1.0f, 0.5f, 0.0f },
		{ 1.0f, 0.5f, 1.0f, 0.0f },
		{ 0.5f, 0.5f, 1.0f, 0.0f },
		{ 1.0f, 1.0f, 0.5f, 0.0f },
		{ 1.0f, 0.5f, 0.5f, 0.0f },
	};

	int f, v;

	::glMaterialfv( GL_FRONT, GL_AMBIENT,  mat_ambient0 ); 
	::glMaterialfv( GL_FRONT, GL_SPECULAR, mat_specular0 );
	::glMaterialfv( GL_FRONT, GL_SHININESS,mat_shininess0 );

	::glPushMatrix();
	::glEnable( GL_CULL_FACE );
	::glCullFace( GL_BACK );

	::glEnable( GL_LIGHTING );
	for( f = 0; f < fc_size; f ++ )
	{
		::glMaterialfv( GL_FRONT, GL_DIFFUSE,  mat_diffuse0[ f ] );
		::glNormal3f( vi_->scale * nomal_vec[ f ][ 0 ], vi_->scale * nomal_vec[ f ][ 1 ], vi_->scale * nomal_vec[ f ][ 2 ] );
		::glBegin( GL_POLYGON );
			for( v = 0; v < fcvx_size; v ++ )
			{
				::glVertex3f( vertex[ indexed_face[ f ][ v ] ][ 0 ], vertex[ indexed_face[ f ][ v ] ][ 1 ], vertex[ indexed_face[ f ][ v ] ][ 2 ] );
			}
		::glEnd();
	}
	::glPopMatrix();

	return;
}

/*********************************************************************
	public�����o�֐�
 *********************************************************************/




