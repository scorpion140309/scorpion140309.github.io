#ifndef _GL_VI_H_
#define _GL_VI_H_

//#include <gl/gl.h>

// OpenGL�̐ݒ�
typedef struct glvi
{
	double eye[ 4 ];
	double center[ 4 ];
	float scale;
	float angle0;
	float angle1;
	float trans[ 3 ];

	float bgcolor[ 4 ];
	int v_mode;
	float znear;
	float zfar;

	// ����
	float lmodel_ambient[ 4 ];
	float lmodel_twoside[ 1 ];
	float lmodel_local[ 1 ];
	float light0_ambient[ 4 ];
	float light0_diffuse[ 4 ];
	float light0_specular[ 4 ];
	float light0_position[ 4 ];

	// �ގ�
	float mat_ambient[ 4 ];
	float mat_shininess[ 4 ];
	float mat_specular[ 4 ];
	float mat_diffuse[ 4 ];

	//
	int flag_visible;

} glvi;


#endif	// _GL_VI_H_
