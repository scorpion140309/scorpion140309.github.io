#pragma once


namespace scGetEncodingTest {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Form1 �̊T�v
	///
	/// �x��: ���̃N���X�̖��O��ύX����ꍇ�A���̃N���X���ˑ����邷�ׂĂ� .resx �t�@�C���Ɋ֘A�t����ꂽ
	///          �}�l�[�W ���\�[�X �R���p�C�� �c�[���ɑ΂��� 'Resource File Name' �v���p�e�B��
	///          �ύX����K�v������܂��B���̕ύX���s��Ȃ��ƁA
	///          �f�U�C�i�ƁA���̃t�H�[���Ɋ֘A�t����ꂽ���[�J���C�Y�ς݃��\�[�X�Ƃ��A
	///          ���������݂ɗ��p�ł��Ȃ��Ȃ�܂��B
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: �����ɃR���X�g���N�^ �R�[�h��ǉ����܂�
			//
		}

	protected:
		/// <summary>
		/// �g�p���̃��\�[�X�����ׂăN���[���A�b�v���܂��B
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	protected: System::Windows::Forms::NumericUpDown^  numericUpDown_index;
	protected: System::Windows::Forms::Label^  label_index;
	protected: System::Windows::Forms::Button^  button_run_stop;
	protected: System::Windows::Forms::TextBox^  TextBox_enc_list;

	protected: System::ComponentModel::BackgroundWorker^  backgroundWorker_enc_check;
	private: System::Windows::Forms::ToolStripProgressBar^  toolStripProgressBar_enc_check;
	protected: 

	protected: System::Windows::Forms::StatusStrip^  statusStrip_get_enc;
	private: 
	protected: 

	private: 

	protected: 

	private:
		/// <summary>
		/// �K�v�ȃf�U�C�i�ϐ��ł��B
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// �f�U�C�i �T�|�[�g�ɕK�v�ȃ��\�b�h�ł��B���̃��\�b�h�̓��e��
		/// �R�[�h �G�f�B�^�ŕύX���Ȃ��ł��������B
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Form1::typeid));
			this->numericUpDown_index = (gcnew System::Windows::Forms::NumericUpDown());
			this->label_index = (gcnew System::Windows::Forms::Label());
			this->button_run_stop = (gcnew System::Windows::Forms::Button());
			this->TextBox_enc_list = (gcnew System::Windows::Forms::TextBox());
			this->backgroundWorker_enc_check = (gcnew System::ComponentModel::BackgroundWorker());
			this->toolStripProgressBar_enc_check = (gcnew System::Windows::Forms::ToolStripProgressBar());
			this->statusStrip_get_enc = (gcnew System::Windows::Forms::StatusStrip());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericUpDown_index))->BeginInit();
			this->statusStrip_get_enc->SuspendLayout();
			this->SuspendLayout();
			// 
			// numericUpDown_index
			// 
			this->numericUpDown_index->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Right));
			this->numericUpDown_index->Location = System::Drawing::Point(540, 64);
			this->numericUpDown_index->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {65536, 0, 0, 0});
			this->numericUpDown_index->Name = L"numericUpDown_index";
			this->numericUpDown_index->Size = System::Drawing::Size(72, 19);
			this->numericUpDown_index->TabIndex = 8;
			this->numericUpDown_index->TextAlign = System::Windows::Forms::HorizontalAlignment::Right;
			// 
			// label_index
			// 
			this->label_index->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Right));
			this->label_index->AutoSize = true;
			this->label_index->Location = System::Drawing::Point(538, 49);
			this->label_index->Name = L"label_index";
			this->label_index->Size = System::Drawing::Size(32, 12);
			this->label_index->TabIndex = 7;
			this->label_index->Text = L"index";
			// 
			// button_run_stop
			// 
			this->button_run_stop->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Right));
			this->button_run_stop->Location = System::Drawing::Point(537, 19);
			this->button_run_stop->Name = L"button_run_stop";
			this->button_run_stop->Size = System::Drawing::Size(75, 23);
			this->button_run_stop->TabIndex = 6;
			this->button_run_stop->Text = L"&Run";
			this->button_run_stop->UseVisualStyleBackColor = true;
			this->button_run_stop->Click += gcnew System::EventHandler(this, &Form1::button_run_stop_Click);
			// 
			// TextBox_enc_list
			// 
			this->TextBox_enc_list->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Bottom) 
				| System::Windows::Forms::AnchorStyles::Left) 
				| System::Windows::Forms::AnchorStyles::Right));
			this->TextBox_enc_list->Font = (gcnew System::Drawing::Font(L"�l�r �S�V�b�N", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(128)));
			this->TextBox_enc_list->Location = System::Drawing::Point(13, 19);
			this->TextBox_enc_list->Multiline = true;
			this->TextBox_enc_list->Name = L"TextBox_enc_list";
			this->TextBox_enc_list->ScrollBars = System::Windows::Forms::ScrollBars::Both;
			this->TextBox_enc_list->Size = System::Drawing::Size(518, 558);
			this->TextBox_enc_list->TabIndex = 5;
			this->TextBox_enc_list->WordWrap = false;
			this->TextBox_enc_list->KeyDown += gcnew System::Windows::Forms::KeyEventHandler(this, &Form1::TextBox_enc_list_KeyDown);
			// 
			// backgroundWorker_enc_check
			// 
			this->backgroundWorker_enc_check->DoWork += gcnew System::ComponentModel::DoWorkEventHandler(this, &Form1::backgroundWorker_enc_check_DoWork);
			this->backgroundWorker_enc_check->RunWorkerCompleted += gcnew System::ComponentModel::RunWorkerCompletedEventHandler(this, &Form1::backgroundWorker_enc_check_RunWorkerCompleted);
			this->backgroundWorker_enc_check->ProgressChanged += gcnew System::ComponentModel::ProgressChangedEventHandler(this, &Form1::backgroundWorker_enc_check_ProgressChanged);
			// 
			// toolStripProgressBar_enc_check
			// 
			this->toolStripProgressBar_enc_check->Maximum = 65535;
			this->toolStripProgressBar_enc_check->Name = L"toolStripProgressBar_enc_check";
			this->toolStripProgressBar_enc_check->Size = System::Drawing::Size(600, 16);
			// 
			// statusStrip_get_enc
			// 
			this->statusStrip_get_enc->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) {this->toolStripProgressBar_enc_check});
			this->statusStrip_get_enc->Location = System::Drawing::Point(0, 580);
			this->statusStrip_get_enc->Name = L"statusStrip_get_enc";
			this->statusStrip_get_enc->Size = System::Drawing::Size(624, 22);
			this->statusStrip_get_enc->TabIndex = 9;
			this->statusStrip_get_enc->Text = L"statusStrip_get_enc";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 12);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(624, 602);
			this->Controls->Add(this->statusStrip_get_enc);
			this->Controls->Add(this->numericUpDown_index);
			this->Controls->Add(this->label_index);
			this->Controls->Add(this->button_run_stop);
			this->Controls->Add(this->TextBox_enc_list);
			this->Icon = (cli::safe_cast<System::Drawing::Icon^  >(resources->GetObject(L"$this.Icon")));
			this->Name = L"Form1";
			this->Text = L"scGetEncodingTest";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			this->Shown += gcnew System::EventHandler(this, &Form1::Form1_Shown);
			this->Resize += gcnew System::EventHandler(this, &Form1::Form1_Resize);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericUpDown_index))->EndInit();
			this->statusStrip_get_enc->ResumeLayout(false);
			this->statusStrip_get_enc->PerformLayout();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion

	private: System::Void Form1_Load(System::Object^  , System::EventArgs^  );
	private: System::Void Form1_Shown(System::Object^  , System::EventArgs^  );
	private: System::Void Form1_Resize(System::Object^  , System::EventArgs^  );
	private: System::Void button_run_stop_Click(System::Object^  , System::EventArgs^  );
	private: System::Void TextBox_enc_list_KeyDown(System::Object^  , System::Windows::Forms::KeyEventArgs^  e);


	private: System::Void backgroundWorker_enc_check_DoWork(System::Object^  sender, System::ComponentModel::DoWorkEventArgs^  e);
	private: System::Void backgroundWorker_enc_check_ProgressChanged(System::Object^  sender, System::ComponentModel::ProgressChangedEventArgs^  e);
	private: System::Void backgroundWorker_enc_check_RunWorkerCompleted(System::Object^  sender, System::ComponentModel::RunWorkerCompletedEventArgs^  e);

};
}

