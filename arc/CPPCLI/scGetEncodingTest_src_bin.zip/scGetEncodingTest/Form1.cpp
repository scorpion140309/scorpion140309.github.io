#include "Form1.h"

//
ref class STR_BUTTON
{
public:
	static System::String ^RUN;
	static System::String ^STOP;
private:
	static STR_BUTTON()
	{
		RUN = gcnew System::String( "&Run" );
		STOP = gcnew System::String( "&Stop" );
	}
};


// �X���b�h�Z�[�t�p
delegate void myDelegateTxt(
	System::Windows::Forms::TextBox ^TextBox_msg,
	System::String ^str_append
);
delegate void myDelegateProgBar(
	System::Windows::Forms::ToolStripProgressBar ^prog_bar,
	System::Windows::Forms::NumericUpDown ^index,
	int progress
);
ref struct DLGT
{
	void AppendEnc(
		System::Windows::Forms::TextBox ^TextBox_msg,
		System::String ^str_append
		)
	{
		if( str_append != nullptr ){
			TextBox_msg->AppendText( str_append );
		}
		else{
			TextBox_msg->Clear();
		}
	}
	void ShowProgBar(
		System::Windows::Forms::ToolStripProgressBar^ prog_bar,
		System::Windows::Forms::NumericUpDown ^index,
		int progress
		)
	{
		prog_bar->Value = progress;
		index->Value = progress;
	}
};



System::Void scGetEncodingTest::Form1::backgroundWorker_enc_check_DoWork(System::Object^  , System::ComponentModel::DoWorkEventArgs^  )
{
	// �X���b�h�Z�[�t�p
	DLGT ^MyDLGT = gcnew DLGT();
	myDelegateTxt ^pAppendEnc = gcnew myDelegateTxt( MyDLGT, &DLGT::AppendEnc );
	myDelegateProgBar ^pShowProgBar = gcnew myDelegateProgBar( MyDLGT, &DLGT::ShowProgBar );
	System::IAsyncResult ^result_end_list, ^result_prog_bar, ^result_index;

	const int MAX = 65536;
	System::Text::Encoding ^enc;
	int index;
	int i;


	// �J�n�ʒu
	index = static_cast< int >( this->numericUpDown_index->Value );

	// �N���A
	if( index == 0 ){
		result_end_list = this->BeginInvoke( pAppendEnc,	this->TextBox_enc_list, nullptr );
		this->EndInvoke( result_end_list );
	}

	for( i = index; i < MAX; i ++ )
	{
		if( this->button_run_stop->Text == STR_BUTTON::RUN )
		{
			result_prog_bar = this->BeginInvoke( pShowProgBar, this->toolStripProgressBar_enc_check, this->numericUpDown_index, i );
			this->EndInvoke( result_prog_bar );
			break;
		}
		if( ( i & 0xFF ) == 0xFF )
		{
			result_index = this->BeginInvoke( pShowProgBar, this->toolStripProgressBar_enc_check, this->numericUpDown_index, i );
			this->EndInvoke( result_index );
		}
		try
		{
			enc = System::Text::Encoding::GetEncoding(i);
			result_end_list = this->BeginInvoke( pAppendEnc, this->TextBox_enc_list, i.ToString() + "	" + enc->WebName + "	" + enc->EncodingName + "\r\n" );
			this->EndInvoke( result_end_list );
		}
		catch(...)
		{
		}
	}
}

System::Void scGetEncodingTest::Form1::backgroundWorker_enc_check_ProgressChanged(System::Object^  , System::ComponentModel::ProgressChangedEventArgs^  )
{
}

System::Void scGetEncodingTest::Form1::backgroundWorker_enc_check_RunWorkerCompleted(System::Object^  , System::ComponentModel::RunWorkerCompletedEventArgs^  )
{
	//
	this->button_run_stop->Text = STR_BUTTON::RUN;
	if( this->numericUpDown_index->Value == 65535 )
	{
		 System::Windows::Forms::MessageBox::Show( "RunWorkerCompleted", "Completed!!", System::Windows::Forms::MessageBoxButtons::OK, System::Windows::Forms::MessageBoxIcon::Information );
		this->numericUpDown_index->Value = 0;
		this->toolStripProgressBar_enc_check->Value = 0;
	}
}


System::Void scGetEncodingTest::Form1::Form1_Load(System::Object^  , System::EventArgs^  )
{
	//this->button_run_stop->Focus();
	//TextBox_msg->
}

System::Void scGetEncodingTest::Form1::Form1_Shown(System::Object^  , System::EventArgs^  )
{
	this->button_run_stop->Focus();
}

System::Void scGetEncodingTest::Form1::Form1_Resize(System::Object^  , System::EventArgs^  )
{
	const int MARGIN = 32;
	const int HEIGHT = 16;
	if( this->Width >= MARGIN )
	{
		this->toolStripProgressBar_enc_check->Size = System::Drawing::Size( this->Width - MARGIN, HEIGHT );
	}
}


System::Void scGetEncodingTest::Form1::button_run_stop_Click(System::Object^  , System::EventArgs^  )
{
	if( this->button_run_stop->Text == STR_BUTTON::RUN ){
		// �X���b�h�J�n
		this->backgroundWorker_enc_check->RunWorkerAsync();
		this->button_run_stop->Text = STR_BUTTON::STOP;
	}
	else{
		this->button_run_stop->Text = STR_BUTTON::RUN;
	}
}

System::Void scGetEncodingTest::Form1::TextBox_enc_list_KeyDown(System::Object^  , System::Windows::Forms::KeyEventArgs^  e)
{
	System::Windows::Forms::Keys key_ctrl, key_A;
	key_ctrl	= System::Windows::Forms::Keys::Control;
	key_A		= System::Windows::Forms::Keys::A;
	if( ( e->Modifiers & key_ctrl ) == key_ctrl && e->KeyCode == key_A )
	{
		this->TextBox_enc_list->SelectAll();
	}
}

