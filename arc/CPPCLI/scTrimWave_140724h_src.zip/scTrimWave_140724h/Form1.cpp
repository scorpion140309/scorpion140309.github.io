#include "Form1.h"
#include <scWaveFormat.h>
#include <windows.h>

/////////////////////////////////////////////////////////////////////////////////////
// static �񃁃��o�֐�
/////////////////////////////////////////////////////////////////////////////////////

// System::String^ �� const char * �ɕϊ�����
static const char * sttc_Str2CstCharPtr( System::String ^str )
{
	const char *cst_char_ptr;
	cst_char_ptr = static_cast< const char * >(
		System::Runtime::InteropServices::Marshal::StringToHGlobalAnsi( str ).ToPointer()
	);
	return cst_char_ptr;
}

// �ҏW���e�𕶎���ɕϊ�����
static System::String^ sttc_MakeItemString( System::String ^arg_input, System::String ^arg_output, double arg_start_sec, double arg_length_sec )
{
	System::String ^str_item;
	str_item = gcnew System::String( "\"" + arg_input + "\" \"" + arg_output + "\" \"" + arg_start_sec + "\" \"" + arg_length_sec + "\"" );
	return str_item;
}

// �ҏW���e�𕶎���ɕϊ�����
static System::String^ sttc_MakeItemString_for_csv( System::String ^arg_input, System::String ^arg_output, double arg_start_sec, double arg_length_sec )
{
	System::String ^str_item;
	str_item = gcnew System::String( "\"" + arg_input + "\",\"" + arg_output + "\"," + arg_start_sec + "," + arg_length_sec );
	return str_item;
}

// 1��Wave�t�@�C�����o��
static int sttc_TrimWaveSingle( WAVE_TRIM_INFO ^ arg_wti, System::String^ arg_str_folder )
{
	int result = -1;
	scWaveFormat wave;
	System::String ^str_fullpath;
	const char *p_inputfile;
	int check;

	str_fullpath = arg_str_folder + "\\" + arg_wti->input;
	p_inputfile = sttc_Str2CstCharPtr( str_fullpath );
	check = wave.Load( p_inputfile );
	if( check == 0 )
	{
		scWaveFormat trim_wave;
		scWaveFormat wave_hoge;
		str_fullpath = arg_str_folder + "\\" + arg_wti->output;
		p_inputfile = sttc_Str2CstCharPtr( str_fullpath );

//		result = wave.Trim( p_inputfile, arg_wti->start_sec, arg_wti->length_sec );

		wave.CopyTo( &wave_hoge );
		wave_hoge.Trim( arg_wti->start_sec, arg_wti->length_sec );
		result = wave_hoge.Save( p_inputfile );

/*		wave.CopyTo( &wave_hoge );
		wave_hoge.Bit08();
		str_fullpath = arg_str_folder + "\\" + "8bit.wav";
		p_inputfile = sttc_Str2CstCharPtr( str_fullpath );
		result = wave_hoge.Save( p_inputfile );*/

//		wave.Save( "F:/projects_C++CLI/scTrimWave/_data_/toeic_5_1/fuga.wav" );
	}
	return result;
}


/////////////////////////////////////////////////////////////////////////////////////
// �蓮�쐬
/////////////////////////////////////////////////////////////////////////////////////

// �v���r���[��ʂ̕`��
System::Void scTrimWave::Form1::RefreshPreview__()
{
	int num;
	
	num = this->listBox_trim_wave->Items->Count;
	if( num < 0 )
	{
		num = 0;
	}
	this->numericUpDown_file_num->Value = num;

	if( this->numericUpDown_file_no->Value > this->numericUpDown_file_num->Value )
	{
		this->numericUpDown_file_no->Value = this->numericUpDown_file_num->Value;
	}

	return;
}

// �s�N�`���{�b�N�X�`��
System::Void scTrimWave::Form1::DrawPictureBox__( System::Windows::Forms::PictureBox ^arg_picture_box, scWaveFormat *arg_wave, int arg_channel, double arg_start_sec, double arg_length_sec )
{
	System::Drawing::Bitmap ^bmp;
	System::Drawing::Graphics ^graph;
	System::Drawing::Pen ^pen;
	System::Drawing::SolidBrush ^brush;
	System::Drawing::Color color;
	int img_width, img_height;
	int graph_y_min, graph_y_max;
	double time_step;
	int volume_min = -100, volume_max = 100;
	int area_s, area_e;
	int x;

	bmp = static_cast< System::Drawing::Bitmap ^ >( arg_picture_box->Image );
	graph = System::Drawing::Graphics::FromImage( bmp );

	img_width	= arg_picture_box->Image->Width;
	img_height	= arg_picture_box->Image->Height;
	time_step	= arg_wave->Length_Sec() / img_width;

	area_s = static_cast< int >( ( ( img_width - 1 ) * arg_start_sec ) / arg_wave->Length_Sec() );
	if( area_s < 0 )
	{
		area_s = 0;
	}
	else if( area_s >= img_width )
	{
		area_s = img_width - 1;
	}
	area_e = static_cast< int >( ( ( img_width - 1 ) * ( arg_start_sec + arg_length_sec ) ) / arg_wave->Length_Sec() );
	if( area_e < 0 )
	{
		area_e = 0;
	}
	else if( area_e >= img_width )
	{
		area_e = img_width - 1;
	}

	// �؂�o���̈�
	brush = gcnew System::Drawing::SolidBrush( System::Drawing::Color::FromArgb( 0xFF008080 ) );
	graph->FillRectangle( brush, area_s, 0, ( area_e - area_s ) + 1, img_height - 1 );

	// �O�̈�
	pen = gcnew System::Drawing::Pen( System::Drawing::Color::White );
	pen->Width = 1;

	try
	{
		for( x = 0; x < img_width; x ++ )
		{
// @@@
if( x >= img_width / 2 )
{
	graph_y_min = -1000;
}
			arg_wave->VolumeMinMax( x * time_step, time_step, arg_channel, &volume_min, &volume_max );

			graph_y_min = ( img_height * ( volume_min + 32768 ) / 65535 );
			graph_y_max = ( img_height * ( volume_max + 32768 ) / 65535 );
			graph->DrawLine( pen, x, graph_y_min, x, graph_y_max );

		}
	}
	catch( System::Exception ^ex )
	{
		System::Windows::Forms::MessageBox::Show(
			ex->Message, "Error",
			System::Windows::Forms::MessageBoxButtons::OK,
			System::Windows::Forms::MessageBoxIcon::Error,
			System::Windows::Forms::MessageBoxDefaultButton::Button1
		);
	}

	return;
}

// �O���t�`��
System::Void scTrimWave::Form1::DrawGraph__()
{
	if( this->pictureBox_wave_0->Width > 0 && this->pictureBox_wave_1->Width > 0 )
	{
		// ���w�i�ŏ�����
		cli::array< System::Windows::Forms::PictureBox ^ > ^ary_picture_box = 
		{
			this->pictureBox_wave_0, this->pictureBox_wave_1
		};
		for each( System::Windows::Forms::PictureBox ^ pic_box in ary_picture_box )
		{
			// �O���t�X�V
			pic_box->Image = gcnew System::Drawing::Bitmap(
				pic_box->Width, pic_box->Height,
				System::Drawing::Imaging::PixelFormat::Format24bppRgb
			);
		}

		if( this->listBox_trim_wave->SelectedIndex >= 0 )
		{

			int c;
//			for each( System::Windows::Forms::PictureBox ^ pic_box in ary_picture_box )
			for( c = 0; c < 2; c ++ )
			{
				scWaveFormat wave;
				int box_width, box_height;
				int index;
				System::String ^str_fullpath;
				const char *p_wavefilename;
				int check;

				box_width = ary_picture_box[ c ]->Image->Width;
				box_height = ary_picture_box[ c ]->Image->Height;

				if( box_width > 0 && box_height > 0 )
				{
					index = System::Convert::ToInt32( this->listBox_trim_wave->SelectedIndex );

					str_fullpath = this->textBox_WorkingDir->Text + "\\" + this->ary_trim_info[ index ]->input;
					p_wavefilename = sttc_Str2CstCharPtr( str_fullpath  );
					check = wave.Load( p_wavefilename );
					if( check == 0 )
					{
						DrawPictureBox__( ary_picture_box[ c ], &wave, c, this->ary_trim_info[ index ]->start_sec, this->ary_trim_info[ index ]->length_sec );
					}
				}

				if( wave.Channel() < 2 )
				{
					break;
				}
			}
		}
	}
	return;
}


// �ҏW���X�g�ǂݍ���
System::Void scTrimWave::Form1::LoadList__( System::String ^arg_str_file )
{
	System::String ^str_file = nullptr;

	if( arg_str_file != nullptr )
	{
		str_file = arg_str_file;
	}
	else
	{
		System::Windows::Forms::OpenFileDialog ^dlg_open;
		System::Windows::Forms::DialogResult dlg_result;

		dlg_open = gcnew System::Windows::Forms::OpenFileDialog;
		dlg_open->Filter = L"�ݒ�t�@�C��(*.csv;*.txt)|*.csv";
		dlg_result = dlg_open->ShowDialog();
		if( dlg_result == System::Windows::Forms::DialogResult::OK )
		{
			str_file = dlg_open->FileName;

		}
	}

	if( str_file != nullptr )
	{
		cli::array< System::String^ > ^ary_lines;
		cli::array< System::String^ > ^ary_contents;
		cli::array< wchar_t, 1 > ^ary_separator = { ',', '\t' };
		System::String ^str_input;
		System::String ^str_output;
		double start_sec;
		double length_sec;

		ary_lines = System::IO::File::ReadAllLines( str_file, System::Text::Encoding::GetEncoding( L"SHIFT_JIS" ) );

		if( ary_lines->Length > 0 )
		{
			int i;
			this->ary_trim_info = gcnew cli::array< WAVE_TRIM_INFO^ >( ary_lines->Length );

			this->listBox_trim_wave->Items->Clear();
			i = 0;
			for each( System::String ^ str_1_line in ary_lines )
			{
				System::String ^str_item;

				str_item = gcnew System::String( "" );
				ary_contents = str_1_line->Split( ary_separator );
				if( ary_contents->Length > 3 )
				{
					WAVE_TRIM_INFO ^wti;

					str_input	= ary_contents[ 0 ]->Replace( "\"", "" );
					str_output	= ary_contents[ 1 ]->Replace( "\"", "" );
					start_sec	= System::Convert::ToDouble( ary_contents[ 2 ] );
					length_sec	= System::Convert::ToDouble( ary_contents[ 3 ] );
					str_item = sttc_MakeItemString( str_input, str_output, start_sec, length_sec );

					wti = gcnew WAVE_TRIM_INFO( str_input, str_output, start_sec, length_sec );
					this->listBox_trim_wave->Items->Add( str_item );
					this->ary_trim_info[ i ] = wti;
					i ++;
				}
			}
		}

		this->RefreshPreview__();
	}
}

// �ҏW���X�g�ۑ�
System::Void scTrimWave::Form1::SaveList__()
{
	try
	{
		if( this->listBox_trim_wave->Items->Count> 0 )
		{
			System::Windows::Forms::SaveFileDialog ^dlg_save;
			System::Windows::Forms::DialogResult dlg_result;

			dlg_save = gcnew System::Windows::Forms::SaveFileDialog;
			dlg_save->Filter = L"�ݒ�t�@�C��(*.csv;*.txt)|*.csv";
			dlg_result = dlg_save->ShowDialog();
			if( dlg_result == System::Windows::Forms::DialogResult::OK )
			{
				System::IO::StreamWriter^ myStream;
				System::String ^str_line;
				int i;

				myStream = gcnew System::IO::StreamWriter( dlg_save->FileName, false, System::Text::Encoding::GetEncoding( "SHIFT_JIS" ) );

				for( i = 0; i < this->listBox_trim_wave->Items->Count; i ++ )
				{
					str_line = sttc_MakeItemString_for_csv(
						this->ary_trim_info[ i ]->input,
						this->ary_trim_info[ i ]->output,
						this->ary_trim_info[ i ]->start_sec,
						this->ary_trim_info[ i ]->length_sec
					);
					if( str_line->Length ){
						myStream->WriteLine( str_line );
					}
				}

				// �t�@�C�������
				myStream->Close();

			}
		}
	}
	catch( System::Exception ^ex )
	{
		System::Windows::Forms::MessageBox::Show(
			ex->Message, "Error",
			System::Windows::Forms::MessageBoxButtons::OK,
			System::Windows::Forms::MessageBoxIcon::Error,
			System::Windows::Forms::MessageBoxDefaultButton::Button1
		);
	}

	return;
}



// ���s
System::Void scTrimWave::Form1::TrimWaveFiles__()
{
	if( this->listBox_trim_wave->Items->Count > 0 )
	{
		for each( WAVE_TRIM_INFO ^ wti in this->ary_trim_info )
		{
			sttc_TrimWaveSingle( wti, this->textBox_WorkingDir->Text );
		}

	}
	return;
}

/////////////////////////////////////////////////////////////////////////////////////
// �t�H�[���f�U�C�i����(BackgroundWoker)
/////////////////////////////////////////////////////////////////////////////////////

System::Void scTrimWave::Form1::backgroundWorker_TrimWave_DoWork(System::Object^  , System::ComponentModel::DoWorkEventArgs^  )
{
	try
	{
		TrimWaveFiles__();
	}
	catch( System::Exception ^ex )
	{
		System::Windows::Forms::MessageBox::Show(
			ex->Message, "Error",
			System::Windows::Forms::MessageBoxButtons::OK,
			System::Windows::Forms::MessageBoxIcon::Error,
			System::Windows::Forms::MessageBoxDefaultButton::Button1
		);
	}

}

System::Void scTrimWave::Form1::backgroundWorker_TrimWave_ProgressChanged(System::Object^  , System::ComponentModel::ProgressChangedEventArgs^  )
{
}

System::Void scTrimWave::Form1::backgroundWorker_TrimWave_RunWorkerCompleted(System::Object^  , System::ComponentModel::RunWorkerCompletedEventArgs^  )
{
	this->groupBox_trim_list->Enabled = true;
	this->groupBox_preview->Enabled = true;
	this->button_exe->Enabled = true;
}



/////////////////////////////////////////////////////////////////////////////////////
// �t�H�[���f�U�C�i����
/////////////////////////////////////////////////////////////////////////////////////

// �t�H�[����ǂݍ��ގ��ɔ����B
System::Void scTrimWave::Form1::Form1_Load(System::Object^  , System::EventArgs^  )
{
#ifdef _DEBUG
//	this->textBox_WorkingDir->Text = "F:/projects_C++CLI/scTrimWave/trim_wave.txt";
#endif
//	System::Data::DataColumn
//	this->textBox_WorkingDir->Text = "F:/projects_C++CLI/scTrimWave";
//	System::Windows::Forms::DataGrid

	//
	this->DrawGraph__();

}

// �e�X�g
System::Void scTrimWave::Form1::TrimWaveTest__()
{
	if( this->listBox_trim_wave->SelectedIndex >= 0 )
	{
		int index;
		System::String ^str_item;

		index = this->listBox_trim_wave->SelectedIndex;
		this->ary_trim_info[ index ]->start_sec = System::Convert::ToDouble( this->numericUpDown_start->Value );
		this->ary_trim_info[ index ]->length_sec = System::Convert::ToDouble( this->numericUpDown_length->Value );

		str_item = sttc_MakeItemString(
			this->ary_trim_info[ index ]->input,
			this->ary_trim_info[ index ]->output,
			this->ary_trim_info[ index ]->start_sec,
			this->ary_trim_info[ index ]->length_sec
		);
		this->listBox_trim_wave->Items[ index ] = str_item;
		this->DrawGraph__();
	}
}


// button
System::Void scTrimWave::Form1::button_something_Click(System::Object^  sender, System::EventArgs^  )
{
	try
	{
		// �ݒ�ǂݍ���
		if( sender->Equals( this->button_setting ) )
		{
			LoadList__( nullptr );
		}
		// �t�H���_�w��
		else if( sender->Equals( this->button_WorkingDir ) )
		{
			System::Windows::Forms::FolderBrowserDialog ^dlg_folder;
			System::Windows::Forms::DialogResult dlg_result;

			dlg_folder = gcnew System::Windows::Forms::FolderBrowserDialog();
			dlg_result = dlg_folder->ShowDialog();
			if( dlg_result == System::Windows::Forms::DialogResult::OK )
			{
				this->textBox_WorkingDir->Text = dlg_folder->SelectedPath;
			}
		}
		// �ݒ�ۑ�
		else if( sender->Equals( this->button_setting_save ) )
		{
			SaveList__();
		}
		// �N���A
		else if( sender->Equals( this->button_clear ) )
		{
			if( this->ary_trim_info != nullptr && this->ary_trim_info->Length > 0 )
			{
				System::Array::Clear( this->ary_trim_info, 0, this->ary_trim_info->Length );
			}
			if( this->listBox_trim_wave->Items->Count > 0 )
			{
				this->listBox_trim_wave->Items->Clear();
			}
			DrawGraph__();
		}
		// �ݒ�X�V(1�A�C�e��)
		else if( sender->Equals( this->button_update ) )
		{
			TrimWaveTest__();
		}
		// ����
		else if( sender->Equals( this->button_test_wave ) )
		{
			int index;
			index = this->listBox_trim_wave->SelectedIndex;
			if( index > -1 )
			{
				int result;
				result = sttc_TrimWaveSingle( this->ary_trim_info[ index ], this->textBox_WorkingDir->Text );
				if( result == 0 )
				{
					System::Diagnostics::Process::Start( this->textBox_WorkingDir->Text + "\\" + this->ary_trim_info[ index ]->output );
				}
			}
		}
		//
		else if( sender->Equals( this->button_exe ) )
		{
			//
			this->groupBox_trim_list->Enabled = false;
			this->groupBox_preview->Enabled = false;
			this->button_exe->Enabled = false;

			// �X���b�h�J�n
			this->backgroundWorker_TrimWave->RunWorkerAsync();
		}
	}
	catch( System::Exception ^ex )
	{
		System::Windows::Forms::MessageBox::Show(
			ex->Message, "Error",
			System::Windows::Forms::MessageBoxButtons::OK,
			System::Windows::Forms::MessageBoxIcon::Error,
			System::Windows::Forms::MessageBoxDefaultButton::Button1
		);
	}
}

// �E�B���h�E�T�C�Y�ύX
System::Void scTrimWave::Form1::Form1_SizeChanged(System::Object^  , System::EventArgs^  )
{
	this->DrawGraph__();
}

// �h���b�O���̃J�[�\������������
System::Void scTrimWave::Form1::textBox_WorkingDir_DragEnter(System::Object^  , System::Windows::Forms::DragEventArgs^  e)
{
	// �h���b�v����悤�Ƃ��Ă���f�[�^���A�t�@�C���̎������󂯕t����
	if( e->Data->GetDataPresent( System::Windows::Forms::DataFormats::FileDrop ) )
	{
		e->Effect = System::Windows::Forms::DragDropEffects::All;
	}
	else{
		e->Effect = System::Windows::Forms::DragDropEffects::None;
	}
}

// �h���b�v���ꂽ��
System::Void scTrimWave::Form1::textBox_WorkingDir_DragDrop(System::Object^  sender, System::Windows::Forms::DragEventArgs^  e)
{
	cli::array< System::String^ >^ ary_str;
	System::String ^str_dir;

	// �h���b�v���ꂽ���̓t�@�C�����o�̓t�@�C���̃p�X������ɕϊ�
	ary_str = static_cast< cli::array<System::String^>^ >(
		e->Data->GetData( System::Windows::Forms::DataFormats::FileDrop, false )
	);

	// ��ƃf�B���N�g��
	if( sender->Equals( this->textBox_WorkingDir ) )
	{
		bool flag_dir;

		flag_dir = System::IO::Directory::Exists( ary_str[ 0 ] );
		if( flag_dir == true )
		{
			str_dir = ary_str[ 0 ];
		}
		else
		{
			str_dir = System::IO::Path::GetDirectoryName( ary_str[ 0 ] );
		}
		this->textBox_WorkingDir->Text = str_dir;
	}
	// ���X�g�{�b�N�X
	else if( sender->Equals( this->listBox_trim_wave ) )
	{
		LoadList__( ary_str[ 0 ] );
		if( this->textBox_WorkingDir->Text == "" )
		{
			this->textBox_WorkingDir_DragDrop( this->textBox_WorkingDir, e );
		}
	}
}


// �v���r���[�ΏەύX
System::Void scTrimWave::Form1::listBox_trim_wave_SelectedIndexChanged(System::Object^  , System::EventArgs^  )
{
	if( this->listBox_trim_wave->SelectedIndex >= 0 )
	{
		int index;

		index = this->listBox_trim_wave->SelectedIndex;
		this->numericUpDown_file_no->Value	= System::Convert::ToDecimal( index + 1 );
		this->numericUpDown_start->Value	= System::Convert::ToDecimal( this->ary_trim_info[ index ]->start_sec );
		this->numericUpDown_length->Value	= System::Convert::ToDecimal( this->ary_trim_info[ index ]->length_sec );

		DrawGraph__();
	}
}

// �L�[�v���X
System::Void scTrimWave::Form1::numericUpDown_something_KeyPress(System::Object^  , System::Windows::Forms::KeyPressEventArgs^  e)
{
	if( e->KeyChar == 13 )
	{
		TrimWaveTest__();
	}
}

