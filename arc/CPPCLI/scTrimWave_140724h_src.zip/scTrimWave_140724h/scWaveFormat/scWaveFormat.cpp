//
//
//
#define _CRT_SECURE_NO_DEPRECATE

#include "scWaveFormat.h"
#include <cstdio>
//#include <cstring>
#include <my_null.h>



/////////////////////////////////////////////////////////////////////////////////
// �\�z�E�j��
/////////////////////////////////////////////////////////////////////////////////

// �R���X�g���N�^
scWaveFormat::scWaveFormat()
{
	Init__();
}
// �R���X�g���N�^
scWaveFormat::scWaveFormat( const char *arg_wavefilename )
{
	Init__();
	ReadWaveFile__( arg_wavefilename );
}
// �R�s�[�R���X�g���N�^
scWaveFormat::scWaveFormat( const scWaveFormat & rhs )
{
	int check;
	check = this->Alloc( rhs.channel__, rhs.bit__, rhs.rate__, rhs.wave_sampling_num__ );
	if( check == 0 )
	{
		int i;
		for( i = 0; i < rhs.wave_sampling_num__; i ++ )
		{
			this->wave_buf__[ i ] = rhs.wave_buf__[ i ];
		}
	}
}
// �f�X�g���N�^
scWaveFormat::~scWaveFormat()
{
	::operator delete( wave_buf__ );
	wave_buf__ = my_null;
}


/////////////////////////////////////////////////////////////////////////////////
// �\�z�E�j��(�����܂�)
/////////////////////////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////////////////////////
// ���Z�q
/////////////////////////////////////////////////////////////////////////////////

// @@@
// ������Z�q
scWaveFormat & scWaveFormat::operator = ( const scWaveFormat & rhs )
{
	if( this->wave_buf__ == rhs.wave_buf__ )
	{
		return *this;
	}
	int check;
	check = this->Alloc( rhs.channel__, rhs.bit__, rhs.rate__, rhs.wave_sampling_num__ );
	if( check == 0 )
	{
		int sound_data_bytesize;
		int i;

		sound_data_bytesize = rhs.wave_sampling_num__ * rhs.block__;
		for( i = 0; i < sound_data_bytesize; i ++ )
		{
			this->wave_buf__[ i ] = rhs.wave_buf__[ i ];
		}

	}
	return *this;
}

/////////////////////////////////////////////////////////////////////////////////
// ���Z�q(�����܂�)
/////////////////////////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////////////////////////
// static �����o�֐�
/////////////////////////////////////////////////////////////////////////////////

void scWaveFormat::Init__()
{
	// header
	riff_ary__[ 0 ]	= 'R';
	riff_ary__[ 1 ]	= 'I';
	riff_ary__[ 2 ]	= 'F';
	riff_ary__[ 3 ]	= 'F';

	total_size__	= 44 - 8;

	wave_ary__[ 0 ]	= 'W';
	wave_ary__[ 1 ]	= 'A';
	wave_ary__[ 2 ]	= 'V';
	wave_ary__[ 3 ]	= 'E';

	fmt_ary__[ 0 ]	= 'f';
	fmt_ary__[ 1 ]	= 'm';
	fmt_ary__[ 2 ]	= 't';
	fmt_ary__[ 3 ]	= ' ';

	fmt_size__		= 16;

	format__		= 1;

	channel__		= 2;
	bit__			= 16;
	block__			= ( bit__ * channel__ ) / 8;
	rate__			= 44100;
	byte_per_sec__	= rate__ * block__;

	data_ary__[ 0 ]	= 'd';
	data_ary__[ 1 ]	= 'a';
	data_ary__[ 2 ]	= 't';
	data_ary__[ 3 ]	= 'a';

	data_size__		= ( total_size__ + 8 ) - 44;

	// body
	wave_buf__			= my_null;
	wave_sampling_num__	= 0;
}

enum
{
	CHUNK_FMT	= 0x20746D66,	// "fmt "
	CHUNK_DATA	= 0x61746164,	// "data"
	CHUNK_FACT	= 0x74636166,	// "fact"
	CHUNK_LIST	= 0x5453494C,	// "LIST"
};

//
int scWaveFormat::ReadWaveFileHeader__( std::FILE *arg_fp )
{
	int result = -1;
	if( arg_fp != my_null )
	{
		int flag_fmt = 0;
		int flag_data = 0;
		int byte;
		long offset;
		long chunk;

		std::fread( &( riff_ary__[ 0 ] ),	sizeof( riff_ary__ ),		1, arg_fp );
		std::fread( &total_size__,			sizeof( unsigned long ),	1, arg_fp );
		std::fread( &( wave_ary__[ 0 ] ),	sizeof( fmt_ary__ ),		1, arg_fp );

		while( ( flag_fmt == 0 ) || ( flag_data == 0 ) )
		{
			byte = std::fread( &chunk, sizeof( unsigned long ),	1, arg_fp );
			byte += std::fread( &offset, sizeof( unsigned long ),	1, arg_fp );
			if( byte == 0 )
			{
				break;
			}
			switch( chunk )
			{
			//
			case CHUNK_FMT:
				fmt_ary__[ 0 ] = 'f';
				fmt_ary__[ 1 ] = 'm';
				fmt_ary__[ 2 ] = 't';
				fmt_ary__[ 3 ] = ' ';
				fmt_size__ = offset;
				std::fread( &format__,				sizeof( short ),			1, arg_fp );
				std::fread( &channel__,				sizeof( short ),			1, arg_fp );
				std::fread( &rate__,				sizeof( unsigned long ),	1, arg_fp );
				std::fread( &byte_per_sec__,		sizeof( unsigned long ),	1, arg_fp );
				std::fread( &block__,				sizeof( short ),			1, arg_fp );
				std::fread( &bit__,					sizeof( short ),			1, arg_fp );
				if( fmt_size__ > 16 )
				{
					std::fseek( arg_fp, fmt_size__ - 16, SEEK_CUR );
					fmt_size__ = 16;
				}
				flag_fmt = 1;
				break;

			//
			case CHUNK_DATA:
				data_ary__[ 0 ] = 'd';
				data_ary__[ 1 ] = 'a';
				data_ary__[ 2 ] = 't';
				data_ary__[ 3 ] = 'a';
//				data_size__ = offset;
				wave_sampling_num__ = offset / block__;
				data_size__ = ( total_size__ + 8 ) - 44;
				flag_data = 1;
				break;

			//
			case CHUNK_FACT:
			case CHUNK_LIST:
				std::fseek( arg_fp, offset, SEEK_CUR );
				break;

			//
			default:
				std::fseek( arg_fp, offset, SEEK_CUR );
				break;
			}
		}

		result = 0;
	}
	return result;
}


//
int scWaveFormat::ReadWaveFileBody__( std::FILE *arg_fp )
{
	int result = -1;
	if( arg_fp != my_null )
	{
		data_size__ = ( total_size__ + 8 ) - 44;
		if( data_size__ > 0 )
		{
			// �o�b�t�@�g�p���Ȃ�A��U�������B
			if( wave_buf__ )
			{
				::operator delete( wave_buf__ );
				wave_buf__ = my_null;
			}

			int sound_data_bytesize;

//			wave_sampling_num__ = data_size__ / block__;
			sound_data_bytesize = wave_sampling_num__ * block__;
			wave_buf__ = static_cast< char * >( ::operator new( data_size__ ) );
			std::fread( &( wave_buf__[ 0 ] ), sizeof( char ), sound_data_bytesize, arg_fp );

		}
		else
		{
			data_size__	= 0;
			wave_sampling_num__	= 0;
		}

		result = 0;
	}
	return result;
}

//
int scWaveFormat::ReadWaveFile__( const char *arg_wavefilename )
{
	int result = -1;
	std::FILE *fp;
	fp = std::fopen( arg_wavefilename, "rb" );
	if( fp != my_null )
	{
		ReadWaveFileHeader__( fp );
		ReadWaveFileBody__( fp );

		std::fclose( fp );

		result = 0;
	}
	return result;
}

//
int scWaveFormat::SaveCore__( const char *arg_wavefilename )
{
	int result = -1;

	std::FILE *fp;
	fp = std::fopen( arg_wavefilename, "wb" );
	if( fp != my_null )
	{
		// header
		std::fwrite( &( riff_ary__[ 0 ] ),	sizeof( riff_ary__ ),		1, fp );
		std::fwrite( &total_size__,			sizeof( unsigned long ),	1, fp );
		std::fwrite( &( wave_ary__[ 0 ] ),	sizeof( wave_ary__ ),		1, fp );
		std::fwrite( &( fmt_ary__[ 0 ] ),	sizeof( fmt_ary__ ),		1, fp );
		std::fwrite( &fmt_size__,			sizeof( unsigned long ),	1, fp );
		std::fwrite( &format__,				sizeof( short ),			1, fp );
		std::fwrite( &channel__,				sizeof( short ),		1, fp );
		std::fwrite( &rate__,				sizeof( unsigned long ),	1, fp );
		std::fwrite( &byte_per_sec__,		sizeof( unsigned long ),	1, fp );
		std::fwrite( &block__,				sizeof( short ),			1, fp );
		std::fwrite( &bit__,				sizeof( short ),			1, fp );
		std::fwrite( &( data_ary__[ 0 ] ),	sizeof( data_ary__ ),		1, fp );
		std::fwrite( &data_size__,			sizeof( long ),				1, fp );

		// body
		if( wave_buf__ != my_null )
		{
			int sound_data_bytesize;
			sound_data_bytesize = this->wave_sampling_num__ * this->block__;
//			std::fwrite( &( wave_buf__[ 0 ] ), sizeof( unsigned char ), data_size__, fp );
			std::fwrite( &( wave_buf__[ 0 ] ), sizeof( char ), sound_data_bytesize, fp );
		}

		std::fclose( fp );

		result = 0;
	}
	return result;
}

/////////////////////////////////////////////////////////////////////////////////
// private �����o�֐�(�����܂�)
/////////////////////////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////////////////////////
// public �����o�֐�
/////////////////////////////////////////////////////////////////////////////////

//
int scWaveFormat::Alloc( unsigned short arg_channel, unsigned short arg_bit, unsigned long arg_rate, long arg_wave_sampling_num )
{
	int result = -1;
	char *p_tmp_buf;
	int tmp_block_size;
	int tmp_buf_size;

	tmp_block_size	= ( arg_bit * arg_channel ) / 8;
	tmp_buf_size	= arg_wave_sampling_num * tmp_block_size;
	if( tmp_buf_size > 0 )
	{
		p_tmp_buf = static_cast< char * >( ::operator new( tmp_buf_size ) );
		if( p_tmp_buf != my_null )
		{
			int i;
			for( i = 0; i < tmp_buf_size; i ++ )
			{
				p_tmp_buf[ i ] = 0x00;
			}
			channel__	= arg_channel;
			rate__		= arg_rate;
			bit__		= arg_bit;
			wave_sampling_num__ = arg_wave_sampling_num;

			total_size__	= 44 + tmp_buf_size - 8;
			block__		= ( bit__ * channel__ ) / 8;
			byte_per_sec__	= rate__ * block__;
			data_size__		= ( total_size__ + 8 ) - 44;

			wave_buf__ = p_tmp_buf;
			result = 0;
		}
	}
	return result;
}

long scWaveFormat::SamplingNum() const
{
	return wave_sampling_num__;
}
double scWaveFormat::Length_Sec() const
{
	double sec;
	sec = static_cast< double >( wave_sampling_num__ ) / rate__;
	return sec;
}

//
int scWaveFormat::Volume( double arg_sec, int *arg_vol_right,  int *arg_vol_left ) const
{
	double sec_pos;
	int index;
	int channel, byte;
	int ary_volume[ 2 ] = { 0, };

	byte	= this->bit__ / 8;
	channel	= this->block__ / byte;
	if( arg_sec > Length_Sec() )
	{
		sec_pos = Length_Sec();
	}
	else
	{
		sec_pos = arg_sec;
	}
	index = static_cast< int >( wave_sampling_num__ * sec_pos / rate__ + 0.5f );

	if( byte == 2 )
	{
		const short *p_i16;

		p_i16 = reinterpret_cast< const short * >( &( this->wave_buf__[ index * byte ] ) );
		if( channel == 2 )
		{
			ary_volume[ 0 ] = p_i16[ 0 ];
			ary_volume[ 1 ] = p_i16[ 1 ];
		}
		else
		{
			ary_volume[ 0 ] = p_i16[ 0 ];
			ary_volume[ 1 ] = ary_volume[ 0 ];
		}
	}
	else
	{
		if( channel == 2 )
		{
			ary_volume[ 0 ] = this->wave_buf__[ index ] << 8;
			ary_volume[ 1 ] = this->wave_buf__[ index + 1 ] << 8;
		}
		else
		{
			ary_volume[ 0 ] = this->wave_buf__[ index ] << 8;
			ary_volume[ 1 ] = ary_volume[ 0 ];
		}
	}

	*arg_vol_right	= ary_volume[ 0 ] * 1000;
	*arg_vol_left	= ary_volume[ 1 ] * 1000;

	return 0;
}

template < typename T1 >
void sttc_GetMinMaxCore( const char *arg_wave_buf, int arg_smp_num, int arg_offset_num, int arg_channel_id, int arg_channel_num, int *arg_min, int *arg_max )
{
	const T1 *p_wave_buf;
	int min, max;
	int i;

	p_wave_buf = reinterpret_cast< const T1 * >( arg_wave_buf ) + arg_offset_num * arg_channel_num;
	min = max = p_wave_buf[ arg_channel_id ];
	for( i = arg_channel_id; i < arg_smp_num; i += arg_channel_num )
	{
		if( p_wave_buf[ i ] > max )
		{
			max = p_wave_buf[ i ];
		}
		if( p_wave_buf[ i ] < min )
		{
			min = p_wave_buf[ i ];
		}
	}

	volatile int elm_size;
	elm_size = sizeof( T1 );
	if( elm_size == 1 )
	{
		min *= 256;
		max *= 256;
	}
	*arg_min = min;
	*arg_max = max;

	return;
}

//
int scWaveFormat::VolumeMinMax( double arg_start_sec, double arg_length_sec, int arg_channel, int *arg_vol_min,  int *arg_vol_max ) const
{
	int channel_id;
	int offset_num, smp_num;

	if( channel__ < 2 )
	{
		channel_id = 0;
	}
	else
	{
		channel_id = arg_channel;
	}
	

//	offset_num	= static_cast< long >( arg_start_sec * this->rate__ + 0.5f ) * ( bit__ / 8 );
//	smp_num		= static_cast< long >( arg_length_sec * this->rate__ + 0.5f ) * ( bit__ / 8 );
	offset_num	= static_cast< long >( arg_start_sec * this->rate__ + 0.5f );
	smp_num		= static_cast< long >( arg_length_sec * this->rate__ + 0.5f );

	if( offset_num + smp_num > wave_sampling_num__ * channel__ )
	{
		smp_num = ( wave_sampling_num__ * channel__ ) - offset_num;
	}

	if( this->bit__ == 16 )
	{
		sttc_GetMinMaxCore< short >( wave_buf__, smp_num, offset_num, channel_id, channel__, arg_vol_min, arg_vol_max );
	}
	else
	{
		sttc_GetMinMaxCore< char >( wave_buf__, smp_num, offset_num, channel_id, channel__, arg_vol_min, arg_vol_max );
	}


	return 0;
}
//
int scWaveFormat::Save( const char *arg_wavefilename )
{
	int result = -1;
	result = SaveCore__( arg_wavefilename );
	return result;
}
//
int scWaveFormat::Load( const char *arg_wavefilename )
{
	int result = -1;
	result = ReadWaveFile__( arg_wavefilename );
	return result;
}
//
int scWaveFormat::ToMonaural()
{
	int result = -1;
	if( channel__ == 2 && wave_buf__ != my_null )
	{
		char *p_new_buf;
		int new_buf_size;
		new_buf_size = ( ( total_size__ + 8 ) - 44 ) / 2;
		p_new_buf = static_cast< char * >( ::operator new( new_buf_size ) );
		if( p_new_buf != my_null )
		{
			int elm_num;
			int sum;
			int i;

			elm_num = wave_sampling_num__ = new_buf_size / ( bit__ / 8 );
			if( bit__ == 8 )
			{
				const char *p08_input_ary;
				char *p08_output_ary;

				p08_input_ary	= wave_buf__;
				p08_output_ary	= p_new_buf;
				for( i = 0; i < elm_num; i += 2 )
				{
					sum = p08_input_ary[ i ] + p08_input_ary[ i + 1 ];
					p08_output_ary[ i >> 1 ] = static_cast< char >( ( sum + 1 ) >> 1 );
				}
			}
			else
			{
				const short *p16_input_ary;
				short *p16_output_ary;

				p16_input_ary	= reinterpret_cast< short * >( wave_buf__ );
				p16_output_ary	= reinterpret_cast< short * >( p_new_buf );
				for( i = 0; i < elm_num; i += 2 )
				{
					sum = p16_input_ary[ i ] + p16_input_ary[ i + 1 ];
					p16_output_ary[ i >> 1 ] = static_cast< short >( ( sum + 1 ) >> 1 );
				}
			}
			// �Â������o�b�t�@��j��
			::operator delete( wave_buf__ );
			// �V���������o�b�t�@�̃A�h���X����
			wave_buf__ = p_new_buf;

			// �����o�ϐ��̍X�V
			channel__		= 1;	// ���m����
			block__			= ( bit__ * channel__ ) / 8;
			byte_per_sec__	= rate__ * block__;
			total_size__	= 44 + wave_sampling_num__ * block__ - 8;
			data_size__		= ( total_size__ + 8 ) - 44;

			data_size__ = ( total_size__ + 8 ) - 44;

			result = 0;
		}
	}
	return result;
}

//
void scWaveFormat::Trim( double srg_start_sec, double srg_length_sec )
{
	if( srg_start_sec >= 0.0f && srg_length_sec >= 0.0f && srg_length_sec )
	{
		int offset_byte;
		int smp_num, newdata_bytesize;
		int src_sound_bytesize;

		src_sound_bytesize = this->wave_sampling_num__ * this->block__;

		offset_byte			= static_cast< long >( srg_start_sec * this->rate__ + 0.5f ) * this->block__;
		smp_num				= static_cast< long >( srg_length_sec * this->rate__ + 0.5f );
		newdata_bytesize	= smp_num * block__;
		if( offset_byte <= src_sound_bytesize - this->block__ )
		{
			if( offset_byte + newdata_bytesize > src_sound_bytesize )
			{
				newdata_bytesize = src_sound_bytesize - offset_byte;
			}
			if( newdata_bytesize > 0 )
			{
				int i;
				for( i = 0; i < newdata_bytesize; i ++ )
				{
					this->wave_buf__[ i ] = this->wave_buf__[ offset_byte + i ];
				}
				this->wave_sampling_num__	= smp_num;
				this->data_size__			= newdata_bytesize;
				this->total_size__			= ( data_size__ + 44 ) - 8;
			}
		}
	}

	return;
}


//
int scWaveFormat::CopyTo( scWaveFormat *arg_input_instance ) const
{
	int result = -1;
	if( arg_input_instance != my_null )
	{
		arg_input_instance->Init__();
		result = arg_input_instance->Alloc( this->channel__, this->bit__, this->rate__, this->wave_sampling_num__ );
		if( result == 0 )
		{
			int sound_data_bytesize;
			int i;

			sound_data_bytesize = wave_sampling_num__ * block__;
			for( i = 0; i < sound_data_bytesize; i ++ )
			{
				arg_input_instance->wave_buf__[ i ] = this->wave_buf__[ i ];
			}
		}
	}
	return result;
}

//
void scWaveFormat::Bit08()
{
	if( channel__ != 1 )
	{
		int sound_data_bytesize;
		int i;

		sound_data_bytesize = wave_sampling_num__ * block__;
		for( i = 0; i < sound_data_bytesize; i += 2 )
		{
			this->wave_buf__[ i >> 1 ] = this->wave_buf__[ i + 1 ];
		}
		this->bit__				= 8;
		this->block__			= ( this->bit__ * this->channel__ ) / 8;
		this->byte_per_sec__	= rate__ * block__;
		this->total_size__		= 44 + ( sound_data_bytesize / 2 ) - 8;
		this->data_size__		= ( total_size__ + 8 ) - 44;
	}
	return;
}

/////////////////////////////////////////////////////////////////////////////////
// public �����o�֐�(�����܂�)
/////////////////////////////////////////////////////////////////////////////////
