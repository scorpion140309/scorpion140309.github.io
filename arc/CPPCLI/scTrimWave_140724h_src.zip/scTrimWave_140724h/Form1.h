#pragma once

#include "WAVE_TRIM_INFO.h"
#include <scWaveFormat.h>

namespace scTrimWave {


	/// <summary>
	/// Form1 �̊T�v
	///
	/// �x��: ���̃N���X�̖��O��ύX����ꍇ�A���̃N���X���ˑ����邷�ׂĂ� .resx �t�@�C���Ɋ֘A�t����ꂽ
	///          �}�l�[�W ���\�[�X �R���p�C�� �c�[���ɑ΂��� 'Resource File Name' �v���p�e�B��
	///          �ύX����K�v������܂��B���̕ύX���s��Ȃ��ƁA
	///          �f�U�C�i�ƁA���̃t�H�[���Ɋ֘A�t����ꂽ���[�J���C�Y�ς݃��\�[�X�Ƃ��A
	///          ���������݂ɗ��p�ł��Ȃ��Ȃ�܂��B
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: �����ɃR���X�g���N�^ �R�[�h��ǉ����܂�
			//
		}

	protected:
		/// <summary>
		/// �g�p���̃��\�[�X�����ׂăN���[���A�b�v���܂��B
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}

	private: System::Windows::Forms::GroupBox^  groupBox_trim_list;






	private: System::Windows::Forms::Button^  button_WorkingDir;
	private: System::Windows::Forms::TextBox^  textBox_WorkingDir;




	private: System::Windows::Forms::Button^  button_setting;
	private: System::Windows::Forms::ListBox^  listBox_trim_wave;
	private: System::Windows::Forms::GroupBox^  groupBox_preview;
	private: System::Windows::Forms::NumericUpDown^  numericUpDown_file_num;
	private: System::Windows::Forms::Label^  label_file_num;
	private: System::Windows::Forms::NumericUpDown^  numericUpDown_file_no;


	private: System::Windows::Forms::Label^  label_file_no;
	private: System::Windows::Forms::NumericUpDown^  numericUpDown_length;

	private: System::Windows::Forms::Label^  label_length_sec;
	private: System::Windows::Forms::NumericUpDown^  numericUpDown_start;

	private: System::Windows::Forms::Label^  label_start_sec;
	private: System::Windows::Forms::PictureBox^  pictureBox_wave_0;
	private: System::Windows::Forms::PictureBox^  pictureBox_wave_1;
	private: System::Windows::Forms::Button^  button_test_wave;

	private: System::Windows::Forms::Button^  button_setting_save;
	private: System::Windows::Forms::Button^  button_exe;
	private: System::ComponentModel::BackgroundWorker^  backgroundWorker_TrimWave;
	private: System::Windows::Forms::Button^  button_clear;
	private: System::Windows::Forms::Button^  button_update;















	protected: 

	private:
		/// <summary>
		/// �K�v�ȃf�U�C�i�ϐ��ł��B
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// �f�U�C�i �T�|�[�g�ɕK�v�ȃ��\�b�h�ł��B���̃��\�b�h�̓��e��
		/// �R�[�h �G�f�B�^�ŕύX���Ȃ��ł��������B
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Form1::typeid));
			this->groupBox_trim_list = (gcnew System::Windows::Forms::GroupBox());
			this->button_clear = (gcnew System::Windows::Forms::Button());
			this->button_setting_save = (gcnew System::Windows::Forms::Button());
			this->listBox_trim_wave = (gcnew System::Windows::Forms::ListBox());
			this->button_setting = (gcnew System::Windows::Forms::Button());
			this->button_WorkingDir = (gcnew System::Windows::Forms::Button());
			this->textBox_WorkingDir = (gcnew System::Windows::Forms::TextBox());
			this->groupBox_preview = (gcnew System::Windows::Forms::GroupBox());
			this->button_update = (gcnew System::Windows::Forms::Button());
			this->button_test_wave = (gcnew System::Windows::Forms::Button());
			this->pictureBox_wave_1 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox_wave_0 = (gcnew System::Windows::Forms::PictureBox());
			this->numericUpDown_length = (gcnew System::Windows::Forms::NumericUpDown());
			this->label_length_sec = (gcnew System::Windows::Forms::Label());
			this->numericUpDown_start = (gcnew System::Windows::Forms::NumericUpDown());
			this->label_start_sec = (gcnew System::Windows::Forms::Label());
			this->numericUpDown_file_num = (gcnew System::Windows::Forms::NumericUpDown());
			this->label_file_num = (gcnew System::Windows::Forms::Label());
			this->numericUpDown_file_no = (gcnew System::Windows::Forms::NumericUpDown());
			this->label_file_no = (gcnew System::Windows::Forms::Label());
			this->button_exe = (gcnew System::Windows::Forms::Button());
			this->backgroundWorker_TrimWave = (gcnew System::ComponentModel::BackgroundWorker());
			this->groupBox_trim_list->SuspendLayout();
			this->groupBox_preview->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox_wave_1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox_wave_0))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericUpDown_length))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericUpDown_start))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericUpDown_file_num))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericUpDown_file_no))->BeginInit();
			this->SuspendLayout();
			// 
			// groupBox_trim_list
			// 
			this->groupBox_trim_list->Anchor = static_cast<System::Windows::Forms::AnchorStyles>(((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Left) 
				| System::Windows::Forms::AnchorStyles::Right));
			this->groupBox_trim_list->Controls->Add(this->button_clear);
			this->groupBox_trim_list->Controls->Add(this->button_setting_save);
			this->groupBox_trim_list->Controls->Add(this->listBox_trim_wave);
			this->groupBox_trim_list->Controls->Add(this->button_setting);
			this->groupBox_trim_list->Controls->Add(this->button_WorkingDir);
			this->groupBox_trim_list->Controls->Add(this->textBox_WorkingDir);
			this->groupBox_trim_list->Location = System::Drawing::Point(20, 16);
			this->groupBox_trim_list->Margin = System::Windows::Forms::Padding(4);
			this->groupBox_trim_list->Name = L"groupBox_trim_list";
			this->groupBox_trim_list->Padding = System::Windows::Forms::Padding(4);
			this->groupBox_trim_list->Size = System::Drawing::Size(746, 373);
			this->groupBox_trim_list->TabIndex = 1;
			this->groupBox_trim_list->TabStop = false;
			this->groupBox_trim_list->Text = L"�ҏW���X�g";
			// 
			// button_clear
			// 
			this->button_clear->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Right));
			this->button_clear->Location = System::Drawing::Point(566, 283);
			this->button_clear->Margin = System::Windows::Forms::Padding(4);
			this->button_clear->Name = L"button_clear";
			this->button_clear->Size = System::Drawing::Size(170, 77);
			this->button_clear->TabIndex = 5;
			this->button_clear->Text = L"���X�g���N���A";
			this->button_clear->UseVisualStyleBackColor = true;
			this->button_clear->Click += gcnew System::EventHandler(this, &Form1::button_something_Click);
			// 
			// button_setting_save
			// 
			this->button_setting_save->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Right));
			this->button_setting_save->Location = System::Drawing::Point(566, 201);
			this->button_setting_save->Margin = System::Windows::Forms::Padding(4);
			this->button_setting_save->Name = L"button_setting_save";
			this->button_setting_save->Size = System::Drawing::Size(170, 77);
			this->button_setting_save->TabIndex = 4;
			this->button_setting_save->Text = L"���O��t���ĕۑ�(CSV)";
			this->button_setting_save->UseVisualStyleBackColor = true;
			this->button_setting_save->Click += gcnew System::EventHandler(this, &Form1::button_something_Click);
			// 
			// listBox_trim_wave
			// 
			this->listBox_trim_wave->AllowDrop = true;
			this->listBox_trim_wave->Anchor = static_cast<System::Windows::Forms::AnchorStyles>(((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Left) 
				| System::Windows::Forms::AnchorStyles::Right));
			this->listBox_trim_wave->Font = (gcnew System::Drawing::Font(L"�l�r �S�V�b�N", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(128)));
			this->listBox_trim_wave->FormattingEnabled = true;
			this->listBox_trim_wave->ItemHeight = 16;
			this->listBox_trim_wave->Location = System::Drawing::Point(10, 116);
			this->listBox_trim_wave->Name = L"listBox_trim_wave";
			this->listBox_trim_wave->Size = System::Drawing::Size(549, 244);
			this->listBox_trim_wave->TabIndex = 2;
			this->listBox_trim_wave->SelectedIndexChanged += gcnew System::EventHandler(this, &Form1::listBox_trim_wave_SelectedIndexChanged);
			this->listBox_trim_wave->DragDrop += gcnew System::Windows::Forms::DragEventHandler(this, &Form1::textBox_WorkingDir_DragDrop);
			this->listBox_trim_wave->DragEnter += gcnew System::Windows::Forms::DragEventHandler(this, &Form1::textBox_WorkingDir_DragEnter);
			// 
			// button_setting
			// 
			this->button_setting->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Right));
			this->button_setting->Location = System::Drawing::Point(567, 116);
			this->button_setting->Margin = System::Windows::Forms::Padding(4);
			this->button_setting->Name = L"button_setting";
			this->button_setting->Size = System::Drawing::Size(170, 77);
			this->button_setting->TabIndex = 3;
			this->button_setting->Text = L"�؂���w��t�@�C��(CSV)";
			this->button_setting->UseVisualStyleBackColor = true;
			this->button_setting->Click += gcnew System::EventHandler(this, &Form1::button_something_Click);
			// 
			// button_WorkingDir
			// 
			this->button_WorkingDir->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Right));
			this->button_WorkingDir->Location = System::Drawing::Point(567, 24);
			this->button_WorkingDir->Margin = System::Windows::Forms::Padding(4);
			this->button_WorkingDir->Name = L"button_WorkingDir";
			this->button_WorkingDir->Size = System::Drawing::Size(170, 77);
			this->button_WorkingDir->TabIndex = 1;
			this->button_WorkingDir->Text = L"��ƃf�B���N�g��";
			this->button_WorkingDir->UseVisualStyleBackColor = true;
			this->button_WorkingDir->Click += gcnew System::EventHandler(this, &Form1::button_something_Click);
			// 
			// textBox_WorkingDir
			// 
			this->textBox_WorkingDir->AllowDrop = true;
			this->textBox_WorkingDir->Anchor = static_cast<System::Windows::Forms::AnchorStyles>(((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Left) 
				| System::Windows::Forms::AnchorStyles::Right));
			this->textBox_WorkingDir->Font = (gcnew System::Drawing::Font(L"�l�r �S�V�b�N", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(128)));
			this->textBox_WorkingDir->Location = System::Drawing::Point(10, 25);
			this->textBox_WorkingDir->Margin = System::Windows::Forms::Padding(4);
			this->textBox_WorkingDir->Multiline = true;
			this->textBox_WorkingDir->Name = L"textBox_WorkingDir";
			this->textBox_WorkingDir->Size = System::Drawing::Size(549, 76);
			this->textBox_WorkingDir->TabIndex = 0;
			this->textBox_WorkingDir->DragDrop += gcnew System::Windows::Forms::DragEventHandler(this, &Form1::textBox_WorkingDir_DragDrop);
			this->textBox_WorkingDir->DragEnter += gcnew System::Windows::Forms::DragEventHandler(this, &Form1::textBox_WorkingDir_DragEnter);
			// 
			// groupBox_preview
			// 
			this->groupBox_preview->Anchor = static_cast<System::Windows::Forms::AnchorStyles>(((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Left) 
				| System::Windows::Forms::AnchorStyles::Right));
			this->groupBox_preview->Controls->Add(this->button_update);
			this->groupBox_preview->Controls->Add(this->button_test_wave);
			this->groupBox_preview->Controls->Add(this->pictureBox_wave_1);
			this->groupBox_preview->Controls->Add(this->pictureBox_wave_0);
			this->groupBox_preview->Controls->Add(this->numericUpDown_length);
			this->groupBox_preview->Controls->Add(this->label_length_sec);
			this->groupBox_preview->Controls->Add(this->numericUpDown_start);
			this->groupBox_preview->Controls->Add(this->label_start_sec);
			this->groupBox_preview->Controls->Add(this->numericUpDown_file_num);
			this->groupBox_preview->Controls->Add(this->label_file_num);
			this->groupBox_preview->Controls->Add(this->numericUpDown_file_no);
			this->groupBox_preview->Controls->Add(this->label_file_no);
			this->groupBox_preview->Location = System::Drawing::Point(20, 396);
			this->groupBox_preview->Name = L"groupBox_preview";
			this->groupBox_preview->Size = System::Drawing::Size(746, 200);
			this->groupBox_preview->TabIndex = 2;
			this->groupBox_preview->TabStop = false;
			this->groupBox_preview->Text = L"�v���r���[";
			// 
			// button_update
			// 
			this->button_update->Location = System::Drawing::Point(402, 23);
			this->button_update->Name = L"button_update";
			this->button_update->Size = System::Drawing::Size(75, 47);
			this->button_update->TabIndex = 8;
			this->button_update->Text = L"�X�V";
			this->button_update->UseVisualStyleBackColor = true;
			this->button_update->Click += gcnew System::EventHandler(this, &Form1::button_something_Click);
			// 
			// button_test_wave
			// 
			this->button_test_wave->Location = System::Drawing::Point(484, 23);
			this->button_test_wave->Name = L"button_test_wave";
			this->button_test_wave->Size = System::Drawing::Size(75, 47);
			this->button_test_wave->TabIndex = 9;
			this->button_test_wave->Text = L"����";
			this->button_test_wave->UseVisualStyleBackColor = true;
			this->button_test_wave->Click += gcnew System::EventHandler(this, &Form1::button_something_Click);
			// 
			// pictureBox_wave_1
			// 
			this->pictureBox_wave_1->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Bottom) 
				| System::Windows::Forms::AnchorStyles::Left) 
				| System::Windows::Forms::AnchorStyles::Right));
			this->pictureBox_wave_1->Location = System::Drawing::Point(13, 136);
			this->pictureBox_wave_1->Name = L"pictureBox_wave_1";
			this->pictureBox_wave_1->Size = System::Drawing::Size(546, 54);
			this->pictureBox_wave_1->TabIndex = 9;
			this->pictureBox_wave_1->TabStop = false;
			// 
			// pictureBox_wave_0
			// 
			this->pictureBox_wave_0->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Bottom) 
				| System::Windows::Forms::AnchorStyles::Left) 
				| System::Windows::Forms::AnchorStyles::Right));
			this->pictureBox_wave_0->Location = System::Drawing::Point(13, 76);
			this->pictureBox_wave_0->Name = L"pictureBox_wave_0";
			this->pictureBox_wave_0->Size = System::Drawing::Size(546, 54);
			this->pictureBox_wave_0->TabIndex = 8;
			this->pictureBox_wave_0->TabStop = false;
			// 
			// numericUpDown_length
			// 
			this->numericUpDown_length->DecimalPlaces = 2;
			this->numericUpDown_length->Increment = System::Decimal(gcnew cli::array< System::Int32 >(4) {5, 0, 0, 65536});
			this->numericUpDown_length->Location = System::Drawing::Point(312, 47);
			this->numericUpDown_length->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {10000, 0, 0, 0});
			this->numericUpDown_length->Name = L"numericUpDown_length";
			this->numericUpDown_length->Size = System::Drawing::Size(84, 23);
			this->numericUpDown_length->TabIndex = 7;
			this->numericUpDown_length->TextAlign = System::Windows::Forms::HorizontalAlignment::Right;
			this->numericUpDown_length->KeyPress += gcnew System::Windows::Forms::KeyPressEventHandler(this, &Form1::numericUpDown_something_KeyPress);
			// 
			// label_length_sec
			// 
			this->label_length_sec->AutoSize = true;
			this->label_length_sec->Location = System::Drawing::Point(204, 49);
			this->label_length_sec->Name = L"label_length_sec";
			this->label_length_sec->Size = System::Drawing::Size(61, 16);
			this->label_length_sec->TabIndex = 6;
			this->label_length_sec->Text = L"����(�b)";
			// 
			// numericUpDown_start
			// 
			this->numericUpDown_start->DecimalPlaces = 2;
			this->numericUpDown_start->Increment = System::Decimal(gcnew cli::array< System::Int32 >(4) {5, 0, 0, 65536});
			this->numericUpDown_start->Location = System::Drawing::Point(114, 47);
			this->numericUpDown_start->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {10000, 0, 0, 0});
			this->numericUpDown_start->Name = L"numericUpDown_start";
			this->numericUpDown_start->Size = System::Drawing::Size(84, 23);
			this->numericUpDown_start->TabIndex = 5;
			this->numericUpDown_start->TextAlign = System::Windows::Forms::HorizontalAlignment::Right;
			this->numericUpDown_start->KeyPress += gcnew System::Windows::Forms::KeyPressEventHandler(this, &Form1::numericUpDown_something_KeyPress);
			// 
			// label_start_sec
			// 
			this->label_start_sec->AutoSize = true;
			this->label_start_sec->Location = System::Drawing::Point(10, 49);
			this->label_start_sec->Name = L"label_start_sec";
			this->label_start_sec->Size = System::Drawing::Size(98, 16);
			this->label_start_sec->TabIndex = 4;
			this->label_start_sec->Text = L"�J�n�ʒu(�b)";
			// 
			// numericUpDown_file_num
			// 
			this->numericUpDown_file_num->Increment = System::Decimal(gcnew cli::array< System::Int32 >(4) {0, 0, 0, 0});
			this->numericUpDown_file_num->Location = System::Drawing::Point(312, 21);
			this->numericUpDown_file_num->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {10000, 0, 0, 0});
			this->numericUpDown_file_num->Name = L"numericUpDown_file_num";
			this->numericUpDown_file_num->ReadOnly = true;
			this->numericUpDown_file_num->Size = System::Drawing::Size(84, 23);
			this->numericUpDown_file_num->TabIndex = 3;
			this->numericUpDown_file_num->TextAlign = System::Windows::Forms::HorizontalAlignment::Right;
			// 
			// label_file_num
			// 
			this->label_file_num->AutoSize = true;
			this->label_file_num->Location = System::Drawing::Point(205, 23);
			this->label_file_num->Name = L"label_file_num";
			this->label_file_num->Size = System::Drawing::Size(101, 16);
			this->label_file_num->TabIndex = 2;
			this->label_file_num->Text = L"�o�̓t�@�C����";
			// 
			// numericUpDown_file_no
			// 
			this->numericUpDown_file_no->Increment = System::Decimal(gcnew cli::array< System::Int32 >(4) {0, 0, 0, 0});
			this->numericUpDown_file_no->Location = System::Drawing::Point(115, 19);
			this->numericUpDown_file_no->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {10000, 0, 0, 0});
			this->numericUpDown_file_no->Name = L"numericUpDown_file_no";
			this->numericUpDown_file_no->ReadOnly = true;
			this->numericUpDown_file_no->Size = System::Drawing::Size(84, 23);
			this->numericUpDown_file_no->TabIndex = 1;
			this->numericUpDown_file_no->TextAlign = System::Windows::Forms::HorizontalAlignment::Right;
			// 
			// label_file_no
			// 
			this->label_file_no->AutoSize = true;
			this->label_file_no->Location = System::Drawing::Point(10, 23);
			this->label_file_no->Name = L"label_file_no";
			this->label_file_no->Size = System::Drawing::Size(85, 16);
			this->label_file_no->TabIndex = 0;
			this->label_file_no->Text = L"�t�@�C���ԍ�";
			// 
			// button_exe
			// 
			this->button_exe->Location = System::Drawing::Point(20, 602);
			this->button_exe->Name = L"button_exe";
			this->button_exe->Size = System::Drawing::Size(559, 67);
			this->button_exe->TabIndex = 3;
			this->button_exe->Text = L"���s";
			this->button_exe->UseVisualStyleBackColor = true;
			this->button_exe->Click += gcnew System::EventHandler(this, &Form1::button_something_Click);
			// 
			// backgroundWorker_TrimWave
			// 
			this->backgroundWorker_TrimWave->WorkerReportsProgress = true;
			this->backgroundWorker_TrimWave->WorkerSupportsCancellation = true;
			this->backgroundWorker_TrimWave->DoWork += gcnew System::ComponentModel::DoWorkEventHandler(this, &Form1::backgroundWorker_TrimWave_DoWork);
			this->backgroundWorker_TrimWave->RunWorkerCompleted += gcnew System::ComponentModel::RunWorkerCompletedEventHandler(this, &Form1::backgroundWorker_TrimWave_RunWorkerCompleted);
			this->backgroundWorker_TrimWave->ProgressChanged += gcnew System::ComponentModel::ProgressChangedEventHandler(this, &Form1::backgroundWorker_TrimWave_ProgressChanged);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(9, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(784, 677);
			this->Controls->Add(this->button_exe);
			this->Controls->Add(this->groupBox_preview);
			this->Controls->Add(this->groupBox_trim_list);
			this->Font = (gcnew System::Drawing::Font(L"MS UI Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(128)));
			this->Icon = (cli::safe_cast<System::Drawing::Icon^  >(resources->GetObject(L"$this.Icon")));
			this->Margin = System::Windows::Forms::Padding(4);
			this->Name = L"Form1";
			this->Text = L"scTrimWave";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			this->SizeChanged += gcnew System::EventHandler(this, &Form1::Form1_SizeChanged);
			this->groupBox_trim_list->ResumeLayout(false);
			this->groupBox_trim_list->PerformLayout();
			this->groupBox_preview->ResumeLayout(false);
			this->groupBox_preview->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox_wave_1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox_wave_0))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericUpDown_length))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericUpDown_start))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericUpDown_file_num))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericUpDown_file_no))->EndInit();
			this->ResumeLayout(false);

		}
#pragma endregion

	/////////////////////////////////////////////////////////////////////////////////////
	// static private �����o�ϐ�
	/////////////////////////////////////////////////////////////////////////////////////


	/////////////////////////////////////////////////////////////////////////////////////
	// static private �����o�֐�
	/////////////////////////////////////////////////////////////////////////////////////


	/////////////////////////////////////////////////////////////////////////////////////
	// private �����o�ϐ�
	/////////////////////////////////////////////////////////////////////////////////////


	private: cli::array< WAVE_TRIM_INFO^ > ^ary_trim_info;

	/////////////////////////////////////////////////////////////////////////////////////
	// �蓮�쐬
	/////////////////////////////////////////////////////////////////////////////////////

	// �v���r���[��ʂ̕`��
	private: System::Void RefreshPreview__();
	// �O���t�`��
	private: System::Void DrawGraph__();
	// �s�N�`���{�b�N�X�`��
	private: System::Void DrawPictureBox__( System::Windows::Forms::PictureBox ^arg_picture_box, scWaveFormat *arg_wave, int arg_channel, double arg_start_sec, double arg_length_sec );
	
	// �ҏW���X�g�ǂݍ���
	private: System::Void LoadList__( System::String ^arg_str_file );
	// �ҏW���X�g�ۑ�
	private: System::Void SaveList__();

	// �e�X�g
	private: System::Void TrimWaveTest__();

	// ���s
	private: System::Void TrimWaveFiles__();

	/////////////////////////////////////////////////////////////////////////////////////
	// �t�H�[���f�U�C�i����(BackgroundWoker)
	/////////////////////////////////////////////////////////////////////////////////////

	private: System::Void backgroundWorker_TrimWave_DoWork(System::Object^  , System::ComponentModel::DoWorkEventArgs^  );
	private: System::Void backgroundWorker_TrimWave_ProgressChanged(System::Object^  , System::ComponentModel::ProgressChangedEventArgs^  );
	private: System::Void backgroundWorker_TrimWave_RunWorkerCompleted(System::Object^  , System::ComponentModel::RunWorkerCompletedEventArgs^  );

	/////////////////////////////////////////////////////////////////////////////////////
	// �t�H�[���f�U�C�i����
	/////////////////////////////////////////////////////////////////////////////////////

	// �t�H�[����ǂݍ��ގ��ɔ����B
	private: System::Void Form1_Load(System::Object^  , System::EventArgs^  );
	// button
	private: System::Void button_something_Click(System::Object^  sender, System::EventArgs^  );
	// �E�B���h�E�T�C�Y�ύX
	private: System::Void Form1_SizeChanged(System::Object^  , System::EventArgs^  );
	// �h���b�O���̃J�[�\������������
	private: System::Void textBox_WorkingDir_DragEnter(System::Object^  , System::Windows::Forms::DragEventArgs^  e);
	// �h���b�v���ꂽ��
	private: System::Void textBox_WorkingDir_DragDrop(System::Object^  , System::Windows::Forms::DragEventArgs^  e);
	// �v���r���[�ΏەύX
	private: System::Void listBox_trim_wave_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e);
	// �L�[�v���X
	private: System::Void numericUpDown_something_KeyPress(System::Object^  sender, System::Windows::Forms::KeyPressEventArgs^  e);

};
}

