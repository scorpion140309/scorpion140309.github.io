#ifndef _WAVE_TRIM_INFO_H_
#define _WAVE_TRIM_INFO_H_


//
ref class WAVE_TRIM_INFO
{
public:
	System::String ^input;
	System::String ^output;
	double start_sec;
	double length_sec;

	WAVE_TRIM_INFO()
	{
		input = gcnew System::String( "" );
		output = gcnew System::String( "" );
		start_sec = 0.0f;
		length_sec = 0.0f;
	}
	WAVE_TRIM_INFO( System::String ^arg_input, System::String ^arg_output, double arg_start_sec, double arg_length_sec )
	{
		input = arg_input;
		output = arg_output;
		start_sec = arg_start_sec;
		length_sec = arg_length_sec;
	}
};

#endif	// _WAVE_TRIM_INFO_H_
