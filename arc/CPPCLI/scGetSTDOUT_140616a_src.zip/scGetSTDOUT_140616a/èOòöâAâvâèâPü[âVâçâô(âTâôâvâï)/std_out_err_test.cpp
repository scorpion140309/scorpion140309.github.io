#include <cstdio>

int main( int, char ** )
{
	std::fprintf( stdout, "stdout\n" );
	std::fprintf( stderr, "[ERROR]stderr\n" );

	return 0;
}
