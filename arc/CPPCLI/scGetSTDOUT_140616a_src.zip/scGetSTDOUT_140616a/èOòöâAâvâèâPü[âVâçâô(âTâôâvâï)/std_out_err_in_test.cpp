#define _CRT_SECURE_NO_DEPRECATE

#include <cstdio>
#include <windows.h>

int main( int, char ** )
{
	int ret = 1;
	int value = 0;

	std::fprintf( stdout, "input 1 - 9 >\n" );
	std::fflush(stdout);
	ret = std::scanf( "%d", &value );
	std::fprintf( stdout, "\n" );
	std::fflush(stdout);

	if( ret == 0 || ( value < 1 || value > 9 ) )
	{
		std::fprintf( stderr, "[ERROR]stderr\n" );
		std::fflush(stderr);
	}
	else
	{
		std::fprintf( stdout, "OK" );
		std::fflush(stdout);
	}

	return 0;
}
