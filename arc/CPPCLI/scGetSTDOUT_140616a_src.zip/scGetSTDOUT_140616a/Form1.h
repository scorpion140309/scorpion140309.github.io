#pragma once


namespace scGetSTDOUT {


	/// <summary>
	/// Form1 �̊T�v
	///
	/// �x��: ���̃N���X�̖��O��ύX����ꍇ�A���̃N���X���ˑ����邷�ׂĂ� .resx �t�@�C���Ɋ֘A�t����ꂽ
	///          �}�l�[�W ���\�[�X �R���p�C�� �c�[���ɑ΂��� 'Resource File Name' �v���p�e�B��
	///          �ύX����K�v������܂��B���̕ύX���s��Ȃ��ƁA
	///          �f�U�C�i�ƁA���̃t�H�[���Ɋ֘A�t����ꂽ���[�J���C�Y�ς݃��\�[�X�Ƃ��A
	///          ���������݂ɗ��p�ł��Ȃ��Ȃ�܂��B
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: �����ɃR���X�g���N�^ �R�[�h��ǉ����܂�
			//
		}

	protected:
		/// <summary>
		/// �g�p���̃��\�[�X�����ׂăN���[���A�b�v���܂��B
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::GroupBox^  groupBox_Exe_Arg;
	private: System::Windows::Forms::ComboBox^  comboBox_arg_1;
	private: System::Windows::Forms::Button^  button_arg_1;
	private: System::Windows::Forms::ComboBox^  comboBox_arg_0;
	private: System::Windows::Forms::Button^  button_arg_0;
	private: System::Windows::Forms::Button^  button_exe_file;
	private: System::Windows::Forms::ComboBox^  comboBox_exe_file;
	private: System::Windows::Forms::GroupBox^  groupBox_STDIN;
	private: System::Windows::Forms::Button^  button_stdin;
	private: System::Windows::Forms::ComboBox^  comboBox_stdin;
	private: System::Windows::Forms::GroupBox^  groupBox_STDOUT;
	private: System::Windows::Forms::TextBox^  textBox_STDOUT;
	private: System::Windows::Forms::Button^  button_clear;
	private: System::Windows::Forms::Button^  button_SaveLog;
	private: System::Windows::Forms::GroupBox^  groupBox_cmdline;
	private: System::Windows::Forms::TextBox^  textBox_cmdline;
	private: System::Windows::Forms::Button^  button_exe_cmdline;
	private: System::ComponentModel::BackgroundWorker^  backgroundWorker_exe;
	protected: 


	private:
		/// <summary>
		/// �K�v�ȃf�U�C�i�ϐ��ł��B
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// �f�U�C�i �T�|�[�g�ɕK�v�ȃ��\�b�h�ł��B���̃��\�b�h�̓��e��
		/// �R�[�h �G�f�B�^�ŕύX���Ȃ��ł��������B
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Form1::typeid));
			this->groupBox_Exe_Arg = (gcnew System::Windows::Forms::GroupBox());
			this->comboBox_arg_1 = (gcnew System::Windows::Forms::ComboBox());
			this->button_arg_1 = (gcnew System::Windows::Forms::Button());
			this->comboBox_arg_0 = (gcnew System::Windows::Forms::ComboBox());
			this->button_arg_0 = (gcnew System::Windows::Forms::Button());
			this->button_exe_file = (gcnew System::Windows::Forms::Button());
			this->comboBox_exe_file = (gcnew System::Windows::Forms::ComboBox());
			this->groupBox_STDIN = (gcnew System::Windows::Forms::GroupBox());
			this->button_stdin = (gcnew System::Windows::Forms::Button());
			this->comboBox_stdin = (gcnew System::Windows::Forms::ComboBox());
			this->groupBox_STDOUT = (gcnew System::Windows::Forms::GroupBox());
			this->button_clear = (gcnew System::Windows::Forms::Button());
			this->button_SaveLog = (gcnew System::Windows::Forms::Button());
			this->textBox_STDOUT = (gcnew System::Windows::Forms::TextBox());
			this->groupBox_cmdline = (gcnew System::Windows::Forms::GroupBox());
			this->textBox_cmdline = (gcnew System::Windows::Forms::TextBox());
			this->button_exe_cmdline = (gcnew System::Windows::Forms::Button());
			this->backgroundWorker_exe = (gcnew System::ComponentModel::BackgroundWorker());
			this->groupBox_Exe_Arg->SuspendLayout();
			this->groupBox_STDIN->SuspendLayout();
			this->groupBox_STDOUT->SuspendLayout();
			this->groupBox_cmdline->SuspendLayout();
			this->SuspendLayout();
			// 
			// groupBox_Exe_Arg
			// 
			this->groupBox_Exe_Arg->Anchor = static_cast<System::Windows::Forms::AnchorStyles>(((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Left) 
				| System::Windows::Forms::AnchorStyles::Right));
			this->groupBox_Exe_Arg->Controls->Add(this->comboBox_arg_1);
			this->groupBox_Exe_Arg->Controls->Add(this->button_arg_1);
			this->groupBox_Exe_Arg->Controls->Add(this->comboBox_arg_0);
			this->groupBox_Exe_Arg->Controls->Add(this->button_arg_0);
			this->groupBox_Exe_Arg->Controls->Add(this->button_exe_file);
			this->groupBox_Exe_Arg->Controls->Add(this->comboBox_exe_file);
			this->groupBox_Exe_Arg->Location = System::Drawing::Point(12, 13);
			this->groupBox_Exe_Arg->Margin = System::Windows::Forms::Padding(4);
			this->groupBox_Exe_Arg->Name = L"groupBox_Exe_Arg";
			this->groupBox_Exe_Arg->Padding = System::Windows::Forms::Padding(4);
			this->groupBox_Exe_Arg->Size = System::Drawing::Size(532, 144);
			this->groupBox_Exe_Arg->TabIndex = 0;
			this->groupBox_Exe_Arg->TabStop = false;
			this->groupBox_Exe_Arg->Text = L"���s�t�@�C��, ����";
			// 
			// comboBox_arg_1
			// 
			this->comboBox_arg_1->AllowDrop = true;
			this->comboBox_arg_1->Anchor = static_cast<System::Windows::Forms::AnchorStyles>(((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Left) 
				| System::Windows::Forms::AnchorStyles::Right));
			this->comboBox_arg_1->FormattingEnabled = true;
			this->comboBox_arg_1->Location = System::Drawing::Point(6, 106);
			this->comboBox_arg_1->Name = L"comboBox_arg_1";
			this->comboBox_arg_1->Size = System::Drawing::Size(393, 24);
			this->comboBox_arg_1->TabIndex = 4;
			this->comboBox_arg_1->DragDrop += gcnew System::Windows::Forms::DragEventHandler(this, &Form1::comboBox_something_DragDrop);
			this->comboBox_arg_1->DragEnter += gcnew System::Windows::Forms::DragEventHandler(this, &Form1::comboBox_something_DragEnter);
			this->comboBox_arg_1->KeyDown += gcnew System::Windows::Forms::KeyEventHandler(this, &Form1::comboBox_something_KeyDown);
			this->comboBox_arg_1->TextChanged += gcnew System::EventHandler(this, &Form1::comboBox_something_TextChanged);
			// 
			// button_arg_1
			// 
			this->button_arg_1->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Right));
			this->button_arg_1->Location = System::Drawing::Point(405, 101);
			this->button_arg_1->Name = L"button_arg_1";
			this->button_arg_1->Size = System::Drawing::Size(120, 32);
			this->button_arg_1->TabIndex = 5;
			this->button_arg_1->Text = L"���� 1";
			this->button_arg_1->UseVisualStyleBackColor = true;
			this->button_arg_1->Click += gcnew System::EventHandler(this, &Form1::button_something_Click);
			// 
			// comboBox_arg_0
			// 
			this->comboBox_arg_0->AllowDrop = true;
			this->comboBox_arg_0->Anchor = static_cast<System::Windows::Forms::AnchorStyles>(((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Left) 
				| System::Windows::Forms::AnchorStyles::Right));
			this->comboBox_arg_0->FormattingEnabled = true;
			this->comboBox_arg_0->Location = System::Drawing::Point(6, 68);
			this->comboBox_arg_0->Name = L"comboBox_arg_0";
			this->comboBox_arg_0->Size = System::Drawing::Size(393, 24);
			this->comboBox_arg_0->TabIndex = 2;
			this->comboBox_arg_0->DragDrop += gcnew System::Windows::Forms::DragEventHandler(this, &Form1::comboBox_something_DragDrop);
			this->comboBox_arg_0->DragEnter += gcnew System::Windows::Forms::DragEventHandler(this, &Form1::comboBox_something_DragEnter);
			this->comboBox_arg_0->KeyDown += gcnew System::Windows::Forms::KeyEventHandler(this, &Form1::comboBox_something_KeyDown);
			this->comboBox_arg_0->TextChanged += gcnew System::EventHandler(this, &Form1::comboBox_something_TextChanged);
			// 
			// button_arg_0
			// 
			this->button_arg_0->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Right));
			this->button_arg_0->Location = System::Drawing::Point(405, 63);
			this->button_arg_0->Name = L"button_arg_0";
			this->button_arg_0->Size = System::Drawing::Size(120, 32);
			this->button_arg_0->TabIndex = 3;
			this->button_arg_0->Text = L"���� 0";
			this->button_arg_0->UseVisualStyleBackColor = true;
			this->button_arg_0->Click += gcnew System::EventHandler(this, &Form1::button_something_Click);
			// 
			// button_exe_file
			// 
			this->button_exe_file->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Right));
			this->button_exe_file->Location = System::Drawing::Point(405, 25);
			this->button_exe_file->Name = L"button_exe_file";
			this->button_exe_file->Size = System::Drawing::Size(120, 32);
			this->button_exe_file->TabIndex = 1;
			this->button_exe_file->Text = L"���s�t�@�C��";
			this->button_exe_file->UseVisualStyleBackColor = true;
			this->button_exe_file->Click += gcnew System::EventHandler(this, &Form1::button_something_Click);
			// 
			// comboBox_exe_file
			// 
			this->comboBox_exe_file->AllowDrop = true;
			this->comboBox_exe_file->Anchor = static_cast<System::Windows::Forms::AnchorStyles>(((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Left) 
				| System::Windows::Forms::AnchorStyles::Right));
			this->comboBox_exe_file->FormattingEnabled = true;
			this->comboBox_exe_file->Location = System::Drawing::Point(6, 30);
			this->comboBox_exe_file->Name = L"comboBox_exe_file";
			this->comboBox_exe_file->Size = System::Drawing::Size(393, 24);
			this->comboBox_exe_file->TabIndex = 0;
			this->comboBox_exe_file->DragDrop += gcnew System::Windows::Forms::DragEventHandler(this, &Form1::comboBox_something_DragDrop);
			this->comboBox_exe_file->DragEnter += gcnew System::Windows::Forms::DragEventHandler(this, &Form1::comboBox_something_DragEnter);
			this->comboBox_exe_file->KeyDown += gcnew System::Windows::Forms::KeyEventHandler(this, &Form1::comboBox_something_KeyDown);
			this->comboBox_exe_file->TextChanged += gcnew System::EventHandler(this, &Form1::comboBox_something_TextChanged);
			// 
			// groupBox_STDIN
			// 
			this->groupBox_STDIN->Anchor = static_cast<System::Windows::Forms::AnchorStyles>(((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Left) 
				| System::Windows::Forms::AnchorStyles::Right));
			this->groupBox_STDIN->Controls->Add(this->button_stdin);
			this->groupBox_STDIN->Controls->Add(this->comboBox_stdin);
			this->groupBox_STDIN->Location = System::Drawing::Point(12, 342);
			this->groupBox_STDIN->Margin = System::Windows::Forms::Padding(4);
			this->groupBox_STDIN->Name = L"groupBox_STDIN";
			this->groupBox_STDIN->Padding = System::Windows::Forms::Padding(4);
			this->groupBox_STDIN->Size = System::Drawing::Size(532, 68);
			this->groupBox_STDIN->TabIndex = 3;
			this->groupBox_STDIN->TabStop = false;
			this->groupBox_STDIN->Text = L"�W������(STDIN)";
			// 
			// button_stdin
			// 
			this->button_stdin->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Right));
			this->button_stdin->Location = System::Drawing::Point(438, 25);
			this->button_stdin->Name = L"button_stdin";
			this->button_stdin->Size = System::Drawing::Size(86, 32);
			this->button_stdin->TabIndex = 1;
			this->button_stdin->Text = L"����";
			this->button_stdin->UseVisualStyleBackColor = true;
			this->button_stdin->Click += gcnew System::EventHandler(this, &Form1::button_stdin_Click);
			// 
			// comboBox_stdin
			// 
			this->comboBox_stdin->AllowDrop = true;
			this->comboBox_stdin->Anchor = static_cast<System::Windows::Forms::AnchorStyles>(((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Left) 
				| System::Windows::Forms::AnchorStyles::Right));
			this->comboBox_stdin->FormattingEnabled = true;
			this->comboBox_stdin->Location = System::Drawing::Point(6, 30);
			this->comboBox_stdin->Name = L"comboBox_stdin";
			this->comboBox_stdin->Size = System::Drawing::Size(427, 24);
			this->comboBox_stdin->TabIndex = 0;
			this->comboBox_stdin->DragDrop += gcnew System::Windows::Forms::DragEventHandler(this, &Form1::comboBox_something_DragDrop);
			this->comboBox_stdin->DragEnter += gcnew System::Windows::Forms::DragEventHandler(this, &Form1::comboBox_something_DragEnter);
			this->comboBox_stdin->KeyDown += gcnew System::Windows::Forms::KeyEventHandler(this, &Form1::comboBox_stdin_KeyDown);
			// 
			// groupBox_STDOUT
			// 
			this->groupBox_STDOUT->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Bottom) 
				| System::Windows::Forms::AnchorStyles::Left) 
				| System::Windows::Forms::AnchorStyles::Right));
			this->groupBox_STDOUT->Controls->Add(this->button_clear);
			this->groupBox_STDOUT->Controls->Add(this->button_SaveLog);
			this->groupBox_STDOUT->Controls->Add(this->textBox_STDOUT);
			this->groupBox_STDOUT->Location = System::Drawing::Point(12, 417);
			this->groupBox_STDOUT->Name = L"groupBox_STDOUT";
			this->groupBox_STDOUT->Size = System::Drawing::Size(532, 176);
			this->groupBox_STDOUT->TabIndex = 4;
			this->groupBox_STDOUT->TabStop = false;
			this->groupBox_STDOUT->Text = L"�o��(STDOUT, STDERR)";
			// 
			// button_clear
			// 
			this->button_clear->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Right));
			this->button_clear->Location = System::Drawing::Point(438, 92);
			this->button_clear->Name = L"button_clear";
			this->button_clear->Size = System::Drawing::Size(85, 32);
			this->button_clear->TabIndex = 2;
			this->button_clear->Text = L"���O����";
			this->button_clear->UseVisualStyleBackColor = true;
			this->button_clear->Click += gcnew System::EventHandler(this, &Form1::button_clear_Click);
			// 
			// button_SaveLog
			// 
			this->button_SaveLog->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Right));
			this->button_SaveLog->Location = System::Drawing::Point(438, 22);
			this->button_SaveLog->Name = L"button_SaveLog";
			this->button_SaveLog->Size = System::Drawing::Size(85, 64);
			this->button_SaveLog->TabIndex = 1;
			this->button_SaveLog->Text = L"���O�ۑ�";
			this->button_SaveLog->UseVisualStyleBackColor = true;
			this->button_SaveLog->Click += gcnew System::EventHandler(this, &Form1::button_SaveLog_Click);
			// 
			// textBox_STDOUT
			// 
			this->textBox_STDOUT->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Bottom) 
				| System::Windows::Forms::AnchorStyles::Left) 
				| System::Windows::Forms::AnchorStyles::Right));
			this->textBox_STDOUT->Location = System::Drawing::Point(6, 23);
			this->textBox_STDOUT->Multiline = true;
			this->textBox_STDOUT->Name = L"textBox_STDOUT";
			this->textBox_STDOUT->ScrollBars = System::Windows::Forms::ScrollBars::Vertical;
			this->textBox_STDOUT->Size = System::Drawing::Size(427, 147);
			this->textBox_STDOUT->TabIndex = 0;
			this->textBox_STDOUT->KeyDown += gcnew System::Windows::Forms::KeyEventHandler(this, &Form1::textBox_STDOUT_KeyDown);
			// 
			// groupBox_cmdline
			// 
			this->groupBox_cmdline->Anchor = static_cast<System::Windows::Forms::AnchorStyles>(((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Left) 
				| System::Windows::Forms::AnchorStyles::Right));
			this->groupBox_cmdline->Controls->Add(this->textBox_cmdline);
			this->groupBox_cmdline->Location = System::Drawing::Point(12, 165);
			this->groupBox_cmdline->Margin = System::Windows::Forms::Padding(4);
			this->groupBox_cmdline->Name = L"groupBox_cmdline";
			this->groupBox_cmdline->Padding = System::Windows::Forms::Padding(4);
			this->groupBox_cmdline->Size = System::Drawing::Size(532, 108);
			this->groupBox_cmdline->TabIndex = 1;
			this->groupBox_cmdline->TabStop = false;
			this->groupBox_cmdline->Text = L"�R�}���h���C��";
			// 
			// textBox_cmdline
			// 
			this->textBox_cmdline->Anchor = static_cast<System::Windows::Forms::AnchorStyles>(((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Left) 
				| System::Windows::Forms::AnchorStyles::Right));
			this->textBox_cmdline->Location = System::Drawing::Point(7, 30);
			this->textBox_cmdline->Multiline = true;
			this->textBox_cmdline->Name = L"textBox_cmdline";
			this->textBox_cmdline->ScrollBars = System::Windows::Forms::ScrollBars::Vertical;
			this->textBox_cmdline->Size = System::Drawing::Size(426, 64);
			this->textBox_cmdline->TabIndex = 0;
			// 
			// button_exe_cmdline
			// 
			this->button_exe_cmdline->Anchor = static_cast<System::Windows::Forms::AnchorStyles>(((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Left) 
				| System::Windows::Forms::AnchorStyles::Right));
			this->button_exe_cmdline->Font = (gcnew System::Drawing::Font(L"MS UI Gothic", 24, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(128)));
			this->button_exe_cmdline->Location = System::Drawing::Point(12, 280);
			this->button_exe_cmdline->Name = L"button_exe_cmdline";
			this->button_exe_cmdline->Size = System::Drawing::Size(532, 55);
			this->button_exe_cmdline->TabIndex = 2;
			this->button_exe_cmdline->Text = L"���s";
			this->button_exe_cmdline->UseVisualStyleBackColor = true;
			this->button_exe_cmdline->Click += gcnew System::EventHandler(this, &Form1::button_exe_cmdline_Click);
			// 
			// backgroundWorker_exe
			// 
			this->backgroundWorker_exe->DoWork += gcnew System::ComponentModel::DoWorkEventHandler(this, &Form1::backgroundWorker_exe_DoWork);
			this->backgroundWorker_exe->RunWorkerCompleted += gcnew System::ComponentModel::RunWorkerCompletedEventHandler(this, &Form1::backgroundWorker_exe_RunWorkerCompleted);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(555, 602);
			this->Controls->Add(this->groupBox_cmdline);
			this->Controls->Add(this->button_exe_cmdline);
			this->Controls->Add(this->groupBox_STDOUT);
			this->Controls->Add(this->groupBox_STDIN);
			this->Controls->Add(this->groupBox_Exe_Arg);
			this->Font = (gcnew System::Drawing::Font(L"�l�r �S�V�b�N", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(128)));
			this->Icon = (cli::safe_cast<System::Drawing::Icon^  >(resources->GetObject(L"$this.Icon")));
			this->Margin = System::Windows::Forms::Padding(4);
			this->Name = L"Form1";
			this->Text = L"Get Standard Out";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			this->groupBox_Exe_Arg->ResumeLayout(false);
			this->groupBox_STDIN->ResumeLayout(false);
			this->groupBox_STDOUT->ResumeLayout(false);
			this->groupBox_STDOUT->PerformLayout();
			this->groupBox_cmdline->ResumeLayout(false);
			this->groupBox_cmdline->PerformLayout();
			this->ResumeLayout(false);

		}
#pragma endregion

	/////////////////////////////////////////////////////////////////////////////////////
	// static private �����o�ϐ�
	/////////////////////////////////////////////////////////////////////////////////////

	// static�����o�֐��ɓn���|�C���^
	static Form1 ^that_ptr;

	/////////////////////////////////////////////////////////////////////////////////////
	// static private �����o�֐�
	/////////////////////////////////////////////////////////////////////////////////////

	//
	private: static System::Void sttc_OutputDataReceived__( System::Object^ sender, System::Diagnostics::DataReceivedEventArgs^ e );
	//
	private: static System::Void sttc_ErrorDataReceived__( System::Object^ sender, System::Diagnostics::DataReceivedEventArgs^ e );

	/////////////////////////////////////////////////////////////////////////////////////
	// static private �����o�ϐ�
	/////////////////////////////////////////////////////////////////////////////////////

	//
	System::String^ str_filename__;
	//
	System::String^ str_argument__;
	//
	int flag_busy_out__;
	int flag_busy_err__;
	int flag_busy_in__;
	//
	System::Diagnostics::Process^ proc__;
	//
	System::Collections::Generic::Queue< System::String^ > ^que_input__;

	/////////////////////////////////////////////////////////////////////////////////////
	// �蓮�쐬
	/////////////////////////////////////////////////////////////////////////////////////

	//
	private: System::String^ OpenFileDialog__( System::Windows::Forms::ComboBox^ comboBox );
	//
	private: void DispMsg__( System::String ^str );
	//
	private: void DispMsg_out__( System::String ^str );
	//
	private: void DispMsg_err__( System::String ^str );
	//
	private: void DispMsg_in__( System::IO::StreamWriter^ myStreamWriter );
	//
	private: void AddComboBoxItems__();
	//
	private: void AddComboBoxItems_STDIN__();


	/////////////////////////////////////////////////////////////////////////////////////
	// �t�H�[���f�U�C�i����(BackgroundWoker)
	/////////////////////////////////////////////////////////////////////////////////////

	// backgroundWorker(�ʃX���b�h�Ŏ��s)
	private: System::Void backgroundWorker_exe_DoWork(System::Object^  , System::ComponentModel::DoWorkEventArgs^  );
	// backgroundWorker�I�����ɌĂ΂��B
	private: System::Void backgroundWorker_exe_RunWorkerCompleted(System::Object^  , System::ComponentModel::RunWorkerCompletedEventArgs^  );


	/////////////////////////////////////////////////////////////////////////////////////
	// �t�H�[���f�U�C�i����
	/////////////////////////////////////////////////////////////////////////////////////

	// �t�H�[���ǂݍ��ݎ��ɔ����B
	private: System::Void Form1_Load(System::Object^  , System::EventArgs^  );
	// �{�^���������ɌĂяo�����B
	private: System::Void button_something_Click(System::Object^  sender, System::EventArgs^  );
	// 
	private: System::Void comboBox_something_DragDrop(System::Object^  sender, System::Windows::Forms::DragEventArgs^  e);
	// 
	private: System::Void comboBox_something_DragEnter(System::Object^  sender, System::Windows::Forms::DragEventArgs^  e);
	// STDOUT�\���e�L�X�g�{�b�N�X��Ctrl+A��L���ɂ���B
	private: System::Void textBox_STDOUT_KeyDown(System::Object^  , System::Windows::Forms::KeyEventArgs^  e);
	// ���s�t�@�C���C�������ύX���ꂽ���CCommand Line����蒼���B
	private: System::Void comboBox_something_TextChanged(System::Object^  , System::EventArgs^  );
	// �O���v���O���������s
	private: System::Void button_exe_cmdline_Click(System::Object^  , System::EventArgs^  );
	// ���O�ۑ�
	private: System::Void button_SaveLog_Click(System::Object^  , System::EventArgs^  );
	// ���O�N���A
	private: System::Void button_clear_Click(System::Object^  , System::EventArgs^  );

	// �W������
	private: System::Void button_stdin_Click(System::Object^  , System::EventArgs^  );
	// �R���{�{�b�N�X�̃L�[����
	private: System::Void comboBox_something_KeyDown(System::Object^  sender, System::Windows::Forms::KeyEventArgs^  e);
	// �R���{�{�b�N�X�̃L�[����(�W������)
	private: System::Void comboBox_stdin_KeyDown(System::Object^  sender, System::Windows::Forms::KeyEventArgs^  e);

};
}

