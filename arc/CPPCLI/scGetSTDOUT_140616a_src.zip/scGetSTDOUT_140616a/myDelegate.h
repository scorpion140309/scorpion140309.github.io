#pragma once

//

/////////////////////////////////////////////////////////////////////////////////////
// Delegate
/////////////////////////////////////////////////////////////////////////////////////

// �X���b�h�Z�[�t�p
delegate void myDelegate_Disp( System::Windows::Forms::TextBox ^textbox, System::String ^str );
ref struct DLGT_DISP
{
	//
	void DispMsg(
		System::Windows::Forms::TextBox ^textbox,
		System::String ^str
	);
};

