#include "Form1.h"
#include "myDelegate.h"

/////////////////////////////////////////////////////////////////////////////////////
// static �񃁃��o
/////////////////////////////////////////////////////////////////////////////////////

//
static int sttc_SaveLogTxt(
	System::String ^log,
	System::String ^path
	)
{
	System::IO::StreamWriter^ myStream;
	myStream = gcnew System::IO::StreamWriter( path, false );

	cli::array< wchar_t >^ sp_char = { '\n' };
	cli::array< System::String ^ > ^split_msg;
	int line_msg;
	int i;

	split_msg = log->Split( sp_char );
	line_msg = split_msg->Length;

	for( i = 0; i < line_msg && i < line_msg; i ++ ){
		if( split_msg[ i ]->Length ){
			myStream->WriteLine( split_msg[ i ]->Replace( L"\r", L"" ) );
		}
	}

	// �t�@�C�������
	myStream->Close();

	return 0;
}

/////////////////////////////////////////////////////////////////////////////////////
// static private �����o�֐�
/////////////////////////////////////////////////////////////////////////////////////

//�s���o�͂���邽�тɌĂяo�����
System::Void scGetSTDOUT::Form1::sttc_OutputDataReceived__( System::Object^ , System::Diagnostics::DataReceivedEventArgs^ e )
{
	//�o�͂��ꂽ�������\������
	if( e->Data != nullptr && e->Data != "" )
	{
		that_ptr->DispMsg_out__( e->Data + "\r\n" );
	}
}

//ErrorDataReceived�C�x���g�n���h��
System::Void scGetSTDOUT::Form1::sttc_ErrorDataReceived__( System::Object^ , System::Diagnostics::DataReceivedEventArgs^ e )
{
	if( e->Data != nullptr && e->Data != "" )
	{
		//�G���[�o�͂��ꂽ�������\������
		that_ptr->DispMsg_err__( e->Data + "\r\n" );
	}
}


/////////////////////////////////////////////////////////////////////////////////////
// �蓮�쐬
/////////////////////////////////////////////////////////////////////////////////////

//
System::String^ scGetSTDOUT::Form1::OpenFileDialog__( System::Windows::Forms::ComboBox^ comboBox )
{
	System::String ^ret_str = nullptr;
	try
	{
		System::Windows::Forms::OpenFileDialog^ dlg_open;
		System::DateTime ^dt;
		dt = System::DateTime::Now;

		// �t�@�C�����J��
		dlg_open = gcnew System::Windows::Forms::OpenFileDialog;
		dlg_open->FileName = "";
		dlg_open->Filter = "ALL(*.*)|*.*";

		//
		System::Windows::Forms::DialogResult dlg_result;
		dlg_result = dlg_open->ShowDialog();
		if( dlg_result == System::Windows::Forms::DialogResult::OK )
		{
			comboBox->Text = dlg_open->FileName;
		}
	}
	catch( System::Exception ^ex )
	{
		System::String^ str_ex;
		str_ex = ex->Message + "(" + __FILE__ + ","+ __LINE__ + ")";
		System::Windows::Forms::MessageBox::Show(
			str_ex, L"Error",
			System::Windows::Forms::MessageBoxButtons::OK,
			System::Windows::Forms::MessageBoxIcon::Error,
			System::Windows::Forms::MessageBoxDefaultButton::Button1
		);
	}

	return ret_str;
}

// Delegate���g���đ��X���b�h����textBox�ɃA�N�Z�X����B
void scGetSTDOUT::Form1::DispMsg__( System::String ^str_msg )
{
	if( this->InvokeRequired )
	{
		DLGT_DISP ^MyDLGT = gcnew DLGT_DISP();
		myDelegate_Disp ^ pMD = gcnew myDelegate_Disp( MyDLGT, &DLGT_DISP::DispMsg );

		System::IAsyncResult ^asyncResult;
		asyncResult = this->BeginInvoke( pMD, this->textBox_STDOUT, str_msg );
		this->EndInvoke( asyncResult );
	}
}

//
void scGetSTDOUT::Form1::DispMsg_out__( System::String ^str_out )
{
	try
	{
		while( this->flag_busy_err__ || this->flag_busy_in__ );
		this->flag_busy_out__ = 1;

		DispMsg__( str_out );
	}
	catch( ... )
	{
	}

	this->flag_busy_out__ = 0;
}

//
void scGetSTDOUT::Form1::DispMsg_err__( System::String ^str_err )
{
	try
	{
		while( this->flag_busy_out__ || this->flag_busy_in__  );
		this->flag_busy_err__ = 1;

		DispMsg__( str_err );
	}
	catch( ... )
	{
	}

	this->flag_busy_err__ = 0;
}

//
void scGetSTDOUT::Form1::DispMsg_in__( System::IO::StreamWriter^ myStreamWriter )
{
	if( this->que_input__->Count > 0 && !( this->flag_busy_out__ || this->flag_busy_err__ ) )
	{
		this->flag_busy_in__ = 1;
		try
		{
			System::String^ str_input;
			str_input = que_input__->Dequeue();
			myStreamWriter->WriteLine( str_input );

			DispMsg__( str_input + "\r\n" );
		}
		catch( ... )
		{
		}
		this->flag_busy_in__ = 0;
	}
}

//
void scGetSTDOUT::Form1::AddComboBoxItems__()
{
	cli::array< System::Windows::Forms::ComboBox^ > ^ary_comboBox = gcnew cli::array< System::Windows::Forms::ComboBox^  >( 3 ) {
		this->comboBox_exe_file, this->comboBox_arg_0, this->comboBox_arg_1
	};
	System::Windows::Forms::ComboBox^ target_comboBox;
	System::String^ str_cb_text;
	int flag_exist;
	int i, j;


	for( i = 0; i < ary_comboBox->Length; i ++ )
	{
		target_comboBox = ary_comboBox[ i ];
		str_cb_text = target_comboBox->Text;
		if( str_cb_text != "" )
		{
			flag_exist = 0;
			for( j = 0 ; j < target_comboBox->Items->Count; j ++ )
			{
				if( str_cb_text == target_comboBox->Items[ j ]->ToString() )
				{
					flag_exist = 1;
					break;
				}
			}
			if( !flag_exist )
			{
				target_comboBox->Items->Add( str_cb_text );
			}
		}
	}
}


//
void scGetSTDOUT::Form1::AddComboBoxItems_STDIN__()
{
	System::Windows::Forms::ComboBox^ target_comboBox;
	System::String^ str_cb_text;
	int flag_exist;
	int j;

	target_comboBox = this->comboBox_stdin;
	str_cb_text = target_comboBox->Text;
	if( str_cb_text != "" )
	{
		flag_exist = 0;
		for( j = 0 ; j < target_comboBox->Items->Count; j ++ )
		{
			if( str_cb_text == target_comboBox->Items[ j ]->ToString() )
			{
				flag_exist = 1;
				break;
			}
		}
		if( !flag_exist )
		{
			target_comboBox->Items->Add( str_cb_text );
		}
	}
}


/////////////////////////////////////////////////////////////////////////////////////
// �t�H�[���f�U�C�i����(BackgroundWoker)
/////////////////////////////////////////////////////////////////////////////////////

// backgroundWorker(�ʃX���b�h�Ŏ��s)
System::Void scGetSTDOUT::Form1::backgroundWorker_exe_DoWork(System::Object^  , System::ComponentModel::DoWorkEventArgs^  )
{
	try
	{
		//
		scGetSTDOUT::Form1::that_ptr = this;
		System::IO::StreamWriter^ myStreamWriter;
		bool flag_end;

		// for���[�v���Ŗ��񏉊���
		this->proc__ = gcnew System::Diagnostics::Process();
		this->proc__->StartInfo->WorkingDirectory = System::IO::Path::GetDirectoryName( this->str_filename__ );
		this->proc__->StartInfo->FileName = this->str_filename__;
		this->proc__->StartInfo->Arguments = this->str_argument__;
		this->proc__->StartInfo->RedirectStandardOutput = true;
		this->proc__->StartInfo->RedirectStandardError = true;
		this->proc__->StartInfo->RedirectStandardInput = true;
		this->proc__->StartInfo->WindowStyle = System::Diagnostics::ProcessWindowStyle::Hidden;
		this->proc__->StartInfo->CreateNoWindow = true;
		this->proc__->StartInfo->UseShellExecute = false;
		this->proc__->OutputDataReceived += gcnew System::Diagnostics::DataReceivedEventHandler( &Form1::sttc_OutputDataReceived__ );
		this->proc__->ErrorDataReceived += gcnew System::Diagnostics::DataReceivedEventHandler( &Form1::sttc_ErrorDataReceived__ );

		this->proc__->Start();
		this->proc__->BeginOutputReadLine();
		this->proc__->BeginErrorReadLine();
		myStreamWriter = this->proc__->StandardInput;
		do
		{
			flag_end = this->proc__->WaitForExit( 100 );
			this->DispMsg_in__( myStreamWriter );
		} while( flag_end == false );

		myStreamWriter->Close();
		this->proc__->Close();

	}
	catch( System::Exception ^ex )
	{
		System::Windows::Forms::MessageBox::Show(
			ex->Message, "Error",
			System::Windows::Forms::MessageBoxButtons::OK,
			System::Windows::Forms::MessageBoxIcon::Error,
			System::Windows::Forms::MessageBoxDefaultButton::Button1
		);
	}
	this->proc__ = nullptr;
}

// backgroundWorker�I�����ɌĂ΂��B
System::Void scGetSTDOUT::Form1::backgroundWorker_exe_RunWorkerCompleted(System::Object^  , System::ComponentModel::RunWorkerCompletedEventArgs^  )
{
	this->button_stdin->Enabled = false;
	this->button_exe_cmdline->Text = "���s";
	this->button_exe_cmdline->ForeColor = System::Drawing::Color::Black;

	AddComboBoxItems__();
}

/////////////////////////////////////////////////////////////////////////////////////
// �t�H�[���f�U�C�i����
/////////////////////////////////////////////////////////////////////////////////////

// �t�H�[���ǂݍ��ݎ��ɔ����B
System::Void scGetSTDOUT::Form1::Form1_Load(System::Object^  , System::EventArgs^  )
{
#ifdef _DEBUG
	this->comboBox_exe_file->Text = "ipconfig";
	this->comboBox_arg_0->Text = "/all";
//	this->comboBox_exe_file->Text = "std_out_err_in_test.exe";
	this->comboBox_exe_file->Text = "std_out_err_in_test.exe";
	this->comboBox_arg_0->Text = "";
#endif

	this->button_stdin->Enabled = false;
	this->flag_busy_out__ = 0;
	this->flag_busy_err__ = 0;
	this->flag_busy_in__ = 0;
	this->proc__ = nullptr;
	this->que_input__ = gcnew System::Collections::Generic::Queue< System::String^ >();


}

// �{�^���������ɌĂяo�����B
System::Void scGetSTDOUT::Form1::button_something_Click(System::Object^  sender, System::EventArgs^  )
{
	// ���s�t�@�C��
	if( sender->Equals( this->button_exe_file ) )
	{
		OpenFileDialog__( this->comboBox_exe_file );
	}
	// ����
	else if( sender->Equals( this->button_arg_0 ) )
	{
		OpenFileDialog__( this->comboBox_arg_0 );
	}
	// ����
	else if( sender->Equals( this->button_arg_1 ) )
	{
		OpenFileDialog__( this->comboBox_arg_1 );
	}


}

//
System::Void scGetSTDOUT::Form1::comboBox_something_DragDrop(System::Object^  sender, System::Windows::Forms::DragEventArgs^  e)
{
	cli::array< System::String^ >^ ary_str;

	// �h���b�v���ꂽ���̓t�@�C�����o�̓t�@�C���̃p�X������ɕϊ�
	ary_str = static_cast< cli::array<System::String^>^ >(
		e->Data->GetData( System::Windows::Forms::DataFormats::FileDrop, false )
	);

	if( sender->Equals( this->comboBox_exe_file ) )
	{
		this->comboBox_exe_file->Text = ary_str[ 0 ];
	}
	else if( sender->Equals( this->comboBox_arg_0 ) )
	{
		this->comboBox_arg_0->Text = ary_str[ 0 ];
	}
	else if( sender->Equals( this->comboBox_arg_1 ) )
	{
		this->comboBox_arg_1->Text = ary_str[ 0 ];
	}
	else if( sender->Equals( this->comboBox_stdin ) )
	{
		this->comboBox_stdin->Text = ary_str[ 0 ];
	}

}

//
System::Void scGetSTDOUT::Form1::comboBox_something_DragEnter(System::Object^  , System::Windows::Forms::DragEventArgs^  e)
{
	// �h���b�v����悤�Ƃ��Ă���f�[�^���A�t�@�C���̎������󂯕t����
	if( e->Data->GetDataPresent( System::Windows::Forms::DataFormats::FileDrop ) )
	{
		e->Effect = System::Windows::Forms::DragDropEffects::All;
	}
	else{
		e->Effect = System::Windows::Forms::DragDropEffects::None;
	}
}


// STDOUT�\���e�L�X�g�{�b�N�X��Ctrl+A��L���ɂ���B
System::Void scGetSTDOUT::Form1::textBox_STDOUT_KeyDown(System::Object^  , System::Windows::Forms::KeyEventArgs^  e)
{
	System::Windows::Forms::Keys key_ctrl, key_A;
	key_ctrl	= System::Windows::Forms::Keys::Control;
	key_A		= System::Windows::Forms::Keys::A;
	if( ( e->Modifiers & key_ctrl ) == key_ctrl && e->KeyCode == key_A ){
		this->textBox_STDOUT ->SelectAll();
	}
}

// ���s�t�@�C���C�������ύX���ꂽ���CCommand Line����蒼���B
System::Void scGetSTDOUT::Form1::comboBox_something_TextChanged(System::Object^  , System::EventArgs^  )
{
	this->str_filename__ = this->comboBox_exe_file->Text->ToString();
	this->str_argument__ = this->comboBox_arg_0->Text->ToString() + this->comboBox_arg_1->Text->ToString();

	this->textBox_cmdline->Text = str_filename__ + " " + str_argument__;


}

// �O���v���O���������s
System::Void scGetSTDOUT::Form1::button_exe_cmdline_Click(System::Object^  , System::EventArgs^  )
{
	if( this->comboBox_exe_file->Text != "" )
	{
		if( this->proc__ == nullptr )
		{
			this->button_stdin->Enabled = true;
			this->button_exe_cmdline->Text = "���~";
			this->button_exe_cmdline->ForeColor = System::Drawing::Color::Red;
			// �X���b�h�J�n
			this->backgroundWorker_exe->RunWorkerAsync();
		}
		else
		{
			this->proc__->Kill();
			this->button_stdin->Enabled = false;
			this->button_exe_cmdline->Text = "���s";
			this->button_exe_cmdline->ForeColor = System::Drawing::Color::Black;

		}
	}
	else
	{
		this->comboBox_exe_file->BackColor = System::Drawing::Color::Pink;
		System::Windows::Forms::MessageBox::Show(
			"\"Exe File\" is Empty.", L"Error",
			System::Windows::Forms::MessageBoxButtons::OK,
			System::Windows::Forms::MessageBoxIcon::Error,
			System::Windows::Forms::MessageBoxDefaultButton::Button1
		);
		this->comboBox_exe_file->BackColor = System::Drawing::Color::White;
	}
}


// ���O�ۑ�
System::Void scGetSTDOUT::Form1::button_SaveLog_Click(System::Object^  , System::EventArgs^  )
{
	int result = -1;
	try
	{
		System::Windows::Forms::SaveFileDialog^ dlg_save_log;
		System::DateTime ^dt;
		dt = System::DateTime::Now;

		// �t�@�C�����J��
		dlg_save_log = gcnew System::Windows::Forms::SaveFileDialog;
		dlg_save_log->FileName = L"scGetSTDOUT_" + dt->ToString( L"yyyyMMdd_HHmm" );
		dlg_save_log->Filter = L"�e�L�X�g�t�@�C��(*.txt;*.log)|*.txt;*.log";

		//
		System::Windows::Forms::DialogResult dlg_result;
		dlg_result = dlg_save_log->ShowDialog();
		if( dlg_result == System::Windows::Forms::DialogResult::OK )
		{
			result = sttc_SaveLogTxt( this->textBox_STDOUT->Text, dlg_save_log->FileName );
		}
	}
	catch( System::Exception ^ex )
	{
		System::String^ str_ex;
		str_ex = ex->Message + "(" + __FILE__ + ","+ __LINE__ + ")";
		System::Windows::Forms::MessageBox::Show(
			str_ex, L"Error",
			System::Windows::Forms::MessageBoxButtons::OK,
			System::Windows::Forms::MessageBoxIcon::Error,
			System::Windows::Forms::MessageBoxDefaultButton::Button1
		);
	}
}

// ���O�N���A
System::Void scGetSTDOUT::Form1::button_clear_Click(System::Object^  , System::EventArgs^  )
{
	this->textBox_STDOUT->Clear();
}

// �W������
System::Void scGetSTDOUT::Form1::button_stdin_Click(System::Object^  , System::EventArgs^  )
{
	//
	if( this->comboBox_stdin->Text != "" && this->button_stdin->Enabled )
	{
		scGetSTDOUT::Form1::that_ptr = this;
		this->que_input__->Enqueue( this->comboBox_stdin->Text );
		AddComboBoxItems_STDIN__();
	}
}

// �R���{�{�b�N�X�̃L�[����
System::Void scGetSTDOUT::Form1::comboBox_something_KeyDown(System::Object^  sender, System::Windows::Forms::KeyEventArgs^  e)
{
	if( e->KeyCode == System::Windows::Forms::Keys::Enter )
	{
		this->button_stdin->Focus();
		this->button_exe_cmdline_Click( sender, e );
	}
}

// �R���{�{�b�N�X�̃L�[����(�W������)
System::Void scGetSTDOUT::Form1::comboBox_stdin_KeyDown(System::Object^  sender, System::Windows::Forms::KeyEventArgs^  e)
{
	if( e->KeyCode == System::Windows::Forms::Keys::Enter )
	{
		this->button_stdin_Click( sender, e );
	}
}
