﻿//
namespace FTP_test
{
	public partial class Form1 : System.Windows.Forms.Form
	{
		////////////////////////////////////////////////////////////
		//
		// 手動で追加されたメソッド
		//
		////////////////////////////////////////////////////////////

		// 
		private System.Net.FtpWebRequest CreateFtpWebReq__()
		{
			System.Net.FtpWebRequest ret_ftpReq = null;

			try
			{
				System.Net.FtpWebRequest tmp_ftpReq = null;

				// FTP転送用のURI
				System.Uri uri_upload = new System.Uri(this.textBox_uri.Text);
				tmp_ftpReq = (System.Net.FtpWebRequest)System.Net.WebRequest.Create(uri_upload);

				// ログインユーザー名とパスワードを設定
				tmp_ftpReq.Credentials = new System.Net.NetworkCredential(this.textBox_user_id.Text, this.textBox_user_password.Text);
				// FTP サーバーに送信するためのコマンドを取得または設定
				// WebRequest.Method をオーバーライド
				tmp_ftpReq.Method = System.Net.WebRequestMethods.Ftp.UploadFile;
				// 要求の完了後に FTP サーバーへの制御接続を閉じるかどうか
				tmp_ftpReq.KeepAlive = this.checkedListBox_ftp_setting.GetItemChecked(0);
				// ASCII or Binary
				tmp_ftpReq.UseBinary = this.checkedListBox_ftp_setting.GetItemChecked(1);
				// PASVモード 無効/有効
				tmp_ftpReq.UsePassive = this.checkedListBox_ftp_setting.GetItemChecked(2);
				// プロキシ
				tmp_ftpReq.Proxy = null;

				//
				ret_ftpReq = tmp_ftpReq;
			}
			catch (System.Exception ex)
			{
				System.Windows.Forms.MessageBox.Show
				(
					ex.Message, "Exception(CreateFtpWebReq__)",
					System.Windows.Forms.MessageBoxButtons.OK,
					System.Windows.Forms.MessageBoxIcon.Error
				);

			}
			return ret_ftpReq;
		}
		// 
		private void Upload__()
		{
			if (
				this.textBox_hostname.Text != "" &&
				this.textBox_filename.Text != "" &&
				this.textBox_user_id.Text != "" &&
				this.textBox_user_password.Text != ""
				)
			{
				//
				System.Net.FtpWebRequest ftpReq;

				// FtpWebRequestの作成
				ftpReq = CreateFtpWebReq__();

				if (ftpReq != null)
				{
					//ファイルをアップロードするためのStreamを取得
					System.IO.Stream reqStrm = ftpReq.GetRequestStream();
					//アップロードするファイルを開く
					System.IO.FileStream fs = new System.IO.FileStream(this.textBox_filename.Text, System.IO.FileMode.Open, System.IO.FileAccess.Read);

					try
					{
						//アップロードStreamに書き込む
						const int SEND_BUF_SIZE = 0x10000;
						byte[] buffer = new byte[SEND_BUF_SIZE];
						int readSize = 0;

						while (true)
						{
							// ファイルから読む
							readSize = fs.Read(buffer, 0, buffer.Length);
							if (readSize == 0)
							{
								break;
							}
							// サーバ上に書き込む
							reqStrm.Write(buffer, 0, readSize);
						}

					}
					catch (System.Exception ex)
					{
						System.Windows.Forms.MessageBox.Show
						(
							ex.Message, "Exception(Upload)",
							System.Windows.Forms.MessageBoxButtons.OK,
							System.Windows.Forms.MessageBoxIcon.Error
						);

					}
					finally
					{
						//
						fs.Close();
						reqStrm.Close();
					}

					//FtpWebResponseを取得
					System.Net.FtpWebResponse ftpRes = (System.Net.FtpWebResponse)ftpReq.GetResponse();
					//FTPサーバーから送信されたステータスを表示
					this.textBox_log.AppendText("StatusCode:" + ftpRes.StatusCode + "\r\n");
					this.textBox_log.AppendText("StatusDescription :" + ftpRes.StatusDescription);
					//閉じる
					ftpRes.Close();
				}
			}
		}

		//
		private void MakeURI__()
		{
			System.String str_tmp_uri = "<none>";

			if (this.textBox_hostname.Text != "")
			{
				str_tmp_uri = "ftp://" + this.textBox_hostname.Text;
				str_tmp_uri += "/";
				str_tmp_uri += this.textBox_server_root_folder.Text;
				str_tmp_uri += this.textBox_server_folder_url.Text;
				str_tmp_uri += "/";
				str_tmp_uri += System.IO.Path.GetFileName(this.textBox_filename.Text);
			}
			this.textBox_uri.Text = str_tmp_uri;
		}

		//
		private void MakeURL_for_DL__()
		{
			System.String str_tmp_uri = "<none>";

			if (this.textBox_hostname.Text != "")
			{
				str_tmp_uri = "http://" + this.textBox_hostname.Text;
				str_tmp_uri += this.textBox_server_folder_url.Text;
				str_tmp_uri += "/";
				str_tmp_uri += System.IO.Path.GetFileName(this.textBox_filename.Text);
			}
			this.linkLabel_URL_for_DL.Text = str_tmp_uri;
		}


		////////////////////////////////////////////////////////////
		//
		// InitializeComponent
		//
		////////////////////////////////////////////////////////////

		//
		public Form1()
		{
			InitializeComponent();
		}

		////////////////////////////////////////////////////////////
		//
		// フォーム デザイナーで生成されたコード
		//
		////////////////////////////////////////////////////////////

		//
		private void button_upload_Click(System.Object sender, System.EventArgs e)
		{
			try
			{
				Upload__();
			}
			catch (System.Exception ex)
			{
				System.Windows.Forms.MessageBox.Show
				(
					ex.Message, "Exception",
					System.Windows.Forms.MessageBoxButtons.OK,
					System.Windows.Forms.MessageBoxIcon.Error
				);

			}
		}

		//
        private void textBox_something_DragDrop(System.Object sender, System.Windows.Forms.DragEventArgs e)
        {
			System.String[] ary_str;

			// ドロップされた入力ファイルを出力ファイルのパス文字列に変換
			ary_str = (System.String[])(
				e.Data.GetData(System.Windows.Forms.DataFormats.FileDrop, false)
			);

			//
			if (sender.Equals(this.textBox_filename))
			{
				this.textBox_filename.Text = ary_str[0];
			}
		}

		//
		private void textBox_something_DragEnter(System.Object sender, System.Windows.Forms.DragEventArgs e)
        {
			// ドロップされようとしているデータが、ファイルの時だけ受け付ける
			if (e.Data.GetDataPresent(System.Windows.Forms.DataFormats.FileDrop))
			{
				e.Effect = System.Windows.Forms.DragDropEffects.All;
			}
			else
			{
				e.Effect = System.Windows.Forms.DragDropEffects.None;
			}
		}


        // フォームが呼ばれた時、一度だけ実行される。
        private void Form1_Load(System.Object sender, System.EventArgs e)
        {
			// binary
			this.checkedListBox_ftp_setting.SetItemChecked(1, true);

			this.textBox_something_TextChanged(this.textBox_filename, null);
        }

		//
		private void textBox_something_TextChanged(System.Object sender, System.EventArgs e)
		{
			if (
				sender.Equals(this.textBox_hostname) ||
				sender.Equals(this.textBox_server_root_folder) ||
				sender.Equals(this.textBox_server_folder_url) ||
				sender.Equals(this.textBox_filename)
				)
			{
				MakeURI__();
				MakeURL_for_DL__();
			}
		}

		//
		private void button_filename_Click(System.Object sender, System.EventArgs e)
		{
			System.Windows.Forms.DialogResult dlg_result;
			System.Windows.Forms.OpenFileDialog dlg_open = new System.Windows.Forms.OpenFileDialog();
			dlg_result = dlg_open.ShowDialog();

			if (dlg_result == System.Windows.Forms.DialogResult.OK)
			{
				this.textBox_filename.Text = dlg_open.FileName;
			}

		}

		//
		private void linkLabel_URL_for_DL_LinkClicked(System.Object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
		{
			if (
				this.linkLabel_URL_for_DL.Text != "" &&
				this.linkLabel_URL_for_DL.Text != "<none>"
				)
			{
				System.Diagnostics.Process.Start(this.linkLabel_URL_for_DL.Text);
			}
		}
	}
}
