﻿namespace FTP_test
{
	partial class Form1
	{
		/// <summary>
		/// 必要なデザイナー変数です。
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 使用中のリソースをすべてクリーンアップします。
		/// </summary>
		/// <param name="disposing">マネージ リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows フォーム デザイナーで生成されたコード

		/// <summary>
		/// デザイナー サポートに必要なメソッドです。このメソッドの内容を
		/// コード エディターで変更しないでください。
		/// </summary>
		private void InitializeComponent()
		{
            this.label_folder_server = new System.Windows.Forms.Label();
            this.textBox_hostname = new System.Windows.Forms.TextBox();
            this.textBox_filename = new System.Windows.Forms.TextBox();
            this.groupBox_server = new System.Windows.Forms.GroupBox();
            this.textBox_server_folder_url = new System.Windows.Forms.TextBox();
            this.label_server_folder_url = new System.Windows.Forms.Label();
            this.label_user_id = new System.Windows.Forms.Label();
            this.textBox_user_password = new System.Windows.Forms.TextBox();
            this.textBox_server_root_folder = new System.Windows.Forms.TextBox();
            this.textBox_user_id = new System.Windows.Forms.TextBox();
            this.label_server_root_folder = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox_uri = new System.Windows.Forms.TextBox();
            this.label_uri = new System.Windows.Forms.Label();
            this.button_upload = new System.Windows.Forms.Button();
            this.groupBox_Iog = new System.Windows.Forms.GroupBox();
            this.textBox_log = new System.Windows.Forms.TextBox();
            this.groupBox_url = new System.Windows.Forms.GroupBox();
            this.linkLabel_URL_for_DL = new System.Windows.Forms.LinkLabel();
            this.label_URL_for_DL = new System.Windows.Forms.Label();
            this.groupBox_ftp_setting = new System.Windows.Forms.GroupBox();
            this.button_filename = new System.Windows.Forms.Button();
            this.checkedListBox_ftp_setting = new System.Windows.Forms.CheckedListBox();
            this.groupBox_ftp_req = new System.Windows.Forms.GroupBox();
            this.groupBox_server.SuspendLayout();
            this.groupBox_Iog.SuspendLayout();
            this.groupBox_url.SuspendLayout();
            this.groupBox_ftp_setting.SuspendLayout();
            this.groupBox_ftp_req.SuspendLayout();
            this.SuspendLayout();
            // 
            // label_folder_server
            // 
            this.label_folder_server.AutoSize = true;
            this.label_folder_server.Location = new System.Drawing.Point(8, 20);
            this.label_folder_server.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_folder_server.Name = "label_folder_server";
            this.label_folder_server.Size = new System.Drawing.Size(40, 16);
            this.label_folder_server.TabIndex = 0;
            this.label_folder_server.Text = "Host";
            // 
            // textBox_hostname
            // 
            this.textBox_hostname.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_hostname.Location = new System.Drawing.Point(11, 41);
            this.textBox_hostname.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_hostname.Name = "textBox_hostname";
            this.textBox_hostname.Size = new System.Drawing.Size(328, 23);
            this.textBox_hostname.TabIndex = 1;
            this.textBox_hostname.TextChanged += new System.EventHandler(this.textBox_something_TextChanged);
            // 
            // textBox_filename
            // 
            this.textBox_filename.AllowDrop = true;
            this.textBox_filename.Location = new System.Drawing.Point(6, 65);
            this.textBox_filename.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_filename.Multiline = true;
            this.textBox_filename.Name = "textBox_filename";
            this.textBox_filename.Size = new System.Drawing.Size(331, 72);
            this.textBox_filename.TabIndex = 1;
            this.textBox_filename.TextChanged += new System.EventHandler(this.textBox_something_TextChanged);
            this.textBox_filename.DragDrop += new System.Windows.Forms.DragEventHandler(this.textBox_something_DragDrop);
            this.textBox_filename.DragEnter += new System.Windows.Forms.DragEventHandler(this.textBox_something_DragEnter);
            // 
            // groupBox_server
            // 
            this.groupBox_server.Controls.Add(this.textBox_server_folder_url);
            this.groupBox_server.Controls.Add(this.label_server_folder_url);
            this.groupBox_server.Controls.Add(this.label_user_id);
            this.groupBox_server.Controls.Add(this.textBox_user_password);
            this.groupBox_server.Controls.Add(this.textBox_server_root_folder);
            this.groupBox_server.Controls.Add(this.textBox_user_id);
            this.groupBox_server.Controls.Add(this.label_server_root_folder);
            this.groupBox_server.Controls.Add(this.label2);
            this.groupBox_server.Controls.Add(this.label_folder_server);
            this.groupBox_server.Controls.Add(this.textBox_hostname);
            this.groupBox_server.Location = new System.Drawing.Point(16, 16);
            this.groupBox_server.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox_server.Name = "groupBox_server";
            this.groupBox_server.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox_server.Size = new System.Drawing.Size(347, 223);
            this.groupBox_server.TabIndex = 0;
            this.groupBox_server.TabStop = false;
            this.groupBox_server.Text = "Server";
            // 
            // textBox_server_folder_url
            // 
            this.textBox_server_folder_url.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_server_folder_url.Location = new System.Drawing.Point(11, 139);
            this.textBox_server_folder_url.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_server_folder_url.Name = "textBox_server_folder_url";
            this.textBox_server_folder_url.Size = new System.Drawing.Size(328, 23);
            this.textBox_server_folder_url.TabIndex = 5;
            this.textBox_server_folder_url.TextChanged += new System.EventHandler(this.textBox_something_TextChanged);
            // 
            // label_server_folder_url
            // 
            this.label_server_folder_url.AutoSize = true;
            this.label_server_folder_url.Location = new System.Drawing.Point(8, 118);
            this.label_server_folder_url.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_server_folder_url.Name = "label_server_folder_url";
            this.label_server_folder_url.Size = new System.Drawing.Size(80, 16);
            this.label_server_folder_url.TabIndex = 4;
            this.label_server_folder_url.Text = "Directory";
            // 
            // label_user_id
            // 
            this.label_user_id.AutoSize = true;
            this.label_user_id.Location = new System.Drawing.Point(8, 166);
            this.label_user_id.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_user_id.Name = "label_user_id";
            this.label_user_id.Size = new System.Drawing.Size(24, 16);
            this.label_user_id.TabIndex = 6;
            this.label_user_id.Text = "ID";
            // 
            // textBox_user_password
            // 
            this.textBox_user_password.Location = new System.Drawing.Point(163, 187);
            this.textBox_user_password.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_user_password.Name = "textBox_user_password";
            this.textBox_user_password.PasswordChar = '*';
            this.textBox_user_password.Size = new System.Drawing.Size(144, 23);
            this.textBox_user_password.TabIndex = 9;
            // 
            // textBox_server_root_folder
            // 
            this.textBox_server_root_folder.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_server_root_folder.Location = new System.Drawing.Point(11, 89);
            this.textBox_server_root_folder.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_server_root_folder.Name = "textBox_server_root_folder";
            this.textBox_server_root_folder.Size = new System.Drawing.Size(328, 23);
            this.textBox_server_root_folder.TabIndex = 3;
            this.textBox_server_root_folder.TextChanged += new System.EventHandler(this.textBox_something_TextChanged);
            // 
            // textBox_user_id
            // 
            this.textBox_user_id.Location = new System.Drawing.Point(11, 187);
            this.textBox_user_id.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_user_id.Name = "textBox_user_id";
            this.textBox_user_id.Size = new System.Drawing.Size(144, 23);
            this.textBox_user_id.TabIndex = 7;
            // 
            // label_server_root_folder
            // 
            this.label_server_root_folder.AutoSize = true;
            this.label_server_root_folder.Location = new System.Drawing.Point(8, 68);
            this.label_server_root_folder.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_server_root_folder.Name = "label_server_root_folder";
            this.label_server_root_folder.Size = new System.Drawing.Size(120, 16);
            this.label_server_root_folder.TabIndex = 2;
            this.label_server_root_folder.Text = "Root Directory";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(163, 167);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 16);
            this.label2.TabIndex = 8;
            this.label2.Text = "パスワード";
            // 
            // textBox_uri
            // 
            this.textBox_uri.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_uri.Location = new System.Drawing.Point(11, 41);
            this.textBox_uri.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_uri.Multiline = true;
            this.textBox_uri.Name = "textBox_uri";
            this.textBox_uri.ReadOnly = true;
            this.textBox_uri.Size = new System.Drawing.Size(328, 48);
            this.textBox_uri.TabIndex = 1;
            // 
            // label_uri
            // 
            this.label_uri.AutoSize = true;
            this.label_uri.Location = new System.Drawing.Point(8, 20);
            this.label_uri.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_uri.Name = "label_uri";
            this.label_uri.Size = new System.Drawing.Size(32, 16);
            this.label_uri.TabIndex = 0;
            this.label_uri.Text = "URI";
            // 
            // button_upload
            // 
            this.button_upload.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.button_upload.Location = new System.Drawing.Point(16, 511);
            this.button_upload.Margin = new System.Windows.Forms.Padding(4);
            this.button_upload.Name = "button_upload";
            this.button_upload.Size = new System.Drawing.Size(702, 34);
            this.button_upload.TabIndex = 5;
            this.button_upload.Text = "Upload";
            this.button_upload.UseVisualStyleBackColor = true;
            this.button_upload.Click += new System.EventHandler(this.button_upload_Click);
            // 
            // groupBox_Iog
            // 
            this.groupBox_Iog.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox_Iog.Controls.Add(this.textBox_log);
            this.groupBox_Iog.Location = new System.Drawing.Point(16, 353);
            this.groupBox_Iog.Name = "groupBox_Iog";
            this.groupBox_Iog.Size = new System.Drawing.Size(702, 149);
            this.groupBox_Iog.TabIndex = 4;
            this.groupBox_Iog.TabStop = false;
            this.groupBox_Iog.Text = "Log";
            // 
            // textBox_log
            // 
            this.textBox_log.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_log.Location = new System.Drawing.Point(9, 22);
            this.textBox_log.Multiline = true;
            this.textBox_log.Name = "textBox_log";
            this.textBox_log.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox_log.Size = new System.Drawing.Size(685, 121);
            this.textBox_log.TabIndex = 0;
            // 
            // groupBox_url
            // 
            this.groupBox_url.Controls.Add(this.linkLabel_URL_for_DL);
            this.groupBox_url.Controls.Add(this.label_URL_for_DL);
            this.groupBox_url.Controls.Add(this.textBox_uri);
            this.groupBox_url.Controls.Add(this.label_uri);
            this.groupBox_url.Location = new System.Drawing.Point(371, 16);
            this.groupBox_url.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox_url.Name = "groupBox_url";
            this.groupBox_url.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox_url.Size = new System.Drawing.Size(347, 179);
            this.groupBox_url.TabIndex = 1;
            this.groupBox_url.TabStop = false;
            this.groupBox_url.Text = "URI,URL";
            // 
            // linkLabel_URL_for_DL
            // 
            this.linkLabel_URL_for_DL.AutoEllipsis = true;
            this.linkLabel_URL_for_DL.AutoSize = true;
            this.linkLabel_URL_for_DL.Location = new System.Drawing.Point(8, 118);
            this.linkLabel_URL_for_DL.Name = "linkLabel_URL_for_DL";
            this.linkLabel_URL_for_DL.Size = new System.Drawing.Size(56, 16);
            this.linkLabel_URL_for_DL.TabIndex = 4;
            this.linkLabel_URL_for_DL.TabStop = true;
            this.linkLabel_URL_for_DL.Text = "<none>";
            this.linkLabel_URL_for_DL.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel_URL_for_DL_LinkClicked);
            // 
            // label_URL_for_DL
            // 
            this.label_URL_for_DL.AutoSize = true;
            this.label_URL_for_DL.Location = new System.Drawing.Point(8, 94);
            this.label_URL_for_DL.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_URL_for_DL.Name = "label_URL_for_DL";
            this.label_URL_for_DL.Size = new System.Drawing.Size(32, 16);
            this.label_URL_for_DL.TabIndex = 2;
            this.label_URL_for_DL.Text = "URL";
            // 
            // groupBox_ftp_setting
            // 
            this.groupBox_ftp_setting.Controls.Add(this.button_filename);
            this.groupBox_ftp_setting.Controls.Add(this.textBox_filename);
            this.groupBox_ftp_setting.Location = new System.Drawing.Point(371, 203);
            this.groupBox_ftp_setting.Name = "groupBox_ftp_setting";
            this.groupBox_ftp_setting.Size = new System.Drawing.Size(347, 144);
            this.groupBox_ftp_setting.TabIndex = 3;
            this.groupBox_ftp_setting.TabStop = false;
            this.groupBox_ftp_setting.Text = "Local File";
            // 
            // button_filename
            // 
            this.button_filename.Location = new System.Drawing.Point(6, 22);
            this.button_filename.Name = "button_filename";
            this.button_filename.Size = new System.Drawing.Size(128, 36);
            this.button_filename.TabIndex = 0;
            this.button_filename.Text = "Select File";
            this.button_filename.UseVisualStyleBackColor = true;
            this.button_filename.Click += new System.EventHandler(this.button_filename_Click);
            // 
            // checkedListBox_ftp_setting
            // 
            this.checkedListBox_ftp_setting.FormattingEnabled = true;
            this.checkedListBox_ftp_setting.Items.AddRange(new object[] {
            "KeepAlive",
            "UseBinary",
            "UsePassive"});
            this.checkedListBox_ftp_setting.Location = new System.Drawing.Point(14, 22);
            this.checkedListBox_ftp_setting.Name = "checkedListBox_ftp_setting";
            this.checkedListBox_ftp_setting.Size = new System.Drawing.Size(151, 58);
            this.checkedListBox_ftp_setting.TabIndex = 0;
            // 
            // groupBox_ftp_req
            // 
            this.groupBox_ftp_req.Controls.Add(this.checkedListBox_ftp_setting);
            this.groupBox_ftp_req.Location = new System.Drawing.Point(16, 247);
            this.groupBox_ftp_req.Name = "groupBox_ftp_req";
            this.groupBox_ftp_req.Size = new System.Drawing.Size(347, 100);
            this.groupBox_ftp_req.TabIndex = 2;
            this.groupBox_ftp_req.TabStop = false;
            this.groupBox_ftp_req.Text = "FTP Req";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(731, 561);
            this.Controls.Add(this.groupBox_ftp_req);
            this.Controls.Add(this.groupBox_ftp_setting);
            this.Controls.Add(this.groupBox_url);
            this.Controls.Add(this.groupBox_Iog);
            this.Controls.Add(this.button_upload);
            this.Controls.Add(this.groupBox_server);
            this.Font = new System.Drawing.Font("ＭＳ ゴシック", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "FTP Test";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox_server.ResumeLayout(false);
            this.groupBox_server.PerformLayout();
            this.groupBox_Iog.ResumeLayout(false);
            this.groupBox_Iog.PerformLayout();
            this.groupBox_url.ResumeLayout(false);
            this.groupBox_url.PerformLayout();
            this.groupBox_ftp_setting.ResumeLayout(false);
            this.groupBox_ftp_setting.PerformLayout();
            this.groupBox_ftp_req.ResumeLayout(false);
            this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Label label_folder_server;
		private System.Windows.Forms.TextBox textBox_hostname;
		private System.Windows.Forms.TextBox textBox_filename;
		private System.Windows.Forms.GroupBox groupBox_server;
		private System.Windows.Forms.Label label_user_id;
		private System.Windows.Forms.TextBox textBox_user_password;
		private System.Windows.Forms.TextBox textBox_user_id;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button button_upload;
        private System.Windows.Forms.TextBox textBox_uri;
        private System.Windows.Forms.Label label_uri;
        private System.Windows.Forms.GroupBox groupBox_Iog;
        private System.Windows.Forms.TextBox textBox_log;
        private System.Windows.Forms.TextBox textBox_server_root_folder;
        private System.Windows.Forms.Label label_server_root_folder;
        private System.Windows.Forms.GroupBox groupBox_url;
        private System.Windows.Forms.Label label_URL_for_DL;
		private System.Windows.Forms.GroupBox groupBox_ftp_setting;
		private System.Windows.Forms.Button button_filename;
		private System.Windows.Forms.CheckedListBox checkedListBox_ftp_setting;
		private System.Windows.Forms.TextBox textBox_server_folder_url;
		private System.Windows.Forms.Label label_server_folder_url;
		private System.Windows.Forms.GroupBox groupBox_ftp_req;
		private System.Windows.Forms.LinkLabel linkLabel_URL_for_DL;
	}
}

