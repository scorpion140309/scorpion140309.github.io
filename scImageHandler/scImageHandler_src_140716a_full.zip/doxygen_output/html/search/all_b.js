var searchData=
[
  ['palette',['Palette',['../classsc_meta_img.html#a838f8dd84d965f26be19feb3b2ea4940',1,'scMetaImg']]],
  ['palette_5fsize_5f',['palette_size_',['../classsc_meta_img.html#a20b85d897a6f821d27cdca3a40876606',1,'scMetaImg']]],
  ['palettesize',['PaletteSize',['../classsc_meta_img.html#a806acc93fab1c943cf3ea218b8574795',1,'scMetaImg']]],
  ['png',['PNG',['../namespacesc_image_handler_1_1_f_o_r_m_a_t.html#a6ee6f4a74c305423aa0597bc064a7b5ea6e9236078903ce622f1d15812eea94df',1,'scImageHandler::FORMAT']]]
];
