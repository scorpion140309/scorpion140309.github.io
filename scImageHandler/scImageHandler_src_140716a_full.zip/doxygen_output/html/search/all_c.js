var searchData=
[
  ['red',['Red',['../struct_s_c___m_e_t_a_i_m_g___p_a_l_e_t_t_e.html#ade9f7a77dabe0015c9f0fd3e1b39af36',1,'SC_METAIMG_PALETTE::Red()'],['../namespacens__sc_meta_img.html#a19d2cd0c4f1c1a3e99b6d960e1c38dd1aa6269fdd81e2cc09b63b998e2a35d15a',1,'ns_scMetaImg::RED()']]],
  ['reserved',['Reserved',['../struct_s_c___m_e_t_a_i_m_g___p_a_l_e_t_t_e.html#a3a66cf3e40413f7d616ca54343d58a70',1,'SC_METAIMG_PALETTE']]],
  ['resize',['Resize',['../classsc_meta_img.html#ada582505e01f92fb47893f9776928511',1,'scMetaImg::Resize(int width, int height, int bit, int channel)'],['../classsc_meta_img.html#ae523fd0ba76d14841577dc887ea817d8',1,'scMetaImg::Resize(const scMetaImg *ref_img)']]]
];
