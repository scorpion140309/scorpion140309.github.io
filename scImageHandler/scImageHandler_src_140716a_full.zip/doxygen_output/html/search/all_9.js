var searchData=
[
  ['ns_5fscmetaimg',['ns_scMetaImg',['../namespacens__sc_meta_img.html',1,'']]]
];
