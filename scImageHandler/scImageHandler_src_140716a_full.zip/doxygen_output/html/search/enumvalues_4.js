var searchData=
[
  ['png',['PNG',['../namespacesc_image_handler_1_1_f_o_r_m_a_t.html#a6ee6f4a74c305423aa0597bc064a7b5ea6e9236078903ce622f1d15812eea94df',1,'scImageHandler::FORMAT']]]
];
