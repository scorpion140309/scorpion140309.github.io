var searchData=
[
  ['jpeg',['JPEG',['../namespacesc_image_handler_1_1_f_o_r_m_a_t.html#a6ee6f4a74c305423aa0597bc064a7b5eae848008fe3413cf575e0442a19aef57b',1,'scImageHandler::FORMAT']]]
];
