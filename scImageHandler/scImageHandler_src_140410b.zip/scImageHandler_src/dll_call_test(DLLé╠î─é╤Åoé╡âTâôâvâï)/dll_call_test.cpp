#define _CRT_SECURE_NO_DEPRECATE
#include <scMetaImg.h>
#include <scImageHandler.h>

#include <windows.h>
#include <cstdio>

typedef const char* ( __stdcall *P_ERROR_MSG )();
typedef int ( __stdcall *P_SET_QALITY )( int qality );
typedef int ( __stdcall *P_SAVE_IMAGE )( const char *img_filename, const scMetaImg *p_meta_img, int img_format_id );
typedef int ( __stdcall *P_CREATE_IMAGE )( const char *img_filename, scMetaImg ** pp_meta_img );
typedef int ( __stdcall *P_DELETE_IMAGE )( scMetaImg *p_meta_img );



int Test_scImageHandler_DLL( const char *input_imgfile )
{
	const char DLL_PATH[] = "scImageHandler.dll";
	int result = -1;
	HINSTANCE hDLL;

	hDLL = ::LoadLibrary( DLL_PATH );
	if( hDLL )
	{
		P_ERROR_MSG		p_err_msg;
		P_SET_QALITY	p_set_quality;
		P_SAVE_IMAGE	p_save_img;
		P_CREATE_IMAGE	p_create_img;
		P_DELETE_IMAGE	p_delete_img;

		p_err_msg		= reinterpret_cast< P_ERROR_MSG >( ::GetProcAddress( hDLL, "scImageHandler_LastErrorMessage" ) );
		p_set_quality	= reinterpret_cast< P_SET_QALITY >( ::GetProcAddress( hDLL, "scImageHandler_SetQuality" ) );
		p_save_img		= reinterpret_cast< P_SAVE_IMAGE >( ::GetProcAddress( hDLL, "scImageHandler_Save" ) );
		p_create_img	= reinterpret_cast< P_CREATE_IMAGE >( ::GetProcAddress( hDLL, "scImageHandler_Create" ) );
		p_delete_img	= reinterpret_cast< P_DELETE_IMAGE >( ::GetProcAddress( hDLL, "scImageHandler_Delete" ) );

		if( p_err_msg != NULL && p_set_quality != NULL && p_save_img != NULL && p_create_img != NULL && p_delete_img != NULL )
		{
			scMetaImg *p_meta_img = NULL;

			// Load
			result = ( *p_create_img )( input_imgfile, &p_meta_img );
//			if( result == 0 && p_meta_img != NULL && p_meta_img->Channel() == 3 && p_meta_img->Bit() == 8 )
			if( result == 0 && p_meta_img != NULL )
			{
				int ary_qality_value[ 6 ] = { 0, 20, 40, 60, 80, 100 };
				char *filename_img;
				int num;
				scMetaImg test_img;
				int i;

				//
				filename_img = static_cast< char * >( ::operator new( 10000 ) );
				// ����̃e�X�g
				test_img = *p_meta_img;

				num = sizeof( ary_qality_value ) / sizeof( int );
				for( i = 0; i < num; i ++ )
				{
					// Set Quality( Jpeg )
					( *p_set_quality )( ary_qality_value[ i ] );

					// Save
					std::sprintf( filename_img, "jpge_quality_%03d.jpg", ary_qality_value[ i ] );
//					result = ( *p_save_img )( filename_img, p_meta_img, scImageHandler::JPEG );
					result = ( *p_save_img )( filename_img, &test_img, scImageHandler::FORMAT::JPEG );
					if( result )
					{
						break;
					}
				}
			}

			if( result )
			{
				// Error Message
				::MessageBox( NULL, ( * p_err_msg )(), "error", MB_OK | MB_ICONERROR );
			}

			if( p_meta_img )
			{
				( *p_delete_img )( p_meta_img );
//				delete p_meta_img;
				p_meta_img = NULL;
			}
		}
		::FreeLibrary( hDLL );

	}

	return result;
}

int main( int argc, char **argv )
{
	int result = -1;
	if( argc > 1 )
	{
		result = Test_scImageHandler_DLL( argv[ 1 ] );
	}
	else
	{
		::MessageBox( NULL, "24bit RGB�摜����͂��Ă��������B\n(JPGE,PNG,TIFF,BMP)", "error", MB_OK | MB_ICONERROR );
	}
	return result;
}