//
//
//

// System::Drawing ��L���ɂ���B
#using <System.Drawing.dll>

// ����w�b�_
#include <scImageHandler.h>
#include <scMetaImg.h>

// ���̑��̃w�b�_
#include <windows.h>


// �摜�����p�����[�^��G���[���b�Z�[�W�������Q�ƃN���X
ref class myGlobal
{
public:
	static System::String ^str_error;
	static __int64 q_value;
private:
	static myGlobal()
	{
		str_error = gcnew System::String( "No Error" );
		q_value = 75;
	}
};



//
//
// static�֐�
//
//

// Create
static scMetaImg * sttc_CreateMetaImg()
{
	scMetaImg *p_meta_img; 
	p_meta_img = ::new scMetaImg;
	return p_meta_img;
}

// Destroy
static void sttc_DestroyMetaImg( scMetaImg *p_meta_img )
{
	::delete p_meta_img;
	return;
}

// �C���[�W�G���R�[�_�Ɋւ�������擾����
static System::Drawing::Imaging::ImageCodecInfo^ sttc_GetEncoderInfo( System::String ^mineType )
{
	System::Drawing::Imaging::ImageCodecInfo^ ret_encoder = nullptr;
	cli::array< System::Drawing::Imaging::ImageCodecInfo^ > ^encs;

	encs= System::Drawing::Imaging::ImageCodecInfo::GetImageEncoders();
	for each( System::Drawing::Imaging::ImageCodecInfo^ enc in encs )
	{
		if( enc->MimeType == mineType )
		{
			ret_encoder = enc;
			break;
		}
	}
	return ret_encoder;
}

// R,G,B�e�F8bit
static int sttc_SaveImage_RGB24( const char *img_filename, const scMetaImg *p_meta_img, int img_format_id )
{
	int result = -1;

	if( img_format_id >= 0 && img_format_id < scImageHandler::FORMAT::_IMG_FORMAT_RESERVED_ )
	{
		try
		{
			cli::array< System::Drawing::Imaging::ImageFormat ^ > ^ary_img_format;
			System::String ^filename;
			System::Drawing::Bitmap ^bmp;
			System::Drawing::Rectangle rect;
			System::Drawing::Imaging::BitmapData ^bmpData;
			System::Drawing::Imaging::ImageFormat ^img_format;

			const unsigned char *pp_img_input_bgr[ 3 ];
			unsigned char* pBuf, *p_current_line;
			int width, height, bit, channel;
			int linesize;
			int x, y, c;
			volatile int flag_mem_save = 1;

			ary_img_format = gcnew cli::array< System::Drawing::Imaging::ImageFormat ^ >( scImageHandler::FORMAT::_IMG_FORMAT_RESERVED_ )
				{
					System::Drawing::Imaging::ImageFormat::Jpeg,
					System::Drawing::Imaging::ImageFormat::Png,
					System::Drawing::Imaging::ImageFormat::Tiff,
					System::Drawing::Imaging::ImageFormat::Gif,
					System::Drawing::Imaging::ImageFormat::Bmp
				};
			width = p_meta_img->Width();
			height = p_meta_img->Height();
			bit = 8;
			channel = 3;

			bmp = gcnew System::Drawing::Bitmap( width, height, System::Drawing::Imaging::PixelFormat::Format24bppRgb );
			rect = System::Drawing::Rectangle( 0, 0, bmp->Width, bmp->Height );
			bmpData = bmp->LockBits( rect, System::Drawing::Imaging::ImageLockMode::ReadWrite, bmp->PixelFormat );
			pBuf = static_cast< unsigned char * >( bmpData->Scan0.ToPointer() );
			img_format = ary_img_format[ img_format_id ];

			// 1���C���̃T�C�Y�́C4�o�C�g�̔{���ɐ؂�グ����K�v������B(4�o�C�g���E)
			linesize = ( ( channel * width * bit + 7 ) / 8 + 3 ) & ~3;


			// DIB
			for( y = 0; y < height; y ++ )
			{
//				p_current_line = pBuf + ( height - y - 1 ) * linesize;
				p_current_line = pBuf + y * linesize;

				// RGB -> BGR
				pp_img_input_bgr[ 0 ] = p_meta_img->CstImgPtr08( ns_scMetaImg::BLUE ) + y * width;
				pp_img_input_bgr[ 1 ] = p_meta_img->CstImgPtr08( ns_scMetaImg::GREEN ) + y * width;
				pp_img_input_bgr[ 2 ] = p_meta_img->CstImgPtr08( ns_scMetaImg::RED ) + y * width;

				// BGR, BGR, ...
				for( x = 0; x < width; x ++ )
				{
					for( c = 0; c < channel; c ++ )
					{
						p_current_line[ channel * x + c ] = pp_img_input_bgr[ c ][ x ];
					}
				}
			}

			filename = gcnew System::String( img_filename );

			// ��������ŃG���R�[�h�����f�[�^���擾���Ă���CWriteAllBytes �ŕۑ��B
			if( flag_mem_save )
			{
				System::IO::MemoryStream ^tempStream;

				tempStream = gcnew System::IO::MemoryStream();

				if( img_format_id == scImageHandler::FORMAT::JPEG )
				{
					System::Drawing::Imaging::EncoderParameter ^enc_param;
					System::Drawing::Imaging::EncoderParameters ^ary_enc_params;
					System::Drawing::Imaging::ImageCodecInfo ^ici;

					enc_param = gcnew System::Drawing::Imaging::EncoderParameter( System::Drawing::Imaging::Encoder::Quality, myGlobal::q_value );
					ary_enc_params = gcnew System::Drawing::Imaging::EncoderParameters( 1 );
					ary_enc_params->Param[ 0 ] = enc_param;
					ici = sttc_GetEncoderInfo( "image/jpeg" );
					bmp->Save( tempStream, ici, ary_enc_params );
				}
				else
				{
					bmp->Save( tempStream, img_format );
				}

				System::IO::File::WriteAllBytes( filename, tempStream->ToArray() );

			}
			// �t�H�[�}�b�g���w�肵�āC���ڕۑ��B
			else
			{
				bmp->Save( filename, img_format );
			}
			bmp->UnlockBits( bmpData );

			myGlobal::str_error = "No Error";
			result = 0;
		}
		catch( System::Exception ^ex )
		{
			myGlobal::str_error = ex->Message;
		}
	}

	return result;
}

//
static int sttc_SetPix( const unsigned char *p_pix_buf, scMetaImg *p_meta_img )
{
	int result = -1;
	const unsigned char *p_current_line;
	int channel, width, height, bit;
	int linesize;
	int c, x, y;
	unsigned char **ary_output_bgr_ptr;

	width	= p_meta_img->Width();
	height	= p_meta_img->Height();
	channel	= p_meta_img->Channel();
	bit		= p_meta_img->Bit();
	linesize = ( ( ( channel * width * bit + 7 ) / 8 ) + 3 ) & ~3;
	ary_output_bgr_ptr = static_cast< unsigned char ** >( ::operator new( sizeof( unsigned char * ) * channel ) );
	for( c = 0; c < channel; c ++ )
	{
		// RGB -> BGR
		ary_output_bgr_ptr[ ( channel - 1 ) - c ] = p_meta_img->ImgPtr08( c );
	}

	// DIB -> scMetaImg
	for( y = 0; y < height; y ++ )
	{
//		p_current_line = p_pix_buf + ( height - y - 1 ) * linesize;
		p_current_line = p_pix_buf + y * linesize;
		// BGR, BGR, ...
		for( x = 0; x < width; x ++ )
		{
			for( c = 0; c < channel; c ++ )
			{
				*ary_output_bgr_ptr[ c ] = p_current_line[ channel * x + c ];
				ary_output_bgr_ptr[ c ] ++;
			}
		}
	}

	::operator delete( ary_output_bgr_ptr );

	result = 0;
	return result;
}

//
static void sttc_SetPalette( System::Drawing::Bitmap ^bmp, scMetaImg *p_meta_img )
{
	int pal_size;

	pal_size = bmp->Palette->Entries->Length;
	if( pal_size )
	{
		SC_METAIMG_PALETTE *palette;
		int i;

		palette = p_meta_img->Palette();
		for( i = 0; i < pal_size; i ++ )
		{
			palette[ i ].Blue		= bmp->Palette->Entries[ i ].B;
			palette[ i ].Green		= bmp->Palette->Entries[ i ].G;
			palette[ i ].Red		= bmp->Palette->Entries[ i ].R;
			palette[ i ].Reserved	= bmp->Palette->Entries[ i ].A;
		}
	}
	return;
}

//
static void sttc_GetParams( System::Drawing::Bitmap ^bmp, int *channel, int *width, int *height, int *bit, int *pal_size )
{
	*width = bmp->Width;
	*height = bmp->Height;
	*pal_size = bmp->Palette->Entries->Length;
	switch( *pal_size )
	{
	case 1:
		*channel = 1;
		*bit = 1;
		break;
	case 16:
		*channel = 1;
		*bit = 4;
		break;
	case 256:
		*channel = 1;
		*bit = 8;
		break;
	default:
		*channel = 3;
		*bit = 8;
		break;
	}
	return;
}

//
static int sttc_LoadImage( const char *img_filename, scMetaImg **pp_meta_img )
{
	int result = -1;

	*pp_meta_img = NULL;
	try
	{
		System::Drawing::Bitmap ^bmp;
		System::Drawing::Rectangle rect;
		System::Drawing::Imaging::BitmapData ^bmpData;
		int channel, width, height, bit, pal_size;
		unsigned char *p_pix_buf;

		bmp = gcnew System::Drawing::Bitmap( gcnew System::String( img_filename ) );
		sttc_GetParams( bmp, &channel, &width, &height, &bit, &pal_size );

		//
		*pp_meta_img = sttc_CreateMetaImg();	// new scMetaImg;
		( *pp_meta_img )->Resize( width, height, bit, channel );
		sttc_SetPalette( bmp, ( *pp_meta_img ) );

		rect = System::Drawing::Rectangle( 0, 0, width, height );
		bmpData = bmp->LockBits( rect, System::Drawing::Imaging::ImageLockMode::ReadWrite, bmp->PixelFormat );
		p_pix_buf = static_cast< unsigned char * >( bmpData->Scan0.ToPointer() );

		sttc_SetPix( p_pix_buf, ( *pp_meta_img ) );

		bmp->UnlockBits( bmpData );

		myGlobal::str_error = "No Error";
		result = 0;
	}
	catch( System::Exception ^ex )
	{
		myGlobal::str_error = ex->Message;
		*pp_meta_img = NULL;
	}

	return result;
}


/////////////////////////////////////////////////////////////////
//
// extern�֐�
//
/////////////////////////////////////////////////////////////////

//
const char* __stdcall scImageHandler_LastErrorMessage()
{
	const char *p_error_msg;

	p_error_msg = static_cast< const char * >( System::Runtime::InteropServices::Marshal::StringToHGlobalAnsi( myGlobal::str_error ).ToPointer() );

	return p_error_msg;
}

//
int __stdcall scImageHandler_SetQuality( int qality )
{
	int q_value_old;

	q_value_old = static_cast< int >( myGlobal::q_value );
	if( qality < 0 )
	{
		myGlobal::q_value = 0;
	}
	else if( qality > 100 )
	{
		myGlobal::q_value = 100;
	}
	else
	{
		myGlobal::q_value = qality;
	}

	return q_value_old;
}

//
int __stdcall scImageHandler_Save( const char *img_filename, const scMetaImg *p_meta_img, int img_format_id )
{
	int result = -1;

	if( p_meta_img->Channel() == 3 && p_meta_img->Bit() == 8 )
	{
		result = sttc_SaveImage_RGB24( img_filename, p_meta_img, img_format_id );
	}
	else
	{
		myGlobal::str_error = "Not Supported( channel != 3 || bit != 8 )";
	}

	return result;
}





//
int __stdcall scImageHandler_Create( const char *img_filename, scMetaImg ** pp_meta_img )
{
	int result = -1;

	result = sttc_LoadImage( img_filename, pp_meta_img );

	return result;
}

//
int __stdcall scImageHandler_Delete( scMetaImg *p_meta_img )
{
	sttc_DestroyMetaImg( p_meta_img );		// delete scMetaImg;
	return 0;
}
