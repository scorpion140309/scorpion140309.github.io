var searchData=
[
  ['resize',['Resize',['../classsc_meta_img.html#ada582505e01f92fb47893f9776928511',1,'scMetaImg::Resize(int width, int height, int bit, int channel)'],['../classsc_meta_img.html#ae523fd0ba76d14841577dc887ea817d8',1,'scMetaImg::Resize(const scMetaImg *ref_img)']]]
];
