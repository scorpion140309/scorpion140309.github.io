var searchData=
[
  ['tiff',['TIFF',['../namespacesc_image_handler_1_1_f_o_r_m_a_t.html#a6ee6f4a74c305423aa0597bc064a7b5ead6b62f597625f739d7aeef4b51b92008',1,'scImageHandler::FORMAT']]]
];
