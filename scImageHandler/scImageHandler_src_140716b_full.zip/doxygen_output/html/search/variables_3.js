var searchData=
[
  ['green',['Green',['../struct_s_c___m_e_t_a_i_m_g___p_a_l_e_t_t_e.html#adfb5b95a3acc38f78409d5505772d5eb',1,'SC_METAIMG_PALETTE']]]
];
