var searchData=
[
  ['palette',['Palette',['../classsc_meta_img.html#a838f8dd84d965f26be19feb3b2ea4940',1,'scMetaImg']]],
  ['palettesize',['PaletteSize',['../classsc_meta_img.html#a806acc93fab1c943cf3ea218b8574795',1,'scMetaImg']]]
];
