var searchData=
[
  ['scimagehandler_5fcreate',['scImageHandler_Create',['../namespacesc_image_handler.html#a0f61de78c1517d44b69208269f81584d',1,'scImageHandler']]],
  ['scimagehandler_5fdelete',['scImageHandler_Delete',['../namespacesc_image_handler.html#a2e711e3342e7de9767cfebc8776b502a',1,'scImageHandler']]],
  ['scimagehandler_5flasterrormessage',['scImageHandler_LastErrorMessage',['../namespacesc_image_handler.html#af04dc484cef1e745c38eca72b7aa7217',1,'scImageHandler']]],
  ['scimagehandler_5fsave',['scImageHandler_Save',['../namespacesc_image_handler.html#a27a723e2db69d20da622e656a5eb25b6',1,'scImageHandler']]],
  ['scimagehandler_5fsetquality',['scImageHandler_SetQuality',['../namespacesc_image_handler.html#a4f89a0f14d08bff8f1019ec06fb153ef',1,'scImageHandler']]],
  ['scmetaimg',['scMetaImg',['../classsc_meta_img.html#a1e71ee9d48d37277ae12fb18e30c32d6',1,'scMetaImg::scMetaImg(const scMetaImg &amp;rhs)'],['../classsc_meta_img.html#a91ddccff5560327eae5f420b1e2aacf6',1,'scMetaImg::scMetaImg()']]]
];
