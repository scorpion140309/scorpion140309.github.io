var searchData=
[
  ['sc_5fmetaimg_5fpalette',['SC_METAIMG_PALETTE',['../struct_s_c___m_e_t_a_i_m_g___p_a_l_e_t_t_e.html',1,'']]],
  ['scmetaimg',['scMetaImg',['../classsc_meta_img.html',1,'']]]
];
