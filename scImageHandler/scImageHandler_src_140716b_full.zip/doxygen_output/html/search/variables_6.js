var searchData=
[
  ['red',['Red',['../struct_s_c___m_e_t_a_i_m_g___p_a_l_e_t_t_e.html#ade9f7a77dabe0015c9f0fd3e1b39af36',1,'SC_METAIMG_PALETTE']]],
  ['reserved',['Reserved',['../struct_s_c___m_e_t_a_i_m_g___p_a_l_e_t_t_e.html#a3a66cf3e40413f7d616ca54343d58a70',1,'SC_METAIMG_PALETTE']]]
];
