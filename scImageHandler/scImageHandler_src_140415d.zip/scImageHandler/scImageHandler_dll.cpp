//
//
//

// System::Drawing ��L���ɂ���B
#using <System.Drawing.dll>

// ����w�b�_
#include <scImageHandler.h>
#include <scMetaImg.h>

// ���̑��̃w�b�_
#include <windows.h>


// �摜�����p�����[�^��G���[���b�Z�[�W�������Q�ƃN���X
ref class myGlobal
{
public:
	static System::String ^str_error;
	static __int64 q_value;
private:
	static myGlobal()
	{
		str_error = gcnew System::String( "No Error" );
		q_value = 75;
	}
};



//
//
// static�֐�
//
//

// Create
static scMetaImg * sttc_CreateMetaImg()
{
	scMetaImg *p_meta_img; 
	p_meta_img = ::new scMetaImg;
	return p_meta_img;
}

// Destroy
static void sttc_DestroyMetaImg( scMetaImg *p_meta_img )
{
	::delete p_meta_img;
	return;
}

// �C���[�W�G���R�[�_�Ɋւ�������擾����
static System::Drawing::Imaging::ImageCodecInfo^ sttc_GetEncoderInfo( System::String ^mineType )
{
	System::Drawing::Imaging::ImageCodecInfo^ ret_encoder = nullptr;
	cli::array< System::Drawing::Imaging::ImageCodecInfo^ > ^encs;

	encs= System::Drawing::Imaging::ImageCodecInfo::GetImageEncoders();
	for each( System::Drawing::Imaging::ImageCodecInfo^ enc in encs )
	{
		if( enc->MimeType == mineType )
		{
			ret_encoder = enc;
			break;
		}
	}
	return ret_encoder;
}

//
static System::Drawing::Bitmap ^ sttc_CreateBitmap( int width, int height, int color_format )
{
	System::Drawing::Bitmap ^bmp;

	if( color_format == 1 )
	{
		bmp = gcnew System::Drawing::Bitmap( width, height, System::Drawing::Imaging::PixelFormat::Format1bppIndexed );

	}
	else if( color_format == 4 )
	{
		bmp = gcnew System::Drawing::Bitmap( width, height, System::Drawing::Imaging::PixelFormat::Format4bppIndexed );

	}
	else if( color_format == 8 )
	{
		bmp = gcnew System::Drawing::Bitmap( width, height, System::Drawing::Imaging::PixelFormat::Format8bppIndexed );

	}
	else
	{
		bmp = gcnew System::Drawing::Bitmap( width, height, System::Drawing::Imaging::PixelFormat::Format24bppRgb );
	}

	return bmp;
}

//
static void sttc_MakePalette( const scMetaImg *p_meta_img, System::Drawing::Bitmap ^bmp )
{
	if( p_meta_img->PaletteSize() > 0 )
	{
		System::Drawing::Imaging::ColorPalette ^palette;
		const SC_METAIMG_PALETTE *ary_palette;
		int pal_size;
		int i;

		// palette
		palette = bmp->Palette;
		ary_palette = p_meta_img->CstPalette();
		pal_size = p_meta_img->PaletteSize();
		for( i = 0; i < pal_size; i ++ )
		{
			palette->Entries[ i ] =  System::Drawing::Color::FromArgb( ary_palette[ i ].Reserved, ary_palette[ i ].Red, ary_palette[ i ].Green, ary_palette[ i ].Blue );
		}
		bmp->Palette = palette;
	}
	return;
}

//
static int sttc_SetOutputPixels_08_24( unsigned char *pBuf,  const scMetaImg *p_meta_img )
{
	unsigned char *p_current_line;
	const unsigned char *pp_img_input_bgr[ 3 ];
	int channel, width, height, bit;
	int linesize_output, linesize_input;
	int c, x, y;

	channel	= p_meta_img->Channel();
	width	= p_meta_img->Width();
	height	= p_meta_img->Height();
	bit		= p_meta_img->Bit();

	// �o�͑����C���T�C�Y
	// 1���C���̃T�C�Y�́C4�o�C�g�̔{���ɐ؂�グ����K�v������B(4�o�C�g���E)
	linesize_output = ( ( channel * width * bit + 7 ) / 8 + 3 ) & ~3;
	// ���͑����C���T�C�Y
	linesize_input = ( ( width * bit + 7 ) / 8 + 3 ) & ~3;


	// DIB
	for( y = 0; y < height; y ++ )
	{
		p_current_line = pBuf + y * linesize_output;

		// �P�F or �C���f�b�N�X�J���[
		if( channel == 1 )
		{
			pp_img_input_bgr[ 0 ] = p_meta_img->CstImgPtr08( 0 ) + y * linesize_input;
		}
		// RGB -> BGR
		else if( channel == 3 )
		{
			pp_img_input_bgr[ 0 ] = p_meta_img->CstImgPtr08( ns_scMetaImg::BLUE ) + y * width;
			pp_img_input_bgr[ 1 ] = p_meta_img->CstImgPtr08( ns_scMetaImg::GREEN ) + y * width;
			pp_img_input_bgr[ 2 ] = p_meta_img->CstImgPtr08( ns_scMetaImg::RED ) + y * width;
		}


		// BGR, BGR, ...
		for( x = 0; x < linesize_input; x ++ )
		{
			for( c = 0; c < channel; c ++ )
			{
				p_current_line[ channel * x + c ] = pp_img_input_bgr[ c ][ x ];
			}
		}
	}
	return 0;
}

//
static int sttc_SetOutputPixels_01( unsigned char *pBuf,  const scMetaImg *p_meta_img )
{
	unsigned char *p_current_line;
	const unsigned char *p_input_line;
	int width, height, bit;
	int linesize_output, linesize_input;
	int x, y;

	width	= p_meta_img->Width();
	height	= p_meta_img->Height();
	bit		= p_meta_img->Bit();

	// �o�͑����C���T�C�Y
	// 1���C���̃T�C�Y�́C4�o�C�g�̔{���ɐ؂�グ����K�v������B(4�o�C�g���E)
	linesize_output = ( ( width * bit + 7 ) / 8 + 3 ) & ~3;
	// ���͑����C���T�C�Y
	linesize_input = ( ( width * bit + 7 ) / 8 + 3 ) & ~3;


	// DIB
	for( y = 0; y < height; y ++ )
	{
		p_current_line = pBuf + ( height - 1 - y ) * linesize_output;

		// �P�F or �C���f�b�N�X�J���[
		p_input_line = p_meta_img->CstImgPtr08( 0 ) + y * linesize_input;

		// 
		for( x = 0; x < linesize_input; x ++ )
		{
			p_current_line[ x ] = p_input_line[ x ];
		}
	}
	return 0;
}

// R,G,B�e�F8bit
static int sttc_SaveImage_Core( const char *img_filename, const scMetaImg *p_meta_img, int img_format_id )
{
	int result = -1;

	if( img_format_id >= 0 && img_format_id < scImageHandler::FORMAT::_IMG_FORMAT_RESERVED_ )
	{
		try
		{
			cli::array< System::Drawing::Imaging::ImageFormat ^ > ^ary_img_format;
			System::String ^filename;
			System::Drawing::Bitmap ^bmp;
			System::Drawing::Rectangle rect;
			System::Drawing::Imaging::BitmapData ^bmpData;
			System::Drawing::Imaging::ImageFormat ^img_format;

			unsigned char* pBuf;
			int width, height, bit, channel, color_format;
			int linesize_output, linesize_input;
			volatile int flag_mem_save = 1;

			ary_img_format = gcnew cli::array< System::Drawing::Imaging::ImageFormat ^ >( scImageHandler::FORMAT::_IMG_FORMAT_RESERVED_ )
				{
					System::Drawing::Imaging::ImageFormat::Jpeg,
					System::Drawing::Imaging::ImageFormat::Png,
					System::Drawing::Imaging::ImageFormat::Tiff,
					System::Drawing::Imaging::ImageFormat::Gif,
					System::Drawing::Imaging::ImageFormat::Bmp
				};
			width	= p_meta_img->Width();
			height	= p_meta_img->Height();
			bit		= p_meta_img->Bit();
			channel	= p_meta_img->Channel();
			color_format = channel * bit;

			// create
			bmp = sttc_CreateBitmap( width, height, color_format );

			// palette
			sttc_MakePalette( p_meta_img, bmp );


			rect = System::Drawing::Rectangle( 0, 0, bmp->Width, bmp->Height );
			bmpData = bmp->LockBits( rect, System::Drawing::Imaging::ImageLockMode::ReadWrite, bmp->PixelFormat );
			pBuf = static_cast< unsigned char * >( bmpData->Scan0.ToPointer() );
			img_format = ary_img_format[ img_format_id ];

			// �o�͑����C���T�C�Y
			// 1���C���̃T�C�Y�́C4�o�C�g�̔{���ɐ؂�グ����K�v������B(4�o�C�g���E)
			linesize_output = ( ( channel * width * bit + 7 ) / 8 + 3 ) & ~3;
			// ���͑����C���T�C�Y
			linesize_input = ( ( width * bit + 7 ) / 8 + 3 ) & ~3;


			// DIB
			if( color_format == 8 || color_format == 24 )
			{
				result = sttc_SetOutputPixels_08_24( pBuf,  p_meta_img );
			}
			else if( color_format == 1 )
			{
				result = sttc_SetOutputPixels_01( pBuf,  p_meta_img );
			}
			else
			{
			}


			filename = gcnew System::String( img_filename );

			// ��������ŃG���R�[�h�����f�[�^���擾���Ă���CWriteAllBytes �ŕۑ��B
			if( flag_mem_save )
			{
				System::IO::MemoryStream ^tempStream;

				tempStream = gcnew System::IO::MemoryStream();

				if( img_format_id == scImageHandler::FORMAT::JPEG )
				{
					System::Drawing::Imaging::EncoderParameter ^enc_param;
					System::Drawing::Imaging::EncoderParameters ^ary_enc_params;
					System::Drawing::Imaging::ImageCodecInfo ^ici;

					enc_param = gcnew System::Drawing::Imaging::EncoderParameter( System::Drawing::Imaging::Encoder::Quality, myGlobal::q_value );
					ary_enc_params = gcnew System::Drawing::Imaging::EncoderParameters( 1 );
					ary_enc_params->Param[ 0 ] = enc_param;
					ici = sttc_GetEncoderInfo( "image/jpeg" );
					bmp->Save( tempStream, ici, ary_enc_params );
				}
				else
				{
					bmp->Save( tempStream, img_format );
				}

				System::IO::File::WriteAllBytes( filename, tempStream->ToArray() );

			}
			// �t�H�[�}�b�g���w�肵�āC���ڕۑ��B
			else
			{
				bmp->Save( filename, img_format );
			}
			bmp->UnlockBits( bmpData );

			myGlobal::str_error = "No Error";
			result = 0;
		}
		catch( System::Exception ^ex )
		{
			myGlobal::str_error = ex->Message;
		}
	}

	return result;
}

//
static int sttc_SetPix( const unsigned char *p_pix_buf, scMetaImg *p_meta_img )
{
	int result = -1;
	const unsigned char *p_current_line;
	int channel, width, height, bit;
	int linesize;
	int c, x, y;
	unsigned char **ary_output_bgr_ptr;

	width	= p_meta_img->Width();
	height	= p_meta_img->Height();
	channel	= p_meta_img->Channel();
	bit		= p_meta_img->Bit();
	linesize = ( ( ( channel * width * bit + 7 ) / 8 ) + 3 ) & ~3;
	ary_output_bgr_ptr = static_cast< unsigned char ** >( ::operator new( sizeof( unsigned char * ) * channel ) );
	for( c = 0; c < channel; c ++ )
	{
		// RGB -> BGR
		ary_output_bgr_ptr[ ( channel - 1 ) - c ] = p_meta_img->ImgPtr08( c );
	}

	// DIB -> scMetaImg
	if( bit == 8 )
	{
		for( y = 0; y < height; y ++ )
		{
//		p_current_line = p_pix_buf + ( height - y - 1 ) * linesize;
			p_current_line = p_pix_buf + y * linesize;
			// BGR, BGR, ...
			for( x = 0; x < width; x ++ )
			{
				for( c = 0; c < channel; c ++ )
				{
					*ary_output_bgr_ptr[ c ] = p_current_line[ channel * x + c ];
					ary_output_bgr_ptr[ c ] ++;
				}
			}
		}
	}
	else if( channel == 1 && bit == 1 )
	{
		int linesize_output;

		// 1 Byte ���E
		linesize_output = ( channel * width * bit + 7 ) / 8 ;
		for( y = 0; y < height; y ++ )
		{
			p_current_line = p_pix_buf + ( height - y - 1 ) * linesize;
			// BGR, BGR, ...
			for( x = 0; x < linesize_output; x ++ )
			{
				*ary_output_bgr_ptr[ 0 ] = p_current_line[ channel * x + 0 ];
				ary_output_bgr_ptr[ 0 ] ++;
			}
		}
	}


	::operator delete( ary_output_bgr_ptr );

	result = 0;
	return result;
}

//
static void sttc_SetPalette( System::Drawing::Bitmap ^bmp, scMetaImg *p_meta_img )
{
	int pal_size;

	pal_size = bmp->Palette->Entries->Length;
	if( pal_size )
	{
		SC_METAIMG_PALETTE *palette;
		int i;

		palette = p_meta_img->Palette();
		for( i = 0; i < pal_size; i ++ )
		{
			palette[ i ].Blue		= bmp->Palette->Entries[ i ].B;
			palette[ i ].Green		= bmp->Palette->Entries[ i ].G;
			palette[ i ].Red		= bmp->Palette->Entries[ i ].R;
			palette[ i ].Reserved	= bmp->Palette->Entries[ i ].A;
		}
	}
	return;
}

//
static int sttc_GetParams( System::Drawing::Bitmap ^bmp, int *channel, int *width, int *height, int *bit, int *pal_size )
{
	int result = 0;

	*width = bmp->Width;
	*height = bmp->Height;
	*pal_size = bmp->Palette->Entries->Length;

	switch( bmp->PixelFormat )
	{
	case System::Drawing::Imaging::PixelFormat::Format1bppIndexed:
		*channel = 1;
		*bit = 1;
		break;
	case System::Drawing::Imaging::PixelFormat::Format8bppIndexed:
		*channel = 1;
		*bit = 8;
		break;
	case System::Drawing::Imaging::PixelFormat::Format24bppRgb:
		*channel = 3;
		*bit = 8;
		break;
	case System::Drawing::Imaging::PixelFormat::Format48bppRgb:
		*channel = 3;
		*bit = 16;
		break;
	default:
		*channel = 3;
		*bit = 8;
		result = -1;
		myGlobal::str_error = "PixelFormat(" + System::Convert::ToInt32( bmp->PixelFormat ) + ") is Not Supported!";
		break;
	}

	return result;
}

/*
#include <cstdio>
int SaveBin( const char *filename, const unsigned char *p_pix_buf, int width, int height, int bit, int channel )
{
	int result = -1;
	std::FILE *fp;

	fp = std::fopen( filename, "wb" );
	if( fp )
	{
		int byte_size;
		byte_size = ( ( width * channel * bit + 7 ) / 8 ) * height;
		std::fwrite( p_pix_buf, byte_size, 1, fp );
		std::fclose( fp );
		result = 0;
	}

	return result;
}*/

//
static scMetaImg * sttc_LoadImage( const char *img_filename )
{
	scMetaImg *p_meta_img = NULL;

	try
	{
		System::Drawing::Bitmap ^bmp;
		System::Drawing::Rectangle rect;
		System::Drawing::Imaging::BitmapData ^bmpData;
		int channel, width, height, bit, pal_size;
		unsigned char *p_pix_buf;
		int check;

		bmp = gcnew System::Drawing::Bitmap( gcnew System::String( img_filename ) );
		check = sttc_GetParams( bmp, &channel, &width, &height, &bit, &pal_size );

		if( check == 0 )
		{
			//
			p_meta_img = sttc_CreateMetaImg();	// new scMetaImg;
			if( p_meta_img != NULL )
			{
				p_meta_img->Resize( width, height, bit, channel );
				sttc_SetPalette( bmp, p_meta_img );

				rect = System::Drawing::Rectangle( 0, 0, width, height );
				bmpData = bmp->LockBits( rect, System::Drawing::Imaging::ImageLockMode::ReadWrite, bmp->PixelFormat );
				p_pix_buf = static_cast< unsigned char * >( bmpData->Scan0.ToPointer() );
				sttc_SetPix( p_pix_buf, p_meta_img );

				bmp->UnlockBits( bmpData );

				myGlobal::str_error = "No Error";
			}
		}
	}
	catch( System::Exception ^ex )
	{
		myGlobal::str_error = ex->Message;

		if( p_meta_img )
		{
			::delete p_meta_img;
			p_meta_img = NULL;
		}
	}

	return p_meta_img;
}


/////////////////////////////////////////////////////////////////
//
// extern�֐�
//
/////////////////////////////////////////////////////////////////

//
const char* __stdcall scImageHandler_LastErrorMessage()
{
	const char *p_error_msg;

	p_error_msg = static_cast< const char * >( System::Runtime::InteropServices::Marshal::StringToHGlobalAnsi( myGlobal::str_error ).ToPointer() );

	return p_error_msg;
}

//
int __stdcall scImageHandler_SetQuality( int qality )
{
	int q_value_old;

	q_value_old = static_cast< int >( myGlobal::q_value );
	if( qality < 0 )
	{
		myGlobal::q_value = 0;
	}
	else if( qality > 100 )
	{
		myGlobal::q_value = 100;
	}
	else
	{
		myGlobal::q_value = qality;
	}

	return q_value_old;
}

//
int __stdcall scImageHandler_Save( const char *img_filename, const scMetaImg *p_meta_img, int img_format_id )
{
	int result = -1;
	int color_format;

	color_format = p_meta_img->Channel() * p_meta_img->Bit();
	if( color_format == 1 || color_format == 8 || color_format == 24 )
	{
		result = sttc_SaveImage_Core( img_filename, p_meta_img, img_format_id );
	}
	else
	{
		myGlobal::str_error = "Not Supported!";
	}

	return result;
}





//
void * __stdcall scImageHandler_Create( const char *img_filename )
{
	scMetaImg *p_meta_img = NULL;

	p_meta_img = sttc_LoadImage( img_filename );

	return p_meta_img;
}

//
void __stdcall scImageHandler_Delete( scMetaImg *p_meta_img )
{
	sttc_DestroyMetaImg( p_meta_img );		// delete scMetaImg;
	return;
}
